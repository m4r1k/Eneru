"""Entry point for running Eneru as a module: python -m eneru"""

from eneru.cli import main

if __name__ == "__main__":
    main()
