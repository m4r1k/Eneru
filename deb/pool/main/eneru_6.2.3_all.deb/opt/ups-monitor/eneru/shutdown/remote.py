"""SSH-based remote-server shutdown phase.

Owns the multi-server orchestration (sequential vs parallel batching by
``shutdown_order``) plus the per-server lifecycle: ``pre_shutdown_commands``
followed by the final shutdown command.
"""

import os
import shlex
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from eneru.actions import REMOTE_ACTIONS, render_action, serialize_umount_targets
from eneru.config import RemoteServerConfig
from eneru.remote_health import build_ssh_probe_command, uses_posix_shell
from eneru.utils import run_command

# Per-command wall-clock buffer added on top of the configured timeout to absorb
# SSH connection/teardown overhead. _run_remote_command spends this on every
# command. _shutdown_remote_server reserves command_timeout + this buffer for
# the final poweroff before spending the deadline on pre-shutdown commands, so a
# slow pre-phase can't starve the poweroff (H8).
_SSH_OVERHEAD_BUFFER = 30

# ELI5: when you log in at a terminal, your shell reads its "startup notes"
# (/etc/profile, ~/.profile) that say where all the tools live -- that's how
# your interactive `sudo which synoshutdown` finds /usr/syno/sbin on a
# Synology NAS. But `ssh host "cmd"` runs cmd non-interactively, so those
# notes are NEVER read: the shell starts with a bare, minimal PATH and a bare
# command name like `synoshutdown` looks like it doesn't exist ("command not
# found"), even though the file is sitting right there. We fix it by handing
# the remote shell a note of our own FIRST -- prepend an `export PATH=...`
# that re-adds the standard privileged dirs plus Synology's /usr/syno/sbin
# and /usr/syno/bin. We append them AFTER $PATH so the remote's own PATH still
# wins and any dir that doesn't exist on that host is simply ignored. sudo
# inherits this augmented PATH (the user's `sudo which` succeeding proves
# their sudoers has no restrictive secure_path), so `sudo -n synoshutdown`
# resolves the bare name exactly like an interactive login would. Real
# incident: DS1821 remote_server target, Eneru 6.1.6 power outage —
# "sudo: synoshutdown: command not found".
REMOTE_PATH_PREFIX = (
    'export PATH="$PATH:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:'
    '/sbin:/bin:/usr/syno/sbin:/usr/syno/bin"; '
)


def remote_shell_command(command: str) -> str:
    """Wrap ``command`` so the PATH prefix works under any login shell.

    ELI5: the note on the door is written in English, but some houses only
    read French. ssh hands our string to the remote user's *login* shell;
    tcsh (pfSense/FreeBSD default) reads ``"$PATH:/usr..."`` as a broken
    ``:`` modifier and drops the whole line, so from 6.1.7 on a
    tcsh target never shut down (issue #128). POSIX ``sh`` now sets PATH,
    then execs the user's own ``$SHELL -c`` with the command untouched, so
    bash/zsh/csh syntax in ``shutdown_command`` keeps working as before.
    Single quotes are literal in sh, bash, zsh and csh alike.
    """
    script = REMOTE_PATH_PREFIX + 'exec "${SHELL:-/bin/sh}" -c "$1"'
    return f"sh -c {shlex.quote(script)} sh {shlex.quote(command)}"

# ELI5: you phone a warehouse and shout "SHIP IT!" — mid-sentence the line goes
# dead. Did they hear you? On a small box (BusyBox/Alpine/dropbear/sysvinit) the
# `poweroff` you just sent kills sshd BEFORE it can mail you back an exit status,
# so ssh gives up with code 255 and a "connection dropped" complaint. That is
# NOT the shutdown command failing — it's the shutdown WORKING so fast it hung up
# on us. We only trust this reading for the FINAL poweroff (a mid-sequence
# command that drops the line really did fail) and only when the stderr looks
# like the transport tore down, never a real "Permission denied" 255.
_SSH_TRANSPORT_TEARDOWN_SIGNATURES = (
    "closed by remote host",
    "broken pipe",
    "connection reset",
)


def _is_ssh_transport_teardown(stderr: str) -> bool:
    """True when ssh stderr looks like the session was cut mid-command.

    Covers the fixed BusyBox/dropbear phrasings plus OpenSSH's
    "Connection to <host> closed." (variable host in the middle).
    """
    low = stderr.lower()
    if any(sig in low for sig in _SSH_TRANSPORT_TEARDOWN_SIGNATURES):
        return True
    return "connection to" in low and "closed" in low


@dataclass
class RemotePreShutdownResult:
    """Best-effort result summary for remote pre-shutdown commands."""

    attempted: int = 0
    failed: int = 0
    timed_out: bool = False
    error: str = ""


@dataclass
class RemoteShutdownResult:
    """Structured result for one remote shutdown worker."""

    server: str
    host: str
    completed: bool = True
    shutdown_sent: bool = False
    dry_run: bool = False
    pre_commands: RemotePreShutdownResult = field(default_factory=RemotePreShutdownResult)
    error: str = ""
    timed_out: bool = False
    crashed: bool = False
    # Final shutdown command outcome for the dashboard's detail pop-up.
    # ``exit_code`` stays None when the command never ran (dry-run, deadline).
    exit_code: Optional[int] = None
    response: str = ""

    @property
    def success(self) -> bool:
        """Return True only when the complete remote sequence succeeded.

        L6 (evaluated, intentional): for a loopback, ``crashed`` (a Phase-A
        pre-action crash) and ``shutdown_sent`` (the Phase-C poweroff succeeded)
        can BOTH be true -- the host drain partially failed but the poweroff
        still went out. Both flags are accurate; ``success`` deliberately treats
        a Phase-A crash as "not fully successful" so the summary surfaces the
        drain failure, even though the host did power off. This is a reporting
        nuance, not a shutdown defect, so it is left as-is.
        """
        return (
            self.completed
            and self.shutdown_sent
            and not self.timed_out
            and not self.crashed
            and not self.error
            and self.pre_commands.failed == 0
            and not self.pre_commands.timed_out
            and not self.pre_commands.error
        )


def _record_command_output(result: "RemoteShutdownResult",
                           capture: Dict[str, Any]) -> None:
    """Copy the final command's exit code and output onto ``result``."""
    exit_code = capture.get("exit_code")
    result.exit_code = exit_code if isinstance(exit_code, int) else None
    parts = [str(capture.get(key) or "").strip() for key in ("stdout", "stderr")]
    result.response = "\n".join(part for part in parts if part)


def loopback_poweroff_sent(result: "RemoteShutdownResult") -> bool:
    """True when the Phase-C delegated host poweroff was actually delivered.

    ISS-005: unlike ``RemoteShutdownResult.success``, this deliberately IGNORES
    Phase-A drain failures (``crashed`` / ``error``). When a loopback delegate's
    pre-action crashes but the poweroff command still went out, the host IS
    powering off, so the sequence must be treated as complete (write the
    SHUTDOWN_SEQUENCE_COMPLETE marker, no failure notification) — the drain
    failure is a reporting nuance, not a missed shutdown. This is the shared
    predicate for the monitor and redundancy loopback paths, which previously
    diverged (monitor used ``all(r.success)`` and misclassified a delivered
    poweroff as failed).
    """
    return bool(
        result.completed
        and result.shutdown_sent
        and not result.timed_out
    )


def select_loopback_results(
    remote_servers: List[RemoteServerConfig],
    results: List["RemoteShutdownResult"],
) -> List["RemoteShutdownResult"]:
    """Return the subset of remote-shutdown ``results`` that belong to an
    enabled ``is_host_loopback`` server.

    A loopback entry's executed shutdown_command is what actually powers
    off THIS host, so the delegated-shutdown paths (single-UPS monitor and
    the redundancy executor) key their "did the poweroff go out?" decision
    on exactly these results. Matched by the ``(name-or-host, host)`` pair
    against the configured servers.

    ISS-013: previously duplicated verbatim as an inline list-comprehension
    in both ``monitor.py`` and ``redundancy.py`` — one source of truth now.
    """
    return [
        result for result in results
        if any(
            server.enabled
            and server.is_host_loopback is True
            and (server.name or server.host) == result.server
            and server.host == result.host
            for server in remote_servers
        )
    ]


def with_sudo(command: str, use_sudo: bool) -> str:
    """Prefix a remote command with ``sudo -n`` when ``use_sudo`` is set.

    The ONE copy of this rule: the runtime and ``eneru config check`` both
    call it, so the check always inspects the command that really gets sent
    (F-124). Idempotent: a command whose first word already is sudo (any
    whitespace after it, or an absolute path like ``/usr/bin/sudo``) is left
    as written. ``sudoedit`` is a different program and is prefixed.
    """
    if not use_sudo:
        return command
    words = (command or "").split(None, 1)
    if words and os.path.basename(words[0]) == "sudo":
        return command
    return f"sudo -n {command}"


class RemoteShutdownMixin:
    """Mixin: SSH-based remote-server orchestration and shutdown."""

    @staticmethod
    def _with_sudo(command: str, use_sudo: bool) -> str:
        """Thin alias of the module-level :func:`with_sudo` (shared with
        ``eneru config check``)."""
        return with_sudo(command, use_sudo)

    @staticmethod
    def _step_use_sudo(server: RemoteServerConfig, cmd_config: Any) -> bool:
        """A pre-shutdown step's effective sudo: its own override, else the
        server's ``use_sudo`` (F-098). Unset (None) means inherit."""
        override = getattr(cmd_config, "use_sudo", None)
        return bool(server.use_sudo if override is None else override)

    def _track_remote_start(self, server: RemoteServerConfig) -> Optional[int]:
        tracker = getattr(self, "_shutdown_progress", None)
        if tracker is not None:
            return tracker.remote_start(server.name or server.host, server.host)
        return None

    def _track_remote_finish(
        self, result: RemoteShutdownResult, generation: Optional[int],
    ) -> None:
        tracker = getattr(self, "_shutdown_progress", None)
        if tracker is not None:
            tracker.remote_finish(result, generation)

    def _shutdown_remote_servers(self) -> List[RemoteShutdownResult]:
        """Shutdown all enabled remote servers via SSH.

        v5.5: ``is_host_loopback: true`` delegates always **bracket** the
        other remotes regardless of their ``shutdown_order``:

        1. Loopback ``pre_shutdown_commands`` (stop local VMs/containers,
           sync, unmount NFS that targets a peer remote) run FIRST so the
           local drain finishes while peer remotes are still alive.
        2. Non-loopback remotes (NAS, secondary host, …) run in the middle,
           grouped by ``shutdown_order`` exactly as in v5.4.
        3. Loopback ``shutdown_command`` (host poweroff) runs LAST so the
           eneru host outlives every remote it might have depended on.

        Why intrinsic and not user-configurable: pre-v5.5 the local-host
        phases (VMs/containers/sync/unmount) ran before any remote and the
        host poweroff ran after. v5.5 collapses the local work into a
        single loopback ``remote_servers`` entry; honouring its
        ``shutdown_order`` like a regular remote would mean the local
        drain races the peer remote shutdowns — that bug ate the v5.5.0-rc7
        controlled test on 2026-05-18 (NFS unmount hung 32s while the NAS
        was already powering off). See AGENTS.md "Loopback ordering".

        Non-loopback remotes follow v5.4 ordering: ``shutdown_order``
        ascending, ties broken by the legacy ``parallel`` flag:
        - parallel: true  (default) -> effective order 0
        - parallel: false -> unique negative orders (run before order 0)
        """
        # Imported lazily to avoid a circular import (monitor.py imports
        # this mixin).
        from eneru.monitor import compute_effective_order

        enabled_servers = [s for s in self.config.remote_servers if s.enabled]
        for server in enabled_servers:
            # A new shutdown run may re-detect a host that was down last time.
            server._runtime_detect_tried = False

        if not enabled_servers:
            return []

        # Partition: loopback delegates bracket the regulars.
        loopbacks = [s for s in enabled_servers if s.is_host_loopback is True]
        regulars = [s for s in enabled_servers if s.is_host_loopback is not True]

        # Phase plan for the header log.
        regular_phases: Dict[int, List[RemoteServerConfig]] = {}
        if regulars:
            ordered = compute_effective_order(regulars)
            for effective, server in ordered:
                regular_phases.setdefault(effective, []).append(server)
        sorted_regular_keys = sorted(regular_phases.keys())

        has_loopback_pre = any(lb.pre_shutdown_commands for lb in loopbacks)
        has_loopback_post = bool(loopbacks)
        num_phases = (
            (1 if has_loopback_pre else 0)
            + len(sorted_regular_keys)
            + (1 if has_loopback_post else 0)
        )

        server_count = len(enabled_servers)
        server_word = "server" if server_count == 1 else "servers"

        if num_phases > 1:
            self._log_message(
                f"🌐  Shutting down {server_count} remote {server_word} in {num_phases} phases..."
            )
        elif server_count > 1 and regulars:
            # "in parallel" is only honest when at least one regular is
            # in the batch — _shutdown_servers_parallel actually threads
            # them. A multi-loopback-only batch (rare, K8s-only) runs
            # Phase C with a plain for-loop over loopbacks, so don't
            # advertise parallelism that won't happen.
            self._log_message(
                f"🌐  Shutting down {server_count} remote servers in parallel..."
            )
        elif server_count > 1:
            self._log_message(
                f"🌐  Shutting down {server_count} remote servers..."
            )
        else:
            self._log_message("🌐  Shutting down 1 remote server...")

        # Pre-allocate one result per loopback so the pre-phase and the
        # post-phase write back into the same record (pre_commands +
        # shutdown_sent live on the same object).
        loopback_results: Dict[int, RemoteShutdownResult] = {}
        loopback_generations: Dict[int, Optional[int]] = {}
        for lb in loopbacks:
            loopback_results[id(lb)] = RemoteShutdownResult(
                server=lb.name or lb.host,
                host=lb.host,
                pre_commands=RemotePreShutdownResult(),
            )
            loopback_generations[id(lb)] = self._track_remote_start(lb)

        # M2 NOTE: an earlier rc10 iteration ran a fresh, blocking
        # run_loopback_identity_probe() here before the destructive phases. It
        # was reverted: the probe is an SSH round-trip (bounded, but up to
        # connect_timeout+10s) that would delay the poweroff during an outage,
        # and we PROCEED regardless of its result, so it added latency on the
        # critical path for purely-informational value. Loopback identity is
        # already verified by the background RemoteHealthManager loop (which
        # logs + notifies a mismatch) and gated by /ready, so the misconfig is
        # surfaced there without blocking shutdown.
        phase_idx = 0
        regular_results: List[RemoteShutdownResult] = []

        # Phase A: loopback pre-actions — drain local state while peers live.
        if has_loopback_pre:
            # has_loopback_pre implies loopbacks exist, which implies
            # has_loopback_post is True, which means num_phases ≥ 2 by
            # construction. No need to gate the Phase header.
            phase_idx += 1
            names = ", ".join(
                lb.name or lb.host for lb in loopbacks if lb.pre_shutdown_commands
            )
            self._log_message(
                f"  📋  Phase {phase_idx}/{num_phases} (loopback pre-actions): {names}"
            )
            for lb in loopbacks:
                if not lb.pre_shutdown_commands:
                    continue
                display = lb.name or lb.host
                self._log_message(
                    f"🌐  Initiating loopback pre-actions: {display} ({lb.host})..."
                )
                # No phase-deadline here: loopback pre-actions are
                # best-effort and the per-command timeouts already cap
                # each step. A hung NFS unmount must not abort the
                # later peer-remote phase.
                #
                # try/except mirrors the thread-level guard in
                # _shutdown_servers_parallel: a bubbling Python
                # exception (SSH lib OOM, AttributeError, etc.) must
                # NOT skip the host poweroff in Phase C. Worst case
                # the operator loses the local drain on that loopback;
                # the host still goes down cleanly.
                try:
                    loopback_results[id(lb)].pre_commands = (
                        self._execute_remote_pre_shutdown(lb, collect_result=True)
                    )
                except Exception as exc:
                    self._log_message(
                        f"  ❌  Loopback pre-actions thread for {display} crashed: {exc}"
                    )
                    result = loopback_results[id(lb)]
                    result.pre_commands.error = str(exc)
                    result.pre_commands.failed += 1
                    result.crashed = True

        # Phase B: non-loopback remotes (existing parallel phased path).
        # F-118: a crash here must not skip Phase C (the host poweroff), the
        # same "host always goes down" discipline Phases A and C already
        # follow. The servers it never finished are reported as crashed rows
        # AFTER Phase C, so callers still see the loopback's poweroff result.
        phase_b_error: Optional[BaseException] = None
        finished_regulars: set = set()
        try:
            for key in sorted_regular_keys:
                phase_idx += 1
                phase_servers = regular_phases[key]
                names = ", ".join(s.name or s.host for s in phase_servers)
                if num_phases > 1:
                    self._log_message(
                        f"  📋  Phase {phase_idx}/{num_phases} (order={key}): {names}"
                    )
                regular_results.extend(
                    self._shutdown_servers_parallel(phase_servers))
                finished_regulars.update(id(s) for s in phase_servers)
        except Exception as exc:
            self._log_message(
                f"  ❌  Remote-server phase crashed: {exc}; continuing to the "
                "loopback poweroff"
            )
            phase_b_error = exc

        # Phase C: loopback poweroff — host goes down LAST.
        if has_loopback_post:
            phase_idx += 1
            names = ", ".join(lb.name or lb.host for lb in loopbacks)
            if num_phases > 1:
                self._log_message(
                    f"  📋  Phase {phase_idx}/{num_phases} (loopback poweroff): {names}"
                )
            for lb in loopbacks:
                # Same try/except discipline as Phase A: a crash in one
                # loopback's poweroff must not skip the others (rare,
                # but possible in K8s multi-pod with several loopbacks).
                display = lb.name or lb.host
                try:
                    self._shutdown_loopback_command(lb, loopback_results[id(lb)])
                except Exception as exc:
                    self._log_message(
                        f"  ❌  Loopback poweroff thread for {display} crashed: {exc}"
                    )
                    result = loopback_results[id(lb)]
                    result.error = str(exc)
                    result.crashed = True
                finally:
                    self._track_remote_finish(
                        loopback_results[id(lb)], loopback_generations[id(lb)])

        if phase_b_error is not None:
            for server in regulars:
                if id(server) not in finished_regulars:
                    regular_results.append(RemoteShutdownResult(
                        server=server.name or server.host,
                        host=server.host,
                        completed=False,
                        error=f"remote-server phase crashed: {phase_b_error}",
                        crashed=True,
                    ))

        results: List[RemoteShutdownResult] = (
            list(loopback_results.values()) + regular_results
        )

        # Log summary
        succeeded = sum(1 for result in results if result.success)
        timed_out = sum(1 for result in results if result.timed_out)
        crashed = sum(1 for result in results if result.crashed)
        failed = server_count - succeeded - timed_out - crashed
        icon = "✅" if succeeded == server_count else "⚠️"
        details = [f"{succeeded}/{server_count} succeeded"]
        if failed:
            details.append(f"{failed} failed")
        if timed_out:
            details.append(f"{timed_out} timed out")
        if crashed:
            details.append(f"{crashed} crashed")
        self._log_message(f"  {icon} Remote shutdown complete ({', '.join(details)})")
        return results

    def _shutdown_loopback_command(
        self,
        server: RemoteServerConfig,
        result: RemoteShutdownResult,
    ) -> None:
        """Execute ONLY the loopback's shutdown_command (no pre-actions).

        v5.5 loopback orchestration runs pre_shutdown_commands in an
        earlier phase (so peer remotes can outlive the local drain) and
        defers the host poweroff to this final phase. This helper
        completes the pre-allocated result record with the poweroff
        outcome.

        Why mutate the caller-provided ``result`` instead of returning
        a fresh one: a loopback's lifecycle spans two phases (A:
        pre-actions, C: poweroff) but produces ONE summary row in
        ``Remote shutdown complete (N/M succeeded)``. The caller
        pre-allocates ``result`` before Phase A so ``pre_commands`` and
        ``shutdown_sent`` land on the same object; returning a fresh
        partial here would split the record across two rows and
        confuse the summary. Mirror for regular remotes:
        ``_shutdown_remote_server`` does both pre and poweroff in a
        single call, so it can return its own result.
        """
        display = server.name or server.host
        self._log_message(
            f"🌐  Initiating loopback poweroff: {display} ({server.host})..."
        )

        # Fire the per-server notification BEFORE issuing the SSH
        # command. Symmetry with regular remotes (see
        # _shutdown_remote_server) and — critically for the loopback
        # case — the notification has to leave the host before the
        # host powers off. Notification recipients (Discord, Slack,
        # PagerDuty, …) live outside the host, so they receive it just
        # fine; the only thing they would miss is a notification fired
        # AFTER the kernel halt syscall.
        self._send_notification(
            f"🌐  **Remote Shutdown Starting:** {display}\n"
            f"Host: {server.host}",
            self.config.NOTIFY_INFO,
            category="shutdown",
        )

        shutdown_command = self._with_sudo(server.shutdown_command, server.use_sudo)
        self._log_message(
            f"  🔌  [{display}] Sending shutdown command: {shutdown_command}"
        )

        if self.config.behavior.dry_run:
            result.shutdown_sent = True
            result.dry_run = True
            self._log_message(
                f"  🧪  [{display}] [DRY-RUN] Would send command "
                f"'{shutdown_command}' to {server.user}@{server.host}"
            )
            return

        capture: Dict[str, Any] = {}
        success, error_msg = self._run_remote_command(
            server,
            shutdown_command,
            server.command_timeout,
            "shutdown",
            is_final_shutdown=True,
            capture=capture,
        )
        _record_command_output(result, capture)

        if success:
            result.shutdown_sent = True
            if error_msg:
                # F-077: sent but unconfirmed (SSH transport tore down before
                # the exit status came back). shutdown_sent is still True so
                # the marker is written and no false-incomplete alert fires.
                self._log_message(
                    f"  ✅  {display} shutdown command sent ({error_msg})"
                )
            else:
                self._log_message(f"  ✅  {display} shutdown command sent successfully")
        else:
            result.error = error_msg
            self._log_message(
                f"  ❌  WARNING: Failed to execute shutdown command on {display}: {error_msg}"
            )
            self._send_notification(
                f"❌  **Remote Shutdown Failed:** {display}\nError: {error_msg}",
                self.config.NOTIFY_FAILURE,
                category="shutdown",
            )

    def _shutdown_servers_parallel(
        self, servers: List[RemoteServerConfig]
    ) -> List[RemoteShutdownResult]:
        """Shutdown multiple remote servers in parallel using threads.

        Returns one structured result per server.  The join is deadline-based
        so a stuck SSH call cannot multiply the wait by the number of servers.
        """
        def calc_server_timeout(server: RemoteServerConfig) -> int:
            # Explicit None check so a per-command timeout of 0 (e.g. for
            # a command the user wants to fire-and-forget) isn't promoted
            # to server.command_timeout via Python's truthiness.
            pre_cmd_time = sum(
                (cmd.timeout if cmd.timeout is not None else server.command_timeout)
                for cmd in server.pre_shutdown_commands
            )
            # _run_remote_command spends `timeout + _SSH_OVERHEAD_BUFFER` on EACH
            # command (every pre-shutdown command plus the final shutdown). The
            # phase-deadline budget must reserve that buffer per command too
            # (CodeRabbit), otherwise the parallel join deadline can expire while
            # a worker is still legitimately inside its own SSH timeout and the
            # server is wrongly reported timed-out.
            num_commands = len(server.pre_shutdown_commands) + 1
            return (
                pre_cmd_time
                + server.command_timeout
                + server.connect_timeout
                + server.shutdown_safety_margin
                + num_commands * _SSH_OVERHEAD_BUFFER
            )

        max_timeout = max(calc_server_timeout(s) for s in servers)

        results: Dict[threading.Thread, RemoteShutdownResult] = {}
        lock = threading.Lock()

        def default_result(
            server: RemoteServerConfig,
            *,
            completed: bool = True,
            error: str = "",
            timed_out: bool = False,
            crashed: bool = False,
        ) -> RemoteShutdownResult:
            return RemoteShutdownResult(
                server=server.name or server.host,
                host=server.host,
                completed=completed,
                shutdown_sent=False,
                pre_commands=RemotePreShutdownResult(),
                error=error,
                timed_out=timed_out,
                crashed=crashed,
            )

        def coerce_result(server: RemoteServerConfig, result) -> RemoteShutdownResult:
            if isinstance(result, RemoteShutdownResult):
                return result
            # Backward-compatible test hook path: older tests monkeypatch
            # _shutdown_remote_server with a function that returns None.
            coerced = default_result(server)
            coerced.shutdown_sent = True
            return coerced

        def shutdown_server_thread(
            server: RemoteServerConfig, generation: Optional[int],
        ):
            """Thread worker for shutting down a single server."""
            result = None
            try:
                try:
                    result = self._shutdown_remote_server(server, deadline=deadline)
                except TypeError as exc:
                    if "unexpected keyword argument 'deadline'" not in str(exc):
                        raise
                    # Backward-compatible test hook path: older tests
                    # monkeypatch _shutdown_remote_server with a function
                    # that accepts only the server argument.
                    result = self._shutdown_remote_server(server)
                result = coerce_result(server, result)
            except Exception as exc:
                # _shutdown_remote_server only catches SSH-style errors;
                # bubbling exceptions (network, AttributeError, OOM…) would
                # otherwise vanish silently in the worker thread.
                display = server.name or server.host
                self._log_message(
                    f"  ❌  Remote shutdown thread for {display} crashed: {exc}"
                )
                result = default_result(server, error=str(exc), crashed=True)
            self._track_remote_finish(result, generation)
            with lock:
                results[threading.current_thread()] = result

        deadline = time.monotonic() + max_timeout
        threads: List[threading.Thread] = []
        thread_generations: Dict[threading.Thread, Optional[int]] = {}
        for server in servers:
            generation = self._track_remote_start(server)
            t = threading.Thread(
                target=shutdown_server_thread,
                args=(server, generation),
                name=f"remote-shutdown-{server.name or server.host}",
                daemon=True,
            )
            thread_generations[t] = generation
            try:
                t.start()
            except Exception as exc:
                # e.g. "can't start new thread" under resource exhaustion.
                # Record it and keep going: workers already started are still
                # joined below, and the caller still reaches the loopback
                # poweroff (Phase C) instead of aborting the whole phase.
                display = server.name or server.host
                self._log_message(
                    f"  ❌  Could not start remote shutdown worker for {display}: {exc}"
                )
                failed = default_result(server, error=str(exc), crashed=True)
                self._track_remote_finish(failed, generation)
                with lock:
                    results[t] = failed
            threads.append(t)

        # Deadline-based join: cap total wait at max_timeout regardless of
        # how many threads are stuck. Per-thread join() with the same
        # max_timeout would stack to N × max_timeout in the worst case.
        for t in threads:
            if t.ident is None:
                continue  # never started; its failure is already recorded
            remaining = max(0.0, deadline - time.monotonic())
            t.join(timeout=remaining)

        still_running = [
            server.name or server.host
            for t, server in zip(threads, servers)
            if t.is_alive()
        ]
        if still_running:
            self._log_message(
                f"  ⚠️  {len(still_running)} remote shutdown(s) still in progress "
                f"({', '.join(still_running)}; continuing with next phase)"
            )

        final_results: List[RemoteShutdownResult] = []
        with lock:
            for thread, server in zip(threads, servers):
                result = results.get(thread)
                if result is None:
                    result = default_result(
                        server,
                        completed=False,
                        timed_out=True,
                        error="remote shutdown worker timed out",
                    )
                    generation = thread_generations.get(thread)
                    self._track_remote_finish(result, generation)
                final_results.append(result)
        return final_results

    def _run_remote_command(
        self,
        server: RemoteServerConfig,
        command: str,
        timeout: int,
        description: str,
        *,
        deadline: Optional[float] = None,
        is_final_shutdown: bool = False,
        capture: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, str]:
        """Run a single command on a remote server via SSH.

        ``is_final_shutdown`` marks the ONE poweroff command (not
        pre_shutdown_commands): only then is an exit-255 transport teardown
        treated as "sent (unconfirmed)" rather than a failure (F-077).
        ``capture``, when given, receives the raw ``exit_code``/``stdout``/
        ``stderr`` of the SSH invocation (untouched if it never ran). On
        success the second tuple element is normally "" but carries a
        human-readable note ("SSH transport ended (result unknown)") for that
        unconfirmed case so callers can log it honestly.

        Returns:
            Tuple of (success, error_or_note)
        """
        # F-095: ONE argv builder for health probes, `config check` and the
        # real shutdown. ELI5: two people reading the same shopping list must
        # read it the same way -- this path used to read `["-i", "/key"]` as
        # two unrelated items (so the key path became the hostname) while the
        # health probe read it correctly, so a remote could look healthy and
        # still never shut down. The shared builder knows which flags take a
        # separate value and rejects a dangling one.
        #
        # Single lowest common injection point: BOTH the final shutdown_command
        # and every pre_shutdown_commands entry (custom commands AND the
        # REMOTE_ACTIONS templates), across the normal remote path AND the
        # loopback-to-127.0.0.1 path, funnel through here before ssh. The PATH
        # augmentation wraps the ONE argv element that carries the remote
        # command string (remote_shell_command), so argv stays `ssh <opts> -- user@host "<cmd>"`.
        # The LOCAL, non-SSH execution paths never reach _run_remote_command.
        # Issue #128: a device without a POSIX shell (RouterOS, Cisco, ...)
        # rejects the sh wrapper as a whole line, so it gets the command
        # exactly as written. Until a device proves it has no shell it stays
        # POSIX.
        posix = self._remote_uses_posix_shell(server, timeout, deadline)
        try:
            ssh_cmd = build_ssh_probe_command(
                server, remote_shell_command(command) if posix else command)
        except ValueError as exc:
            # A dangling option (e.g. a trailing "-i") is a config error for
            # this server only: fail the step, never crash the sequence.
            # ``capture`` stays untouched: ssh never ran.
            return False, str(exc)

        # Add buffer to account for SSH connection overhead, unless a
        # shutdown-phase deadline requires a tighter cap. This prevents a
        # hung pre-shutdown command from outliving the phase and later
        # drifting into the final shutdown command.
        command_timeout = timeout + _SSH_OVERHEAD_BUFFER
        if deadline is not None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False, "remote shutdown deadline exceeded"
            command_timeout = max(1, min(command_timeout, int(remaining)))
        exit_code, stdout, stderr = run_command(ssh_cmd, timeout=command_timeout)
        if capture is not None:
            capture.update(exit_code=exit_code, stdout=stdout, stderr=stderr)

        if exit_code == 0:
            if not posix:
                # A shell-less CLI may report a failure with exit 0 (RouterOS
                # does, half the time), so surface whatever it printed.
                reply = next((line.strip() for line in
                              f"{stdout or ''}\n{stderr or ''}".splitlines()
                              if line.strip()), "")
                if reply:
                    return True, (f"the device replied: {reply[:200]}; no POSIX "
                                  "shell, so its exit status is not reliable")
            return True, ""
        elif exit_code == 124:
            # ``command_timeout`` is the value actually handed to
            # ``run_command`` (timeout + SSH overhead buffer, capped by the
            # phase deadline). Reporting just ``timeout`` would mislead
            # operators when deadline-capping shrinks the effective
            # window below what was configured per-command.
            if command_timeout != timeout + _SSH_OVERHEAD_BUFFER:
                return (
                    False,
                    f"timed out after {command_timeout}s "
                    f"(configured {timeout}s, capped by phase deadline)",
                )
            return False, (f"timed out after {command_timeout}s "
                           f"(command_timeout {timeout}s + "
                           f"{_SSH_OVERHEAD_BUFFER}s SSH allowance)")
        elif (
            is_final_shutdown
            and exit_code == 255
            and _is_ssh_transport_teardown(stderr)
        ):
            # F-077: the remote accepted the poweroff and sshd died before
            # returning status. Report "sent (unconfirmed)" so the
            # loopback-delegate path writes the completion marker and skips the
            # false "sequence incomplete" alert. Scoped to the final poweroff
            # and a transport-teardown stderr — a mid-sequence drop, a non-255
            # code, or "Permission denied" all stay failures.
            return True, "SSH transport ended (result unknown)"
        else:
            # A shell-less CLI (RouterOS) prints its errors on stdout.
            reply = stderr.strip() or ("" if posix else next(
                (line.strip() for line in (stdout or "").splitlines()
                 if line.strip()), ""))
            return False, reply or f"exit code {exit_code}"

    @staticmethod
    def _remote_uses_posix_shell(server: RemoteServerConfig, timeout: int,
                                 deadline: Optional[float]) -> bool:
        """Shell mode for the shutdown path, detecting ``auto`` at most once.

        ELI5: knocking to ask "anyone speak sh?" must not eat the minutes
        reserved for the real message. Detection only runs while the phase
        deadline still leaves room for the command itself (``timeout`` + the
        SSH allowance), is capped to the spare time, and is tried once per
        server per shutdown run: an unreachable host is not re-probed before
        every step. Skipped or inconclusive means POSIX, as before 6.2.2.
        """
        detect = not server._runtime_detect_tried
        probe_timeout = server.connect_timeout + 10
        if detect and deadline is not None:
            spare = int(deadline - time.monotonic()) - (timeout + _SSH_OVERHEAD_BUFFER)
            if spare < 5:
                detect = False
            else:
                probe_timeout = min(probe_timeout, spare)
        if detect and server._detected_posix is None:
            server._runtime_detect_tried = True
        return uses_posix_shell(server, detect=detect, timeout=probe_timeout)

    @staticmethod
    def _remote_deadline_exceeded(deadline: Optional[float] = None) -> bool:
        """Return True when a remote shutdown phase deadline has expired."""
        return deadline is not None and time.monotonic() >= deadline

    def _loopback_skip_ids(self):
        """Return the set of container IDs the host must skip during a
        loopback-delegated container/compose shutdown.

        Source of truth is ``ContainerShutdownMixin._current_container_ids``
        (also mixed into ``UPSGroupMonitor``). When the loopback host runs
        ``stop_containers`` or ``stop_compose``, these IDs are filtered out
        so Eneru's own container isn't killed mid-sequence. Returns an
        empty set on bare-metal (the mixin returns ``set()`` outside a
        container).
        """
        get_ids = getattr(self, "_current_container_ids", None)
        if get_ids is None:
            return set()
        try:
            return get_ids()
        except Exception:
            return set()

    def _loopback_umount_targets(self):
        """Return the unmount-mounts config for the local owner group.

        Loopback delegation: ``unmount_filesystems`` runs on the host with
        the operator's per-mount options. We pull the list straight from
        the local group's filesystems config — the operator declared it
        once in the normal place.
        """
        group = self.config.ups_groups[0] if self.config.ups_groups else None
        if group is None or not group.filesystems.unmount.enabled:
            return []
        return list(group.filesystems.unmount.mounts)

    def _execute_remote_pre_shutdown(
        self,
        server: RemoteServerConfig,
        *,
        collect_result: bool = False,
        deadline: Optional[float] = None,
    ):
        """Execute pre-shutdown commands on a remote server.

        Returns:
            True once the loop has iterated through every command.
            Per-command failures are logged and execution continues
            (best-effort) — there is no current code path that returns
            False.
        """
        if not server.pre_shutdown_commands:
            if collect_result:
                return RemotePreShutdownResult()
            return True

        display_name = server.name or server.host
        cmd_count = len(server.pre_shutdown_commands)
        result = RemotePreShutdownResult()

        # ELI5: two cooks shouting "timer started!" in the same kitchen tell you
        # nothing unless each one calls out their station. Parallel remote
        # threads interleave line-by-line (#128), so every per-server step line
        # carries [display_name] instead of relying on the header above it.
        self._log_message(
            f"  📋  [{display_name}] Executing {cmd_count} pre-shutdown command(s)..."
        )

        for idx, cmd_config in enumerate(server.pre_shutdown_commands, 1):
            if self._remote_deadline_exceeded(deadline):
                result.timed_out = True
                result.error = "remote shutdown deadline exceeded before pre-shutdown completed"
                self._log_message(
                    f"    ⚠️  [{display_name}] [{idx}/{cmd_count}] Skipping remaining "
                    "pre-shutdown commands: remote shutdown deadline exceeded"
                )
                break

            # Determine timeout
            timeout = cmd_config.timeout
            if timeout is None:
                timeout = server.command_timeout

            # Handle predefined action
            if cmd_config.action:
                action_name = cmd_config.action.lower()

                if action_name not in REMOTE_ACTIONS:
                    self._log_message(
                        f"    ⚠️  [{display_name}] [{idx}/{cmd_count}] Unknown action: "
                        f"{action_name} (skipping)"
                    )
                    result.failed += 1
                    continue

                # Validate stop_compose has path BEFORE rendering the
                # template; otherwise the precondition warning becomes
                # dead code; a future template change might let the bad
                # command slip through.
                if action_name == "stop_compose" and not cmd_config.path:
                    self._log_message(
                        f"    ⚠️  [{display_name}] [{idx}/{cmd_count}] stop_compose "
                        "requires 'path' parameter (skipping)"
                    )
                    result.failed += 1
                    continue

                # Get command template and substitute placeholders.
                # render_action() owns shell quoting for path-bearing
                # templates before they enter the remote shell.
                # v5.5: loopback delegate gets extra context — the
                # mandatory self-skip set so 'stop_containers' /
                # 'stop_compose' don't kill Eneru's own container, and
                # the umount targets serialized for 'unmount_filesystems'.
                skip_ids = ""
                umount_targets = ""
                if server.is_host_loopback is True:
                    skip_ids = ",".join(sorted(self._loopback_skip_ids()))
                    if action_name == "unmount_filesystems":
                        umount_targets = serialize_umount_targets(
                            self._loopback_umount_targets()
                        )
                elif action_name == "unmount_filesystems":
                    umount_targets = serialize_umount_targets(cmd_config.mounts)
                    if not umount_targets:
                        self._log_message(
                            f"    ⚠️  [{display_name}] [{idx}/{cmd_count}] "
                            "unmount_filesystems requires 'mounts' on regular "
                            "remote servers (skipping)"
                        )
                        result.failed += 1
                        continue
                command = render_action(
                    action_name,
                    timeout=timeout,
                    path=cmd_config.path or "",
                    skip_ids=skip_ids,
                    umount_targets=umount_targets,
                    use_sudo=self._step_use_sudo(server, cmd_config),
                )
                description = action_name

            # Handle custom command
            elif cmd_config.command:
                # use_sudo covers custom commands too (6.2): with a non-root
                # SSH user they almost always need root, and the operator
                # already declared the server as "sudo -n" in one place.
                # Idempotent: an explicit `sudo ...` is left as written. Only
                # the first command of a pipeline/list is prefixed, exactly
                # like the final shutdown_command.
                command = self._with_sudo(
                    cmd_config.command, self._step_use_sudo(server, cmd_config))
                # Truncate long commands for display
                if len(command) > 50:
                    description = command[:47] + "..."
                else:
                    description = command

            else:
                self._log_message(
                    f"    ⚠️  [{display_name}] [{idx}/{cmd_count}] No action or "
                    "command specified (skipping)"
                )
                result.failed += 1
                continue

            # Log what we're about to do
            self._log_message(
                f"    ➡️  [{display_name}] [{idx}/{cmd_count}] {description} "
                f"(timeout: {timeout}s)"
            )
            result.attempted += 1

            if self.config.behavior.dry_run:
                self._log_message(
                    f"    🧪  [{display_name}] [DRY-RUN] Would execute"
                )
                continue

            # Execute the command
            success, error_msg = self._run_remote_command(
                server, command, timeout, description, deadline=deadline
            )

            if success:
                self._log_message(
                    f"    ✅  [{display_name}] [{idx}/{cmd_count}] {description} completed"
                )
            else:
                result.failed += 1
                self._log_message(
                    f"    ⚠️  [{display_name}] [{idx}/{cmd_count}] {description} "
                    f"failed: {error_msg} (continuing)"
                )

            if self._remote_deadline_exceeded(deadline):
                result.timed_out = True
                result.error = "remote shutdown deadline exceeded during pre-shutdown"
                self._log_message(
                    f"    ⚠️  [{display_name}] Remote shutdown deadline reached "
                    "during pre-shutdown; final shutdown command will not be sent"
                )
                break

        if collect_result:
            return result
        return True

    def _shutdown_remote_server(
        self,
        server: RemoteServerConfig,
        *,
        deadline: Optional[float] = None,
    ) -> RemoteShutdownResult:
        """Shutdown a single remote server via SSH.

        Execution order:
        1. Execute pre_shutdown_commands (if any) - best effort
        2. Execute shutdown_command
        """
        display_name = server.name or server.host
        has_pre_cmds = len(server.pre_shutdown_commands) > 0
        result = RemoteShutdownResult(
            server=display_name,
            host=server.host,
            pre_commands=RemotePreShutdownResult(),
        )
        self._log_message(f"🌐  Initiating remote shutdown: {display_name} ({server.host})...")

        # Send notification for remote server shutdown start
        self._send_notification(
            f"🌐  **Remote Shutdown Starting:** {display_name}\n"
            f"Host: {server.host}",
            self.config.NOTIFY_INFO,
            category="shutdown",
        )

        # Execute pre-shutdown commands first. RESERVE enough of the phase
        # deadline for the final shutdown command (its own timeout + the SSH
        # overhead buffer _run_remote_command adds) so a slow pre-shutdown phase
        # can NEVER starve or skip the actual poweroff (H8). Pre-commands run
        # against the reduced deadline; the poweroff then runs against the full
        # deadline, spending the reserved slice. When the reserve exceeds the
        # whole budget, pre-commands get no time at all -- the poweroff wins.
        if has_pre_cmds:
            pre_deadline = deadline
            if deadline is not None:
                final_reserve = server.command_timeout + _SSH_OVERHEAD_BUFFER
                pre_deadline = deadline - final_reserve
            result.pre_commands = self._execute_remote_pre_shutdown(
                server, collect_result=True, deadline=pre_deadline,
            )

        # Skip the poweroff ONLY when the FULL phase deadline is blown. A
        # pre-phase that merely exhausted its reserved slice (pre_commands
        # .timed_out) must NOT cancel the poweroff -- reserving its budget is
        # precisely what stops the starvation H8 fixes. Pre-phase failures are
        # still recorded in result.pre_commands for the summary.
        if self._remote_deadline_exceeded(deadline):
            result.completed = False
            result.timed_out = True
            result.error = (
                result.pre_commands.error
                or "remote shutdown deadline exceeded before final shutdown command"
            )
            self._log_message(
                f"  ⚠️  Skipping final shutdown command for {display_name}: {result.error}"
            )
            return result

        # Execute final shutdown command
        shutdown_command = self._with_sudo(
            server.shutdown_command,
            server.use_sudo,
        )
        posix = (uses_posix_shell(server, detect=False)
                 if self.config.behavior.dry_run  # a dry run never SSHes
                 else self._remote_uses_posix_shell(
                     server, server.command_timeout, deadline))
        verbatim = "" if posix else " (as written: no POSIX shell)"
        self._log_message(
            f"  🔌  [{display_name}] Sending shutdown command{verbatim}: {shutdown_command}")

        if self.config.behavior.dry_run:
            result.shutdown_sent = True
            result.dry_run = True
            self._log_message(
                f"  🧪  [{display_name}] [DRY-RUN] Would send command "
                f"'{shutdown_command}' to {server.user}@{server.host}"
            )
            return result

        capture: Dict[str, Any] = {}
        success, error_msg = self._run_remote_command(
            server,
            shutdown_command,
            server.command_timeout,
            "shutdown",
            deadline=deadline,
            is_final_shutdown=True,
            capture=capture,
        )
        _record_command_output(result, capture)

        if success:
            result.shutdown_sent = True
            if error_msg:
                # F-077: sent but unconfirmed (SSH transport tore down before
                # the exit status came back). Treated as sent, not failed.
                self._log_message(
                    f"  ✅  {display_name} shutdown command sent ({error_msg})"
                )
            else:
                self._log_message(f"  ✅  {display_name} shutdown command sent successfully")
            # Per-server success used to fire a notification too; dropped in
            # v5.2 — the "Starting" notification is the per-server signal,
            # the aggregate "Sequence Complete" rolls up the result, and
            # journalctl carries the full trace. Failures still notify
            # because they're the only thing the user actually needs to act
            # on individually.
        else:
            result.error = error_msg
            self._log_message(
                f"  ❌  WARNING: Failed to execute shutdown command on {display_name}: {error_msg}"
            )
            self._send_notification(
                f"❌  **Remote Shutdown Failed:** {display_name}\n"
                f"Error: {error_msg}",
                self.config.NOTIFY_FAILURE,
                category="shutdown",
            )
        return result
