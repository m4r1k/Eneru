"""Remote SSH healthcheck runtime.

Healthchecks are advisory only. They use a dedicated harmless probe command
and never execute configured pre-shutdown or final shutdown commands.
"""

import json
import shlex
import time
import threading
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from eneru.config import Config, RemoteServerConfig
from eneru import utils as eneru_utils
from eneru.utils import run_command


REMOTE_HEALTH_DISABLED = "DISABLED"
REMOTE_HEALTH_UNKNOWN = "UNKNOWN"
REMOTE_HEALTH_CHECKING = "CHECKING"
REMOTE_HEALTH_HEALTHY = "HEALTHY"
REMOTE_HEALTH_DEGRADED = "DEGRADED"
REMOTE_HEALTH_FAILED = "FAILED"
SLOW_REMOTE_SSH_LOG_THRESHOLD_MS = 2_000
SLOW_REMOTE_SSH_LOG_RATE_LIMIT_SECONDS = 300.0
SLOW_REMOTE_SSH_NOTIFY_THRESHOLD_MS = 10_000
SLOW_REMOTE_SSH_NOTIFY_CONSECUTIVE_CHECKS = 3

DANGEROUS_PROBE_WORDS = (
    "shutdown", "poweroff", "reboot", "halt", "init 0",
    "systemctl poweroff", "systemctl reboot", "systemctl halt",
    "systemctl stop", "service stop",
    "docker stop", "docker compose stop", "docker-compose stop",
    "podman stop", "virsh shutdown", "virsh destroy",
    "qm shutdown", "qm stop", "pct shutdown", "pct stop",
)
# Reject any shell metacharacter that could chain a dangerous command
# after a benign-looking probe (e.g. ``true; shutdown -h now`` slips
# past the keyword list because the prefix is harmless). The probe runs
# inside ssh's remote shell, so command-line operators here apply
# remote-side. Newlines are rejected too — multi-line commands are
# almost certainly a misconfiguration in this context.
DANGEROUS_PROBE_CHARS = frozenset(";|&$`><()\n\r")
SSH_OPTIONS_WITH_SEPARATE_ARG = {
    "-B", "-b", "-c", "-D", "-E", "-e", "-F", "-I", "-i", "-J",
    "-L", "-l", "-m", "-O", "-o", "-p", "-Q", "-R", "-S", "-W", "-w",
}


@dataclass
class RemoteHealthStatus:
    """Latest healthcheck result for one configured remote server."""
    group: str
    server: str
    host: str
    user: str
    status: str = REMOTE_HEALTH_UNKNOWN
    last_checked_at: float = 0.0
    last_success_at: float = 0.0
    last_error: str = ""
    latency_ms: int = 0
    consecutive_failures: int = 0
    # v5.5: loopback delegate flag. When True, the manager runs an additional
    # host-identity probe and marks the entry FAILED on mismatch (the most
    # common cause being a missing /etc/machine-id bind-mount). Surfaced in
    # API/TUI so operators can tell the host-poweroff delegate apart from
    # regular remote targets.
    is_host_loopback: bool = False


def remote_health_sidecar_path(state_file_path: Path) -> Path:
    """Return the sidecar path paired with a daemon state file."""
    return state_file_path.with_name(state_file_path.name + ".remote-health.json")


def is_safe_probe_command(command: str) -> bool:
    """Reject obvious shutdown/control commands in remote health probes.

    Two-stage check:
      1. Reject shell metacharacters that could chain a dangerous
         command after a benign prefix.
      2. Reject any keyword from the dangerous-words list.
    """
    raw = (command or "").strip()
    if not raw:
        return False
    if any(ch in DANGEROUS_PROBE_CHARS for ch in raw):
        return False
    lowered = raw.lower()
    return not any(word in lowered for word in DANGEROUS_PROBE_WORDS)


def build_ssh_probe_command(server: RemoteServerConfig,
                            probe_command: str) -> List[str]:
    """Build the SSH argv for ``server`` running ``probe_command``.

    The ONE builder: remote health probes, the loopback identity probe,
    `eneru config check` and the real shutdown path (F-095) all use it, so
    they can never disagree about how ``ssh_options`` are split.

    Raises:
        ValueError: If ``server.ssh_options`` ends with a flag that
            requires a separate argument (e.g. trailing ``-i`` with no
            key path). Without this guard the ``-o ConnectTimeout=…``
            we append below would silently be consumed as the dangling
            flag's value.
    """
    ssh_cmd = ["ssh"]
    if server.ssh_key_path:
        ssh_cmd.extend(["-i", server.ssh_key_path])

    pending_arg = False
    for opt in [*eneru_utils.runtime_default_ssh_options(server.ssh_options),
                *server.ssh_options]:
        parts = opt.split(None, 1)
        if pending_arg:
            ssh_cmd.append(opt)
            pending_arg = False
        elif len(parts) == 2 and parts[0] in SSH_OPTIONS_WITH_SEPARATE_ARG:
            # R2-02: "-i /root/.ssh/key" typed as ONE list item (the natural
            # command-line habit) becomes two argv elements. Passed whole,
            # ssh would read the key path with a leading space and fall back
            # to its default keys -- every remote shutdown would fail.
            ssh_cmd.extend(parts)
        elif opt.startswith("-"):
            ssh_cmd.append(opt)
            pending_arg = opt in SSH_OPTIONS_WITH_SEPARATE_ARG
        else:
            ssh_cmd.extend(["-o", opt])
    if pending_arg:
        raise ValueError(
            f"remote server {server.name or server.host!r} has a dangling "
            f"SSH option in ssh_options ({ssh_cmd[-1]!r}); add the "
            f"argument as the next list entry"
        )
    ssh_cmd.extend([
        "-o", f"ConnectTimeout={server.connect_timeout}",
        "-o", "BatchMode=yes",
        # F-104: `--` ends option parsing, so a user/host that starts with
        # "-" (e.g. "-oProxyCommand=...") can never be read as an ssh option.
        "--",
        f"{server.user}@{server.host}",
        probe_command,
    ])
    return ssh_cmd


PROBE_EXPECT_MISSING = "probe output did not contain"
PROBE_UNSAFE = "unsafe probe_command rejected"


def run_remote_probe(server: RemoteServerConfig, probe_command: str,
                     expect: Optional[str] = None) -> Tuple[bool, str, int]:
    """Run one harmless remote health probe.

    Returns ``(success, error, latency_ms)``. With ``expect``, exit 0 is not
    enough: the output must also contain that text (``probe_expect``, for a
    CLI such as RouterOS that can exit 0 on a failed command). Whenever the
    device itself answered (not ssh's 255, a timeout or a missing client),
    a missing ``expect`` is reported as a probe problem, not an SSH one.
    """
    start = time.monotonic()
    exit_code, stdout, stderr = run_command(
        build_ssh_probe_command(server, probe_command),
        timeout=server.connect_timeout + 10,
    )
    latency_ms = int((time.monotonic() - start) * 1000)
    # Exit 0, or a non-zero exit that printed on stdout, came from the
    # device; a non-zero exit with nothing on stdout stays an SSH/local error.
    answered = exit_code == 0 or bool((stdout or "").strip())
    if (isinstance(expect, str) and expect and answered
            and exit_code not in (124, 127, 255)
            and expect not in (stdout or "")):
        got = next((line.strip() for line in f"{stdout or ''}\n{stderr or ''}"
                    .splitlines() if line.strip()), "no output")
        return False, (f"{PROBE_EXPECT_MISSING} {expect!r} "
                       f"(got: {got[:120]})"), latency_ms
    if exit_code == 0:
        return True, "", latency_ms
    if exit_code == 124:
        return False, f"timed out after {server.connect_timeout}s", latency_ms
    return False, stderr.strip() or f"exit code {exit_code}", latency_ms


# Issue #128: does the remote run our commands through a POSIX shell?
# ELI5: ask the device to say a password that is not written in the question.
# A POSIX shell assembles "eneru-" + "posix" + "-ok" and says it back; a router
# CLI answers "syntax error"; a Cisco CLI may echo the question, but the
# question never contains the assembled marker, so an echo cannot fake it.
# Only the OUTPUT decides: RouterOS returns exit 0 or 1 at random for failed
# commands (measured on 7.21), so exit codes are useless for this.
POSIX_DETECT_COMMAND = "sh -c 'printf eneru-%s-ok posix'"
POSIX_DETECT_MARKER = "eneru-posix-ok"


def _posix_probe(server: RemoteServerConfig, timeout: Optional[int] = None
                 ) -> Tuple[Optional[bool], str, bool]:
    """Run the detection probe once.

    Returns ``(verdict, ssh error text, answered)``. ``answered`` is True when
    SSH got through and the remote ran *something* (any exit but ssh's own
    255, a timeout or a missing ssh client): Windows answers on stderr only,
    which is not a verdict but still proves the machine is up.
    """
    try:
        cmd = build_ssh_probe_command(server, POSIX_DETECT_COMMAND)
    except ValueError as exc:
        return None, str(exc), False
    limit = timeout or server.connect_timeout + 10
    exit_code, stdout, stderr = run_command(cmd, timeout=limit)
    if exit_code == 124:
        return None, f"timed out after {limit}s", False
    # 127 is local only when run_command could not start ssh at all; ssh
    # forwards a remote command's own 127. 255 is ssh's own failure unless
    # the remote did print something.
    local_127 = exit_code == 127 and (stderr or "").startswith("Command not found:")
    if local_127 or (exit_code == 255 and not (stdout or "").strip()):
        return None, (stderr or "").strip() or f"exit code {exit_code}", False
    if POSIX_DETECT_MARKER in (stdout or ""):
        return True, "", True
    if (stdout or "").strip():
        return False, "", True
    return None, (stderr or "").strip() or f"no output (exit code {exit_code})", True


def detect_posix_shell(server: RemoteServerConfig,
                       timeout: Optional[int] = None) -> Optional[bool]:
    """Probe once: True = POSIX shell, False = no shell, None = unknown.

    False needs positive evidence: SSH connected and the device printed
    something on stdout other than the marker (RouterOS prints its errors
    there). ssh's own failures (255), timeouts (124), a missing ssh client
    (127) and empty output stay unknown, so a down or slow host never flips
    a POSIX server to verbatim mode.
    """
    verdict = _posix_probe(server, timeout)[0]
    if verdict is not None:
        server._detected_posix = verdict
    return verdict


def uses_posix_shell(server: RemoteServerConfig, *, detect: bool = True,
                     timeout: Optional[int] = None) -> bool:
    """The effective mode for ``server``: wrap commands in sh, or not.

    A loopback delegate is always POSIX (it is the Linux host). An explicit
    ``posix_shell`` wins. ``auto`` uses the cached detection, probing once
    when ``detect`` allows it; while still unknown it stays POSIX, which is
    exactly how every release before 6.2.2 behaved. A "no shell" verdict on
    an entry configured with ``use_sudo`` or ``pre_shutdown_commands`` (both
    need a shell) is overruled: the config wins, ``config check`` reports it.
    """
    if server.is_host_loopback is True:
        return True
    if isinstance(server.posix_shell, bool):
        return server.posix_shell
    if server._detected_posix is None and detect:
        detect_posix_shell(server, timeout)
    if server._detected_posix is False and posix_shell_conflict(server):
        return True
    return server._detected_posix is not False


def posix_shell_conflict(server: RemoteServerConfig) -> bool:
    """Detected "no shell", but the entry uses settings that need one."""
    return bool(server.posix_shell is None and server._detected_posix is False
                and (server.use_sudo is True or server.pre_shutdown_commands))


def posix_mode_label(server: RemoteServerConfig) -> str:
    """Short human label of the shell mode, for logs and config check."""
    if server.is_host_loopback is True or server.posix_shell is True:
        return "POSIX shell (configured)"
    if server.posix_shell is False:
        return "no POSIX shell (configured)"
    if server._detected_posix is True:
        return "POSIX shell (detected)"
    if server._detected_posix is False:
        return "no POSIX shell (detected)"
    return "POSIX shell (assumed: not detected)"


def run_server_probe(server: RemoteServerConfig,
                     default_probe: Optional[str]) -> Tuple[bool, str, int]:
    """Health probe for one server, honouring its shell mode.

    Order: the server's own ``probe_command``; else, while an ``auto``
    server is undetected or once it has no POSIX shell, the detection probe
    (which also warms the cache); else the global ``default_probe``. A
    shell-less server is healthy when it answers over SSH at all. An ``auto``
    server whose detection is inconclusive falls back to ``default_probe``,
    exactly as before 6.2.2.
    """
    if server.probe_command:
        # Validation already rejects an unsafe value; config check probes
        # even an invalid config, so refuse it here as well.
        if not is_safe_probe_command(server.probe_command):
            return False, PROBE_UNSAFE, 0
        return run_remote_probe(server, server.probe_command,
                                server.probe_expect)
    auto = server.posix_shell is None and server.is_host_loopback is not True
    if (auto and server._detected_posix is None) or not uses_posix_shell(
            server, detect=False):
        start = time.monotonic()
        verdict, error, answered = _posix_probe(server)
        latency_ms = int((time.monotonic() - start) * 1000)
        if auto and verdict is not None:
            server._detected_posix = verdict
        if server.posix_shell is False or (auto and verdict is False):
            return answered, ("" if answered else error), latency_ms
        if verdict is None and not answered:
            return False, error, latency_ms
    if default_probe is None:
        return False, "unsafe probe command rejected", 0
    # Only the probe's own latency: the one-off detection must not trip the
    # slow-SSH diagnostics.
    return run_remote_probe(server, default_probe)


def run_loopback_identity_probe(
    server: RemoteServerConfig,
) -> Tuple[bool, str, int]:
    """Run the host-identity probe for a loopback entry.

    Returns ``(matches, error_or_value, latency_ms)``. On success the second
    element is the empty string; on mismatch it's an operator-actionable
    error message that names the bind-mount as the most likely cause.
    """
    start = time.monotonic()
    # Defense in depth: the regular remote-health probe rejects unsafe
    # commands via is_safe_probe_command() before sending over SSH.
    # Apply the same safety check to host_identity_command so a
    # malicious or accidentally-pipelined value can't slip through.
    if not is_safe_probe_command(server.host_identity_command):
        latency_ms = int((time.monotonic() - start) * 1000)
        return False, (
            "identity probe rejected: host_identity_command is not a "
            "safe single-token command (no shell metacharacters allowed)"
        ), latency_ms
    exit_code, stdout, stderr = run_command(
        build_ssh_probe_command(server, server.host_identity_command),
        timeout=server.connect_timeout + 10,
    )
    latency_ms = int((time.monotonic() - start) * 1000)
    if exit_code != 0:
        if exit_code == 124:
            return False, f"identity probe timed out after {server.connect_timeout}s", latency_ms
        return False, (
            f"identity probe failed: {stderr.strip() or f'exit code {exit_code}'}"
        ), latency_ms
    actual = stdout.strip()
    lowered_actual = actual.lower()
    shutdown_markers = (
        "shutdown",
        "poweroff",
        "reboot",
        "halt",
        "broadcast message",
        "system is going down",
    )
    if any(marker in lowered_actual for marker in shutdown_markers):
        return False, (
            "identity probe returned shutdown-control output instead of "
            "machine-id. Most likely cause: the loopback key in "
            "authorized_keys uses command=, which makes sshd substitute "
            "Eneru's identity probe and generated shutdown actions with "
            "that forced command. Remove authorized_keys command= for "
            "Eneru loopback keys."
        ), latency_ms
    expected = (server.expected_host_identity or "").strip()
    if not expected:
        source = _describe_identity_source(server.host_identity_command)
        return False, (
            f"host identity unknown: container-side {source} was not "
            "readable at startup and no explicit expected_host_identity was "
            "configured. Bind-mount the host identity file read-only at the "
            "same container path or set expected_host_identity explicitly. "
            "If using the default /etc/machine-id path and it is empty on "
            "the host, initialize it with systemd-machine-id-setup."
        ), latency_ms
    if actual != expected:
        source = _describe_identity_source(server.host_identity_command)
        return False, (
            f"host identity mismatch: probe returned {actual!r} but expected "
            f"{expected!r}. Most likely cause: {source} is NOT bind-mounted "
            "from the host into the container, so Eneru sees a different "
            "identity locally than what the loopback SSH target reports. "
            "Fix: bind-mount the same host identity file read-only into the "
            "container or set expected_host_identity explicitly."
        ), latency_ms
    return True, "", latency_ms


def _identity_path_from_cat_command(command: str) -> Optional[Path]:
    """Return the local path for simple ``cat /path`` identity probes."""
    try:
        parts = shlex.split(command or "")
    except ValueError:
        return None
    if len(parts) != 2:
        return None
    if Path(parts[0]).name != "cat":
        return None
    path = Path(parts[1])
    if not path.is_absolute():
        return None
    return path


def _describe_identity_source(command: str) -> str:
    path = _identity_path_from_cat_command(command)
    if path is not None:
        return str(path)
    return "the configured host_identity_command output"


def _read_identity_from_path(path: Path) -> Optional[str]:
    try:
        return path.read_text(encoding="utf-8").strip() or None
    except OSError:
        return None


def _read_expected_identity_for_command(command: str) -> Optional[str]:
    """Auto-populate expected identity for simple local ``cat /path`` probes.

    The loopback identity check compares what SSH reports from the host with
    what the container can read locally. For the default ``cat /etc/machine-id``
    and for Alpine-style marker files mounted at the same path, reading the
    same local path gives the expected value without asking the operator to
    duplicate it in YAML. Non-``cat /path`` commands still require an explicit
    ``expected_host_identity`` because Eneru cannot safely infer their output.
    """
    path = _identity_path_from_cat_command(command)
    if path is None:
        return None
    return _read_identity_from_path(path)


class RemoteHealthManager:
    """Background healthcheck loop for one UPS/redundancy group."""

    def __init__(
        self,
        *,
        config: Config,
        group_label: str,
        servers: List[RemoteServerConfig],
        sidecar_path: Path,
        stop_event: threading.Event,
        log_fn: Callable[[str], None],
        notify_fn: Optional[Callable[[str, str], None]] = None,
        event_fn: Optional[Callable[[str, str, bool], None]] = None,
    ):
        self.config = config
        self.group_label = group_label
        self.servers = [s for s in servers if s.enabled]
        self.sidecar_path = Path(sidecar_path)
        self.stop_event = stop_event
        self._local_stop = threading.Event()
        self.log_fn = log_fn
        self.notify_fn = notify_fn
        self.event_fn = event_fn
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._notified_failed: Dict[str, bool] = {}
        self._last_slow_ssh_log_time: Dict[str, float] = {}
        self._slow_ssh_check_streak: Dict[str, int] = {}
        self._slow_ssh_notified: Dict[str, bool] = {}
        self._slow_ssh_log_threshold_ms = SLOW_REMOTE_SSH_LOG_THRESHOLD_MS
        self._slow_ssh_log_rate_limit_seconds = SLOW_REMOTE_SSH_LOG_RATE_LIMIT_SECONDS
        self._slow_ssh_notify_threshold_ms = SLOW_REMOTE_SSH_NOTIFY_THRESHOLD_MS
        self._slow_ssh_notify_consecutive_checks = (
            SLOW_REMOTE_SSH_NOTIFY_CONSECUTIVE_CHECKS
        )
        self._event_fn_logged_failure = False
        probe = config.remote_health.probe_command
        self._validated_probe_command = probe if is_safe_probe_command(probe) else None
        self._sidecar_write_failed_paths = set()
        initial = REMOTE_HEALTH_UNKNOWN if config.remote_health.enabled else REMOTE_HEALTH_DISABLED
        # v5.5: auto-populate expected_host_identity on any loopback entry that
        # didn't get one from config. Reads /etc/machine-id from the container
        # filesystem — when the operator bind-mounts the host's machine-id at
        # the same path, this value matches what the loopback SSH probe will
        # return. Missing or mismatching → identity probe fails closed with a
        # clear bind-mount hint.
        for server in self.servers:
            if server.is_host_loopback is True and not server.expected_host_identity:
                server.expected_host_identity = _read_expected_identity_for_command(
                    server.host_identity_command
                )
        self._statuses: Dict[str, RemoteHealthStatus] = {
            self._key(server): RemoteHealthStatus(
                group=group_label,
                server=server.name or server.host,
                host=server.host,
                user=server.user,
                status=initial,
                is_host_loopback=server.is_host_loopback is True,
            )
            for server in self.servers
        }
        for server in self.servers:
            if server.is_host_loopback is True:
                self._statuses[self._key(server)].status = REMOTE_HEALTH_UNKNOWN

    def _stopping(self) -> bool:
        """True when daemon shutdown or a manager-local reload stop fired."""
        return self.stop_event.is_set() or self._local_stop.is_set()

    def _wait(self, timeout: float) -> bool:
        """Wait for either stop signal, polling local reload stops promptly."""
        if self._local_stop.is_set():
            return True
        remaining = max(0.0, float(timeout))
        while remaining > 0:
            slice_ = min(5.0, remaining)
            if self.stop_event.wait(slice_):
                return True
            if self._local_stop.is_set():
                return True
            remaining -= slice_
        return self._local_stop.is_set()

    def start(self) -> None:
        """Start the background healthcheck loop if configured."""
        has_loopback = any(s.is_host_loopback is True for s in self.servers)
        if ((not self.config.remote_health.enabled) and not has_loopback) or not self.servers:
            self._write_sidecar()
            return
        if self._thread is not None:
            return
        self._local_stop.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            name=f"remote-health-{self.group_label}",
            daemon=True,
        )
        self._thread.start()

    def stop(self, timeout: int = 5) -> None:
        """Signal the healthcheck loop and wait briefly for it to exit."""
        self._local_stop.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            if not self._thread.is_alive():
                self._thread = None

    def snapshot(self) -> List[dict]:
        """Return JSON-serializable health rows."""
        with self._lock:
            return [asdict(row) for row in self._statuses.values()]

    def check_once(self) -> List[dict]:
        """Run one healthcheck cycle synchronously."""
        has_loopback = any(s.is_host_loopback is True for s in self.servers)
        if not self.config.remote_health.enabled and not has_loopback:
            self._write_sidecar()
            return self.snapshot()
        for server in self.servers:
            if self._stopping():
                break
            if not self.config.remote_health.enabled and server.is_host_loopback is not True:
                continue
            self._check_server(server)
        self._write_sidecar()
        return self.snapshot()

    def _run_loop(self) -> None:
        if self.config.remote_health.startup_check:
            self.check_once()
        interval = max(60, int(self.config.remote_health.interval))
        while not self._wait(interval):
            self.check_once()

    def _check_server(self, server: RemoteServerConfig) -> None:
        key = self._key(server)
        with self._lock:
            row = self._statuses[key]
            previous = row.status
            row.status = REMOTE_HEALTH_CHECKING
        self._write_sidecar()

        probe = self._validated_probe_command
        if server.is_host_loopback is True and not (server.expected_host_identity or "").strip():
            source = _describe_identity_source(server.host_identity_command)
            success, error, latency_ms = False, (
                f"host identity unknown: container-side {source} was not "
                "readable at startup and no explicit expected_host_identity was "
                "configured. Bind-mount the host identity file read-only at the "
                "same container path or set expected_host_identity explicitly. "
                "If using the default /etc/machine-id path and it is empty on "
                "the host, initialize it with systemd-machine-id-setup."
            ), 0
        elif (probe is None and not server.probe_command
              and uses_posix_shell(server, detect=False)):
            success, error, latency_ms = False, "unsafe probe command rejected", 0
        else:
            # Per-server probe_command / shell-less detection first (#128).
            success, error, latency_ms = run_server_probe(server, probe)
            # v5.5: loopback entries get an extra host-identity step. The
            # standard probe proves SSH reachability; identity proves we're
            # actually talking to the host Eneru is meant to control.
            if success and server.is_host_loopback is True:
                id_ok, id_err, id_latency = run_loopback_identity_probe(server)
                latency_ms += id_latency
                if not id_ok:
                    success = False
                    error = id_err

        now = time.time()
        with self._lock:
            row = self._statuses[key]
            row.last_checked_at = now
            row.latency_ms = latency_ms
            if success:
                row.status = REMOTE_HEALTH_HEALTHY
                row.last_success_at = now
                row.last_error = ""
                row.consecutive_failures = 0
            else:
                row.consecutive_failures += 1
                row.last_error = error
                threshold = max(1, int(self.config.remote_health.failure_threshold))
                row.status = (
                    REMOTE_HEALTH_FAILED
                    if row.consecutive_failures >= threshold
                    else REMOTE_HEALTH_DEGRADED
                )
            current = row.status

        display = server.name or server.host
        notification_sent = False
        if success and previous in (REMOTE_HEALTH_DEGRADED, REMOTE_HEALTH_FAILED):
            self._notified_failed[key] = False
            self.log_fn(f"✅  Remote health recovered: {display}")
            if (
                previous == REMOTE_HEALTH_FAILED
                and self.config.remote_health.notify_on_recovery
                and self.notify_fn
            ):
                self.notify_fn(
                    f"✅  **Remote SSH Health Recovered:** {display}\nHost: {server.host}",
                    self.config.NOTIFY_SUCCESS,
                )
                notification_sent = True
        elif current == REMOTE_HEALTH_FAILED and not self._notified_failed.get(key):
            self._notified_failed[key] = True
            if server.is_host_loopback is True:
                # v5.5: loud, operator-actionable message — the loopback IS
                # the host-poweroff contract; if it's broken, Eneru cannot
                # honor a power-loss shutdown in full.
                self.log_fn(
                    f"❌  HOST LOOPBACK FAILED: {display} ({server.host}). "
                    "Under a real power outage, we cannot shut the system "
                    f"down. Cause: {error}"
                )
                if self.config.remote_health.notify_on_failure and self.notify_fn:
                    self.notify_fn(
                        f"🚨  **Host Loopback FAILED:** {display}\n"
                        f"Host: {server.host}\n"
                        "**Under a real power outage, we cannot shut the "
                        "system down.**\n"
                        f"Cause: {error}",
                        self.config.NOTIFY_FAILURE,
                    )
                    notification_sent = True
            else:
                self.log_fn(f"❌  Remote health failed: {display}: {error}")
                if self.config.remote_health.notify_on_failure and self.notify_fn:
                    self.notify_fn(
                        f"❌  **Remote SSH Health Failed:** {display}\n"
                        f"Host: {server.host}\nError: {error}",
                        self.config.NOTIFY_FAILURE,
                    )
                    notification_sent = True
        elif not success and current != REMOTE_HEALTH_FAILED:
            # L8: only log "degraded" while the server is genuinely degrading
            # (before it crosses failure_threshold). Once it's FAILED we've
            # already logged + notified the failure; relabelling it "degraded"
            # on every subsequent poll is noisy and misleading.
            self.log_fn(f"⚠️  Remote health degraded: {display}: {error}")
        self._record_slow_ssh_response(
            key, display, server.host, latency_ms, success, now,
        )
        self._record_status_transition(
            previous, current, display, server.host, row.last_error,
            notification_sent,
        )

    def _record_slow_ssh_response(
        self,
        key: str,
        display: str,
        host: str,
        latency_ms: int,
        success: bool,
        now: float,
    ) -> None:
        """Record successful-but-slow SSH health probes as diagnostics."""
        if not success:
            self._slow_ssh_check_streak[key] = 0
            self._slow_ssh_notified[key] = False
            return
        # N1: if THIS call is about to record the sustained-slow event below,
        # skip the transient one so a single cycle doesn't write two
        # REMOTE_SSH_SLOW_RESPONSE rows for the same probe.
        will_record_sustained = (
            latency_ms >= self._slow_ssh_notify_threshold_ms
            and not self._slow_ssh_notified.get(key, False)
            and (self._slow_ssh_check_streak.get(key, 0) + 1)
            >= self._slow_ssh_notify_consecutive_checks
        )
        if (latency_ms >= self._slow_ssh_log_threshold_ms
                and not will_record_sustained):
            last_log = self._last_slow_ssh_log_time.get(key, 0.0)
            if (
                last_log == 0.0
                or now - last_log >= self._slow_ssh_log_rate_limit_seconds
            ):
                detail = (
                    f"{self.group_label}/{display} ({host}) slow SSH "
                    f"response: {latency_ms} ms"
                )
                self.log_fn(
                    f"⚠️  Slow remote SSH response from {display} "
                    f"({host}): {latency_ms} ms"
                )
                self._record_event(
                    "REMOTE_SSH_SLOW_RESPONSE", detail, notification_sent=False,
                )
                self._last_slow_ssh_log_time[key] = now

        if latency_ms >= self._slow_ssh_notify_threshold_ms:
            self._slow_ssh_check_streak[key] = (
                self._slow_ssh_check_streak.get(key, 0) + 1
            )
        else:
            self._slow_ssh_check_streak[key] = 0
            self._slow_ssh_notified[key] = False
            return

        if (
            not self._slow_ssh_notified.get(key, False)
            and self._slow_ssh_check_streak[key]
            >= self._slow_ssh_notify_consecutive_checks
        ):
            if self.notify_fn:
                self.notify_fn(
                    f"⚠️  **Sustained slow remote SSH responses:** {display}\n"
                    f"Host: {host}\n"
                    f"Latest probe took {latency_ms / 1000:.1f}s. "
                    f"Threshold: {self._slow_ssh_notify_threshold_ms / 1000:.1f}s "
                    f"for {self._slow_ssh_notify_consecutive_checks} "
                    "consecutive checks.",
                    self.config.NOTIFY_WARNING,
                )
            detail = (
                f"{self.group_label}/{display} ({host}) sustained slow SSH "
                f"responses: latest {latency_ms} ms; threshold "
                f"{self._slow_ssh_notify_threshold_ms} ms for "
                f"{self._slow_ssh_notify_consecutive_checks} consecutive checks"
            )
            self._record_event(
                "REMOTE_SSH_SLOW_RESPONSE",
                detail,
                notification_sent=self.notify_fn is not None,
            )
            self._slow_ssh_notified[key] = True

    def _record_status_transition(
        self,
        previous: str,
        current: str,
        display: str,
        host: str,
        error: str,
        notification_sent: bool,
    ) -> None:
        """Record stable remote-health state transitions in SQLite events."""
        if self.event_fn is None or current == previous:
            return
        # UNKNOWN -> HEALTHY is the initial baseline after daemon start,
        # not an operator-actionable state change. Keep startup failures
        # and later recoveries visible, but do not add a healthy row next
        # to every DAEMON_START event.
        if previous == REMOTE_HEALTH_UNKNOWN and current == REMOTE_HEALTH_HEALTHY:
            return
        detail = (
            f"{self.group_label}/{display} ({host}) "
            f"{previous} -> {current}"
        )
        if error:
            detail = f"{detail}: {error}"
        self._record_event(
            f"REMOTE_HEALTH_{current}",
            detail,
            notification_sent,
        )

    def _record_event(
        self,
        event_type: str,
        detail: str,
        notification_sent: bool,
    ) -> None:
        """Record a remote-health diagnostic event without affecting probes."""
        if self.event_fn is None:
            return
        try:
            self.event_fn(
                event_type,
                detail,
                notification_sent,
            )
        except Exception as exc:
            # Stats are diagnostic only. A broken DB must not affect
            # health checks or the shutdown path. Log the first failure
            # so a silently broken events table leaves a journal trail.
            if not self._event_fn_logged_failure:
                self._event_fn_logged_failure = True
                self.log_fn(
                    f"⚠️  Remote health stats event failed (further "
                    f"failures will be silent): {exc}"
                )

    def _write_sidecar(self) -> None:
        try:
            payload = {
                "group": self.group_label,
                "generated_at": time.time(),
                "servers": self.snapshot(),
            }
            self.sidecar_path.parent.mkdir(parents=True, exist_ok=True)
            eneru_utils.write_side_file(
                self.sidecar_path, json.dumps(payload, sort_keys=True))
        except Exception as exc:
            key = str(self.sidecar_path)
            if key not in self._sidecar_write_failed_paths:
                self._sidecar_write_failed_paths.add(key)
                self.log_fn(
                    f"⚠️  Failed to write remote health sidecar for "
                    f"{self.group_label} at {self.sidecar_path}: {exc}"
                )

    @staticmethod
    def _key(server: RemoteServerConfig) -> str:
        return f"{server.user}@{server.host}:{server.name or server.host}"


def read_remote_health_sidecar(path: Path) -> List[dict]:
    """Read remote-health sidecar rows, returning an empty list on failure."""
    try:
        data = json.loads(Path(path).read_text())
        rows = data.get("servers", [])
        return rows if isinstance(rows, list) else []
    except Exception:
        return []
