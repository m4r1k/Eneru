"""Libvirt virtual-machine shutdown phase."""

import time
from typing import List

from eneru.utils import command_exists, run_command


class VMShutdownMixin:
    """Mixin: graceful libvirt VM shutdown with force-destroy fallback."""

    def _shutdown_vms(self):
        """Shutdown all libvirt virtual machines."""
        if not self.config.virtual_machines.enabled:
            return

        self._log_message("🖥️  Shutting down all libvirt virtual machines...")

        if not command_exists("virsh"):
            self._log_message("  ℹ️  virsh not available, skipping VM shutdown")
            return

        exit_code, stdout, _ = run_command(["virsh", "list", "--name", "--state-running"])
        if exit_code != 0:
            self._log_message("  ⚠️  Failed to get VM list")
            return

        running_vms = [vm.strip() for vm in stdout.strip().split('\n') if vm.strip()]

        if not running_vms:
            self._log_message("  ℹ️  No running VMs found")
            return

        for vm in running_vms:
            self._log_message(f"  ⏹️  Shutting down VM: {vm}")
            if self.config.behavior.dry_run:
                self._log_message(f"  🧪  [DRY-RUN] Would shutdown VM: {vm}")
            else:
                exit_code, stdout, stderr = run_command(["virsh", "shutdown", vm])
                if stdout.strip():
                    self._log_message(f"    {stdout.strip()}")
                # ISS-040: surface a failed shutdown request instead of moving on
                # silently (the wait loop below still force-destroys stragglers).
                if exit_code != 0:
                    detail = f": {stderr.strip()[:200]}" if stderr and stderr.strip() else ""
                    self._log_message(
                        f"  ⚠️  virsh shutdown {vm} returned rc={exit_code}{detail}"
                    )

        if self.config.behavior.dry_run:
            return

        max_wait = self.config.virtual_machines.max_wait
        self._log_message(f"  ⏳  Waiting up to {max_wait}s for VMs to shutdown gracefully...")
        wait_interval = 5
        # L7 / CodeRabbit: use a WALL-CLOCK deadline rather than counting only
        # the sleeps. The old loop advanced `time_waited` only after sleep(), so
        # each (bounded) `virsh list` poll plus a wedged libvirtd could stretch
        # the phase well past max_wait. A monotonic deadline charges poll time
        # too, and each poll/sleep is capped to the remaining budget so the whole
        # graceful wait is bounded by ~max_wait before force-destroy/poweroff.
        deadline = time.monotonic() + max_wait
        # Seed with the originally-running list so a transient virsh
        # failure on the first poll doesn't make the loop think the VMs
        # are gone (empty stdout would otherwise yield remaining_vms=[]
        # and skip force-destroy).
        remaining_vms: List[str] = list(running_vms)

        while time.monotonic() < deadline:
            remaining_budget = max(1, int(deadline - time.monotonic()))
            exit_code, stdout, _ = run_command(
                ["virsh", "list", "--name", "--state-running"],
                timeout=min(wait_interval, remaining_budget),
            )
            if exit_code != 0:
                # libvirtd may be wedged or restarting. Don't trust empty
                # stdout as "all stopped" — keep the previous remaining_vms
                # and re-poll on the next interval. If we exhaust max_wait
                # the force-destroy pass below still fires.
                self._log_message(
                    f"  ⚠️  virsh list returned exit {exit_code}; keeping prior "
                    f"remaining VMs ({len(remaining_vms)}) and retrying"
                )
            else:
                still_running = set(vm.strip() for vm in stdout.strip().split('\n') if vm.strip())
                remaining_vms = [vm for vm in running_vms if vm in still_running]

                if not remaining_vms:
                    self._log_message("  ✅  All VMs stopped gracefully.")
                    break

                self._log_message(f"  🕒  Still waiting for: {' '.join(remaining_vms)}")

            # Sleep only up to the remaining budget so we don't overshoot.
            time.sleep(max(0, min(wait_interval, deadline - time.monotonic())))

        # F-025: the wait loop can exit on the deadline the instant AFTER the VMs
        # actually stopped, or with a stale `remaining_vms` left over from a
        # failed final poll. Either way, force-destroying now would fire
        # `virsh destroy` at already-stopped domains and then warn "possibly still
        # running" about VMs that shut down cleanly. ELI5: before you kick down a
        # door, knock once more -- the person may have already walked out. Do one
        # last bounded poll and trust a SUCCESSFUL result to prune the list; if
        # the poll fails we keep the prior list (better a redundant destroy than a
        # missed one).
        if remaining_vms:
            # cubic P2 (round 1): cap this poll to the remaining budget like
            # every poll in the loop above — a fixed 5s here could stretch the
            # phase past max_wait, the exact overrun the deadline design
            # prevents. The max(1, ...) floor keeps the knock-once-more useful
            # when the deadline is already spent (the common case: the loop
            # exited BY the deadline), while bounding the overshoot to ~1s.
            rc_final, stdout_final, _ = run_command(
                ["virsh", "list", "--name", "--state-running"],
                timeout=min(
                    wait_interval,
                    max(1, int(deadline - time.monotonic()))),
            )
            if rc_final == 0:
                still_running = set(
                    vm.strip() for vm in stdout_final.strip().split('\n') if vm.strip()
                )
                remaining_vms = [vm for vm in running_vms if vm in still_running]
                if not remaining_vms:
                    self._log_message(
                        "  ✅  All VMs stopped gracefully (confirmed on final poll)."
                    )

        destroy_failures = 0
        if remaining_vms:
            self._log_message("  ⚠️  Timeout reached. Force destroying remaining VMs.")
            for vm in remaining_vms:
                self._log_message(f"  ⚡  Force destroying VM: {vm}")
                rc, _, err = run_command(["virsh", "destroy", vm])
                if rc != 0:
                    destroy_failures += 1
                    detail = f": {err.strip()[:200]}" if err and err.strip() else ""
                    self._log_message(
                        f"  ⚠️  virsh destroy {vm} returned rc={rc}{detail}"
                    )

        # ISS-040 follow-up: don't claim ✅ when a force-destroy failed --
        # those VMs may still be running (graceful-path rc failures are
        # covered by the destroy pass, so only destroy failures count here).
        if destroy_failures:
            self._log_message(
                f"  ⚠️  VM shutdown finished with {destroy_failures} VM(s) "
                f"possibly still running"
            )
        else:
            self._log_message("  ✅  All VMs shutdown complete")
