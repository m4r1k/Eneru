"""Embedded HTTP API, Prometheus endpoint, and (v6.0) authenticated write-path."""

import collections
import importlib.resources
import ipaddress
import json
import math
import os
import re
import secrets
import socket
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple
from urllib.parse import parse_qs, unquote, urlparse

from eneru import nut_control as nutctl
from eneru import self_test as selftest
from eneru.auth import AuthStore, auth_is_active
from eneru.status import (
    HISTORY_METRICS,
    collect_status,
    config_summary,
    find_status,
    live_remote_health,
    monitor_status,
    power_series,
    query_events,
    query_history,
    readiness,
)

# Cap request bodies so a hostile/accidental huge POST can't exhaust memory in a
# handler thread. Auth + control payloads are tiny JSON objects.
MAX_BODY_BYTES = 64 * 1024
# Bound reads from each client socket. Without this, a client can declare a
# small Content-Length and drip bytes forever, pinning a non-daemon handler.
# F-046: this same value is the per-connection IDLE timeout for HTTP/1.1
# keep-alive (set as EneruAPIHandler.timeout). An idle keep-alive connection is
# dropped after this many seconds so its worker thread returns to the pool
# instead of a slow/idle client holding it open indefinitely (slowloris).
REQUEST_READ_TIMEOUT_SECONDS = 10

# F-018: cap the number of requests actively being PROCESSED at once. The
# monitor is the process that must react to power events, so the API's
# ThreadingHTTPServer (one thread per connection, unbounded) is a
# resource-exhaustion DoS surface — a flood of connections could spawn threads
# without limit and starve the monitor. 32 comfortably covers a handful of
# dashboards + Prometheus scrapers while capping the blast radius.
MAX_CONCURRENT_REQUESTS = 32

# cubic P1 (round 1): the request semaphore above bounds PROCESSING, but the
# stock ThreadingHTTPServer still spawned one thread per accepted CONNECTION
# before that gate, so a connection flood piled up blocked threads without
# limit. This caps the connections themselves (see _BoundedThreadingHTTPServer)
# — above the cap, new sockets are closed on accept without spawning a thread.
# 2× the processing cap leaves headroom for idle keep-alive connections
# (dashboards hold ~1-2 each) without letting a flood grow the thread count.
MAX_CONCURRENT_CONNECTIONS = 64

# F-100 (slowloris): REQUEST_READ_TIMEOUT_SECONDS bounds each socket read, so
# a client dripping one header byte every few seconds never trips it and holds
# its connection (and slot) forever. This is a WALL-CLOCK bound on reading the
# request line + headers of one request; past it the read side is shut down
# and the connection closed. It is longer than the idle timeout so a
# keep-alive client that waits (up to the idle timeout) and then sends a
# normal request is never cut off.
REQUEST_HEADER_DEADLINE_SECONDS = 20
# F-100: connection slots only loopback peers may use, so the container
# HEALTHCHECK (127.0.0.1) and local probes still get in while a remote flood
# holds every other slot.
LOOPBACK_RESERVED_CONNECTIONS = 8

# ISS-032: in-memory per-source-IP login throttle. After LOGIN_FAIL_MAX failed
# logins within LOGIN_FAIL_WINDOW_SECONDS, further attempts from that IP get 429
# until the window rolls off. Process-local (resets on restart) and best-effort
# behind a reverse proxy (keyed on the immediate peer), but it defeats naive
# credential-stuffing against the daemon's own listener.
LOGIN_FAIL_WINDOW_SECONDS = 60
LOGIN_FAIL_MAX = 10
# Cap the tracked-IP table so an attacker rotating source IPs (direct bind)
# can't grow it without bound; on overflow we sweep expired buckets, then evict
# the oldest-inserted key.
LOGIN_TRACKED_IPS_MAX = 4096
_login_failures: "collections.OrderedDict[str, collections.deque]" = (
    collections.OrderedDict()
)
_login_failures_lock = threading.Lock()

# F-040: the per-IP throttle above is defeated by an attacker rotating source
# IPs (an IPv6 /64 hands out billions), which evicts the targeted buckets and
# never accumulates per-IP failures. A GLOBAL sliding-window ceiling backstops
# it: once total failed logins across ALL sources exceed the threshold within
# the window, every login attempt is throttled until the window drains. The
# window is deliberately wider and the count higher than the per-IP knobs so a
# handful of fat-fingered operators can't trip it, but a distributed brute
# force (which the per-IP guard can't see) does.
GLOBAL_LOGIN_FAIL_WINDOW_SECONDS = 300
GLOBAL_LOGIN_FAIL_MAX = 100
_global_login_failures: "collections.deque" = collections.deque()
_global_login_lock = threading.Lock()


def _global_login_is_blocked() -> bool:
    """True if global failed logins in the window exceed the ceiling."""
    now = time.monotonic()
    cutoff = now - GLOBAL_LOGIN_FAIL_WINDOW_SECONDS
    with _global_login_lock:
        while _global_login_failures and _global_login_failures[0] < cutoff:
            _global_login_failures.popleft()
        return len(_global_login_failures) >= GLOBAL_LOGIN_FAIL_MAX


def _global_login_record_failure() -> bool:
    """Record one global failure and report entry into throttled state."""
    now = time.monotonic()
    cutoff = now - GLOBAL_LOGIN_FAIL_WINDOW_SECONDS
    with _global_login_lock:
        while _global_login_failures and _global_login_failures[0] < cutoff:
            _global_login_failures.popleft()
        _global_login_failures.append(now)
        return len(_global_login_failures) == GLOBAL_LOGIN_FAIL_MAX


def _login_is_blocked(ip: str) -> bool:
    """True if ``ip`` has hit the failed-login cap within the window."""
    now = time.monotonic()
    cutoff = now - LOGIN_FAIL_WINDOW_SECONDS
    with _login_failures_lock:
        dq = _login_failures.get(ip)
        if not dq:
            return False
        while dq and dq[0] < cutoff:
            dq.popleft()
        if not dq:
            _login_failures.pop(ip, None)
            return False
        return len(dq) >= LOGIN_FAIL_MAX


def _login_record_failure(ip: str) -> bool:
    """Record one source failure and report entry into throttled state."""
    now = time.monotonic()
    cutoff = now - LOGIN_FAIL_WINDOW_SECONDS
    with _login_failures_lock:
        dq = _login_failures.get(ip)
        if dq is None:
            # Bound memory: sweep fully-expired buckets, then evict oldest.
            if len(_login_failures) >= LOGIN_TRACKED_IPS_MAX:
                for k in [k for k, d in _login_failures.items()
                          if not d or d[-1] < cutoff]:
                    _login_failures.pop(k, None)
                while len(_login_failures) >= LOGIN_TRACKED_IPS_MAX:
                    _login_failures.popitem(last=False)
            dq = _login_failures[ip] = collections.deque()
        while dq and dq[0] < cutoff:
            dq.popleft()
        dq.append(now)
        return len(dq) == LOGIN_FAIL_MAX


def _login_clear(ip: str) -> None:
    with _login_failures_lock:
        _login_failures.pop(ip, None)

# Dashboard static assets (served from the eneru.web package). Only these flat
# names are servable; the strict name check below makes path traversal impossible.
_STATIC_CONTENT_TYPES = {
    ".html": "text/html",
    ".js": "application/javascript",
    ".css": "text/css",
    ".svg": "image/svg+xml",
}
_DASHBOARD_INDEX = "index.html"
# A conservative charset for upsrw values. NUT values are short tokens (numbers,
# enum words, voltages). upscmd/upsrw run via execve arg lists (never a shell),
# so this is defense-in-depth, not the only barrier — but it keeps control
# characters and shell-ish metacharacters out of the value entirely.
# L9: anchor with \Z, not $ -- in Python `$` also matches just before a trailing
# newline, so "value\n" would slip through this defense-in-depth charset filter.
_SAFE_NUT_VALUE = re.compile(r"\A[A-Za-z0-9 ._:+%/,\-]{1,64}\Z")
# Strict response content-type whitelist (avoids header injection if a route
# ever passes user data through as a content type).
_CONTENT_TYPE_HEADERS = {
    "application/json": "application/json; charset=utf-8",
    "text/plain": "text/plain; charset=utf-8",
    "text/html": "text/html; charset=utf-8",
    "application/javascript": "application/javascript; charset=utf-8",
    "text/css": "text/css; charset=utf-8",
    "image/svg+xml": "image/svg+xml; charset=utf-8",
}

# Serialize control writes per UPS so two concurrent requests can't race an
# INSTCMD/SET against the same device. The lock lives in nut_control so the
# scheduled self-test path (monitor) shares the SAME lock identity as the API
# control routes — keyed by the real NUT name.
from eneru.nut_control import command_lock as _ups_lock  # noqa: E402


class APIBadRequest(ValueError):
    """Raised when a client supplies invalid API query parameters."""


class APIPayloadTooLarge(ValueError):
    """Raised when a request body exceeds ``MAX_BODY_BYTES`` (413)."""


class APIUnauthorized(Exception):
    """Raised when a request needs a credential it didn't supply (401)."""


class APIForbidden(Exception):
    """Raised when an action is not permitted in the current mode (403)."""


class APILengthRequired(Exception):
    """Raised when a body request omits Content-Length, e.g. a chunked
    Transfer-Encoding the fixed-length reader can't bound (411)."""


class SessionManager:
    """In-memory bearer-token sessions with a fixed TTL.

    Sessions are deliberately ephemeral — they live only in the daemon process
    and are lost on restart. That's fine: a restart just means re-login, and
    keeping them out of the DB avoids persisting anything credential-like.
    Thread-safe because requests run on ThreadingHTTPServer worker threads.
    """

    def __init__(self, ttl_seconds: int) -> None:
        self._ttl = max(1, int(ttl_seconds))
        self._sessions: Dict[str, Tuple[Dict[str, Any], float]] = {}
        self._lock = threading.Lock()

    @property
    def ttl(self) -> int:
        """The effective session lifetime in seconds (clamped to >= 1)."""
        return self._ttl

    def create(self, principal: Dict[str, Any]) -> str:
        token = secrets.token_urlsafe(32)
        now = time.time()
        expiry = now + self._ttl
        with self._lock:
            # Opportunistically drop expired entries so repeated logins don't
            # grow the table unbounded (they're only otherwise reaped on reuse).
            expired = [t for t, (_p, e) in self._sessions.items() if e < now]
            for t in expired:
                del self._sessions[t]
            self._sessions[token] = (principal, expiry)
        return token

    def validate(self, token: str) -> Optional[Dict[str, Any]]:
        now = time.time()
        if not isinstance(token, str) or not token:
            return None
        # ISS-061: match the presented token against stored session tokens with
        # secrets.compare_digest so validation time doesn't leak how much of a
        # guessed token was correct (a plain dict lookup compares byte-by-byte
        # and short-circuits). Compare on BYTES: compare_digest raises
        # TypeError on an ASCII-vs-non-ASCII str comparison, and header values
        # decode to arbitrary latin-1, so a str compare would turn a bad token
        # into a 500 instead of a clean 401. Session counts are tiny, so the
        # linear scan is negligible.
        token_bytes = token.encode("utf-8", "surrogatepass")
        with self._lock:
            matched_key = None
            for stored in self._sessions:
                if secrets.compare_digest(
                    stored.encode("utf-8", "surrogatepass"), token_bytes
                ):
                    matched_key = stored
                    break
            if matched_key is None:
                return None
            principal, expiry = self._sessions[matched_key]
            if expiry < now:
                del self._sessions[matched_key]
                return None
            return principal

    def invalidate(self, token: str) -> bool:
        with self._lock:
            return self._sessions.pop(token, None) is not None


API_ENDPOINTS = (
    {"path": "/health", "description": "Liveness probe"},
    {"path": "/ready", "description": "Readiness probe with fresh UPS data"},
    {"path": "/metrics", "description": "Prometheus metrics when enabled"},
    {"path": "/api/v1", "description": "API endpoint index"},
    {"path": "/api/v1/ups", "description": "Current UPS and redundancy status"},
    {"path": "/api/v1/ups/{name}", "description": "Current status for one UPS"},
    {
        "path": "/api/v1/ups/{name}/history",
        "description": "SQLite metric history for one UPS",
        "query": {
            # Derived from HISTORY_METRICS so discovery never drifts from the
            # set /history actually accepts.
            "metric": "|".join(HISTORY_METRICS),
            "from": "unix timestamp",
            "to": "unix timestamp",
        },
    },
    {
        "path": "/api/v1/events",
        "description": "Recent SQLite event rows",
        "query": {
            "limit": "1..10000",
            "verbosity": "0..2",
            "from": "unix timestamp",
            "to": "unix timestamp",
            "before": "unix timestamp cursor",
            "beforeSource": "source-qualified cursor source",
            "beforeId": "source-qualified cursor id",
        },
    },
    {"path": "/api/v1/config", "description": "Configuration summary (extended when authenticated)"},
    {"path": "/api/v1/remote-health", "description": "Remote SSH health rows"},
    {"path": "/api/v1/auth/state", "description": "Effective auth state for dashboard login bootstrap"},
    {"path": "/api/v1/auth/login", "description": "POST username/password for a session token (when auth enabled)"},
    {"path": "/api/v1/auth/logout", "description": "POST to invalidate the current session token"},
    {"path": "/api/v1/ups/{name}/commands", "description": "Allowlisted UPS commands (when nut_control enabled)"},
    {"path": "/api/v1/ups/{name}/command", "description": "POST {command} to run an allowlisted upscmd"},
    {"path": "/api/v1/ups/{name}/variables", "description": "Allowlisted writable UPS variables (upsrw)"},
    {"path": "/api/v1/ups/{name}/variables/{var}", "description": "PUT {value} to set an allowlisted upsrw variable"},
    {"path": "/api/v1/ups/{name}/events", "description": "DELETE selected events {items:[{id,ts,eventType}]} (auth required)"},
    {"path": "/api/v1/ups/{name}/battery-health", "description": "Battery-health score, terms, and replacement projection (v6.1)"},
    {"path": "/api/v1/ups/{name}/battery-health-history", "description": "Battery-health score trend (time series) for the Battery-tab graph (v6.1)"},
    {"path": "/api/v1/ups/{name}/energy", "description": "Energy (kWh) and optional cost, today/month (v6.1)"},
    {"path": "/api/v1/ups/{name}/power", "description": "Per-sample load% + watts series for the Energy chart (v6.1)"},
    {"path": "/api/v1/ups/{name}/shutdown-plan", "description": "Structured controlled-shutdown plan (phases, parallel groups, steps) (v6.1)"},
    {"path": "/api/v1/ups/{name}/shutdown-progress", "description": "Current or most recent controlled-shutdown progress"},
    {"path": "/api/v1/redundancy-groups/{name}/shutdown-plan", "description": "Structured redundancy-group shutdown plan"},
    {"path": "/api/v1/redundancy-groups/{name}/shutdown-progress", "description": "Current or most recent redundancy-group shutdown progress"},
    {"path": "/api/v1/ups/{name}/self-test", "description": "POST to issue a UPS self-test (auth required, allowlisted) (v6.1)"},
    {"path": "/api/v1/config/reload", "description": "POST to re-read config and apply the safe subset live"},
)


def _auth_is_active(config: Any) -> bool:
    """Whether API authentication is effectively enforced for ``config``.

    Thin wrapper over :func:`eneru.auth.auth_is_active` (the shared source of
    truth, also used by config validation): an explicit ``api.auth.enabled``
    always wins; when unset, auth is active iff the auth DB already has a user.
    """
    return auth_is_active(getattr(getattr(config, "api", None), "auth", None))


_AUDIT_EVENT_TYPE_BY_KIND = {
    "command": "CONTROL_COMMAND",
    "variable": "CONTROL_VARIABLE",
    "config": "CONFIG_RELOAD",
    "events": "EVENTS_DELETED",
    "self-test": "CONTROL_SELF_TEST",
    "login": "LOGIN_FAILURE",
}
# Every event type the audit trail writes ("CONTROL" is _audit's fallback).
# The API never deletes these (F-108) and hides them from anonymous readers
# (F-109).
AUDIT_EVENT_TYPES = frozenset(_AUDIT_EVENT_TYPE_BY_KIND.values()) | {"CONTROL"}
# What an anonymous /remote-health reader sees instead of last_error (F-110).
REDACTED_REMOTE_ERROR = "check failed; sign in for details"


def _redact_loopback_error(payload: Dict[str, Any]) -> None:
    """F-110: the loopback delegate's lastError (copied from remote health)
    can carry both machine-ids; anonymous /ready and /api/v1/ups readers get
    the same generic text as anonymous /remote-health readers."""
    delegate = (payload.get("runtime") or {}).get("loopbackDelegate") or {}
    if delegate.get("lastError"):
        delegate["lastError"] = REDACTED_REMOTE_ERROR


def _redact_remote_rows(rows: Any) -> Any:
    """F-110: copies of remote-health rows with last_error replaced."""
    if not isinstance(rows, list):
        return rows
    return [dict(r, last_error=REDACTED_REMOTE_ERROR)
            if isinstance(r, dict) and r.get("last_error") else r
            for r in rows]


def _redact_ups_row(row: Dict[str, Any]) -> Dict[str, Any]:
    """A copy of one UPS/redundancy status row with its embedded
    remote-health errors redacted."""
    if not row.get("remoteHealth"):
        return row
    return dict(row, remoteHealth=_redact_remote_rows(row["remoteHealth"]))


def _redact_status_payload(payload: Dict[str, Any]) -> None:
    """F-110 for /api/v1/ups: the loopback summary plus every remote-health
    row nested under ``ups[]`` and ``redundancyGroups[]``."""
    _redact_loopback_error(payload)
    for key in ("ups", "redundancyGroups"):
        rows = payload.get(key)
        if isinstance(rows, list):
            payload[key] = [_redact_ups_row(r) if isinstance(r, dict) else r
                            for r in rows]


class _BoundedThreadingHTTPServer(ThreadingHTTPServer):
    """ThreadingHTTPServer with a hard cap on concurrent connections.

    cubic P1 (round 1): the F-018 request semaphore bounds PROCESSING, but
    ``ThreadingMixIn`` still spawned one thread per accepted connection
    before ever reaching that gate — a plain connection flood would pile up
    blocked handler threads without limit. ELI5: the kitchen only cooks 32
    orders at once, but the lobby let an unlimited crowd in to stand and
    wait; now the lobby has a fire-code capacity too. Past
    ``MAX_CONCURRENT_CONNECTIONS`` simultaneous connections, a new socket is
    closed at accept time WITHOUT spawning a thread (a cheap refusal —
    well-behaved clients retry), so a flood stops costing a thread per
    socket.

    Class attribute so tests can shrink the cap to prove the refusal path.
    """

    max_connections = MAX_CONCURRENT_CONNECTIONS

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._connection_slots = threading.BoundedSemaphore(
            self.max_connections)
        # F-100: non-loopback peers must ALSO hold one of these, so the last
        # LOOPBACK_RESERVED_CONNECTIONS slots stay available to local probes.
        self._public_slots = threading.BoundedSemaphore(
            max(1, self.max_connections - LOOPBACK_RESERVED_CONNECTIONS))

    @staticmethod
    def _is_loopback_peer(client_address: Any) -> bool:
        try:
            return ipaddress.ip_address(client_address[0]).is_loopback
        except (ValueError, TypeError, IndexError):
            return False

    def _public_gate(self, client_address: Any) -> Optional[Any]:
        """The extra semaphore a non-loopback peer must hold, if any."""
        public = getattr(self, "_public_slots", None)
        if public is None or self._is_loopback_peer(client_address):
            return None
        return public

    def process_request(self, request: Any, client_address: Any) -> None:
        public = self._public_gate(client_address)
        if public is not None and not public.acquire(blocking=False):
            self.shutdown_request(request)
            return
        if not self._connection_slots.acquire(blocking=False):
            # Saturated: refuse before a thread exists to leak.
            if public is not None:
                public.release()
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            # Thread creation failed — the per-thread release below will
            # never run, so return the slot here. Pinned assumption (CPython
            # 3.9–3.13): ThreadingMixIn.process_request has no raising code
            # AFTER t.start(), so this except and the thread's finally can
            # never both fire; BoundedSemaphore would raise loudly if a
            # future stdlib change broke that.
            self._connection_slots.release()
            if public is not None:
                public.release()
            raise

    def process_request_thread(self, request: Any, client_address: Any) -> None:
        # ThreadingMixIn runs this ON the spawned worker thread; the slot is
        # held for the connection's whole lifetime (incl. keep-alive idles)
        # and released exactly once on the way out.
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._connection_slots.release()
            public = self._public_gate(client_address)
            if public is not None:
                public.release()


class EneruAPIServer:
    """Small stdlib HTTP server for read-only observability endpoints."""

    def __init__(
        self,
        source: Any,
        config: Any,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.source: Any = source
        self.config: Any = config
        self.log_fn: Callable[[str], None] = log_fn or (lambda msg: None)
        self._httpd: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        # Auth machinery is built whenever the auth config exists — construction
        # is free (no I/O until first use), and the store must be ready in case
        # auth becomes active at runtime without a restart (e.g. the first user
        # is created while the daemon runs; see _auth_is_active). Whether auth is
        # actually *enforced* is decided dynamically per request, not here.
        self._auth_store: Optional[AuthStore] = None
        self._sessions: Optional[SessionManager] = None
        auth_cfg = getattr(config.api, "auth", None)
        if auth_cfg is not None:
            self._auth_store = AuthStore(auth_cfg.db_path)
            self._sessions = SessionManager(auth_cfg.session_ttl)

    def start(self) -> None:
        """Start the API server when enabled."""
        if not self.config.api.enabled or self._thread is not None:
            return

        source = self.source
        config = self.config
        auth_store = self._auth_store
        sessions = self._sessions
        log_fn = self.log_fn

        class Handler(EneruAPIHandler):
            api_source = source
            api_config = config
            api_auth = auth_store
            api_sessions = sessions
            api_log = staticmethod(log_fn)

        addr = (self.config.api.bind, int(self.config.api.port))
        try:
            # bind_and_activate=False so we can raise the listen backlog before
            # listen() is called. The stdlib default request_queue_size is 5, so a
            # burst of concurrent dashboard/API connections could overflow the
            # accept queue and surface as intermittent "connection refused" even
            # though the daemon is healthy and every handler runs on its own
            # worker thread. 128 absorbs realistic bursts.
            self._httpd = _BoundedThreadingHTTPServer(
                addr, Handler, bind_and_activate=False)
            self._httpd.request_queue_size = 128
            self._httpd.server_bind()
            self._httpd.server_activate()
        except OSError as exc:
            self.log_fn(f"⚠️  API server failed to bind {addr[0]}:{addr[1]}: {exc}")
            # bind_and_activate=False bypasses TCPServer.__init__'s cleanup, so a
            # failed server_bind() leaves the freshly-created socket open. Close it
            # explicitly to avoid leaking the fd on a retry / repeated reload.
            if self._httpd is not None:
                try:
                    self._httpd.server_close()
                except OSError:
                    pass
            self._httpd = None
            return
        # v6.0: worker threads are NON-daemon. The API now has non-idempotent
        # write endpoints (control commands, config reload), so a worker must
        # not be cut off mid-request on shutdown — that would leave a caller
        # unsure whether a command actually ran. ``stop()`` calls
        # ``shutdown()`` + ``server_close()`` to drain in-flight handlers
        # gracefully. Handlers are bounded (subprocess timeouts on control
        # calls), so this can't hang shutdown indefinitely.
        self._httpd.daemon_threads = False
        self._thread = threading.Thread(
            target=self._httpd.serve_forever,
            name="eneru-api",
            daemon=True,
        )
        self._thread.start()
        self.log_fn(f"📊  API server listening on {addr[0]}:{addr[1]}")
        # Off-loopback binds still need a trusted network boundary, but auth
        # disabled is not a write-surface problem in v6.0: write endpoints are
        # closed, and anonymous /api/v1/config responses are sanitized.
        auth_on = _auth_is_active(self.config)
        if not _is_loopback_bind(self.config.api.bind):
            # ISS-009: the API is HTTP-only, so an off-loopback bind sends login
            # passwords and bearer tokens in cleartext. Say so explicitly and
            # point at a TLS reverse proxy (see docs/observability-api.md).
            self.log_fn(
                f"⚠️  API bound to {addr[0]} over PLAIN HTTP — credentials and "
                "tokens are sent unencrypted. Front it with a TLS reverse proxy "
                "(nginx/caddy) or keep the bind on loopback."
            )
            if auth_on:
                self.log_fn(
                    f"ℹ️  API bound to {addr[0]} with auth enabled. Read endpoints "
                    "stay open unless api.auth.require_for_reads is set."
                )
            else:
                self.log_fn(
                    f"ℹ️  API bound to {addr[0]} with auth disabled. Write endpoints "
                    "are disabled, and /api/v1/config returns a sanitized view "
                    "to anonymous clients; restrict network access before "
                    "exposing read endpoints beyond trusted hosts."
                )
        elif not auth_on:
            # Loopback + auth off: the dashboard hides its Sign-in button in this
            # state, so spell out why and how to enable login/control. (The
            # off-loopback branch already warns above.)
            self.log_fn(
                "ℹ️  API authentication is disabled; the dashboard is read-only "
                "and Sign-in is hidden. Set api.auth.enabled: true and run "
                "`eneru user create` to enable login and UPS control."
            )

    def stop(self) -> None:
        """Stop the API server."""
        if self._httpd is None:
            return
        try:
            self._httpd.shutdown()
            self._httpd.server_close()
        except Exception:
            pass
        self._httpd = None
        self._thread = None


class EneruAPIHandler(BaseHTTPRequestHandler):
    """Request handler for the Eneru API (reads + v6.0 authenticated writes)."""

    api_source: Any = None
    api_config: Any = None
    # Set by EneruAPIServer.start() only when api.auth is enabled.
    api_auth: Any = None
    api_sessions: Any = None
    api_log: Any = None

    # ISS-007: bound the request-line/header read. BaseHTTPRequestHandler applies
    # this to the connection socket in setup(); without it, handle_one_request's
    # rfile.readline() blocks forever on a client that connects and never sends a
    # complete request line (slowloris). With daemon_threads=False that stalled
    # worker makes server_close() (called from EneruAPIServer.stop() on SIGTERM)
    # join it indefinitely, hanging daemon shutdown until systemd SIGKILLs. On
    # timeout handle_one_request sets close_connection and the thread exits. The
    # body read (below) restores this class value via previous_timeout.
    #
    # F-046: with protocol_version="HTTP/1.1" (below) this same timeout is ALSO
    # the keep-alive idle timeout. Between two pipelined requests the handler
    # blocks in handle_one_request's readline() waiting for the next one; the
    # socket timeout fires after REQUEST_READ_TIMEOUT_SECONDS of silence,
    # BaseHTTPRequestHandler catches socket.timeout, sets close_connection, and
    # handle() returns — so an idle keep-alive client cannot pin a worker thread.
    timeout = REQUEST_READ_TIMEOUT_SECONDS

    # F-046: default to HTTP/1.1 so a browser/Prometheus client can REUSE one TCP
    # connection for the whole dashboard poll (the stdlib default HTTP/1.0 tears
    # the connection down after every request — a fresh TCP + thread per call).
    # Every response already sends Content-Length (see _finish), which is what
    # HTTP/1.1 keep-alive needs to frame a body without chunked encoding.
    #
    # ELI5 — the keep-alive vs. thread-bound trap: HTTP/1.1 lets a caller keep a
    # phone line (connection) open between questions. A naive "cap the number of
    # phone lines" would let a few callers who dial in and then say nothing hold
    # every line and lock out real users (a slowloris). We avoid that with a
    # two-part rule: (1) an idle line is hung up after `timeout` seconds
    # (above), so a silent caller can't squat forever; (2) the cap below counts
    # only lines that are actively ASKING something, not lines merely held open.
    # A caller waiting between questions holds a thread but NOT a semaphore slot,
    # so idle keep-alives can never starve active request processing — the
    # semaphore only ever blocks when 32 requests are being handled at once.
    protocol_version = "HTTP/1.1"

    # F-018: BoundedSemaphore capping concurrent ACTIVE request processing (see
    # MAX_CONCURRENT_REQUESTS + _dispatch). A class attribute (shared across the
    # per-start Handler subclass and every worker thread) so a test can swap in a
    # smaller semaphore to prove the (N+1)th concurrent request queues instead of
    # running unbounded.
    _request_semaphore = threading.BoundedSemaphore(MAX_CONCURRENT_REQUESTS)
    # F-072: one warning per server lifetime is enough to make a newly rejected
    # hostname discoverable without giving an attacker an unbounded log stream.
    _host_rejection_warned = False
    _host_rejection_lock = threading.Lock()

    server_version = "EneruAPI/1.0"

    def handle_one_request(self):
        """F-100: bound the request line + headers by wall-clock time.

        ELI5: the doorman already hangs up on a caller who goes silent for
        10 s, but a caller who mumbles one syllable every 9 s could keep the
        line forever. A stopwatch now starts with each request; if the
        caller hasn't finished saying who they are (request line + headers)
        when it rings, the doorman stops listening (shutdown of the read
        side), the half-read request fails and the connection closes. The
        stopwatch stops as soon as the headers are parsed, so a slow HANDLER
        (e.g. a long self-test issue) is never cut off.
        """
        timer = None
        connection = getattr(self, "connection", None)
        if connection is not None:
            timer = threading.Timer(REQUEST_HEADER_DEADLINE_SECONDS,
                                    self._abort_slow_headers)
            timer.daemon = True
            timer.start()
        self._header_timer = timer
        self._header_deadline_hit = False
        try:
            super().handle_one_request()
        finally:
            if timer is not None:
                timer.cancel()

    def parse_request(self):
        ok = super().parse_request()
        timer = getattr(self, "_header_timer", None)
        if timer is not None:
            timer.cancel()  # headers are in: the handler may take its time
        if getattr(self, "_header_deadline_hit", False):
            # The read side was shut down mid-headers, so the stdlib parsed
            # a truncated header block as complete (and reset
            # close_connection). Never dispatch that request.
            self.close_connection = True
            return False
        return ok

    def _abort_slow_headers(self) -> None:
        self._header_deadline_hit = True
        self.close_connection = True
        try:
            self.connection.shutdown(socket.SHUT_RD)
        except OSError:
            pass

    def do_GET(self):  # noqa: N802 - stdlib hook
        self._dispatch(self._route)

    def do_POST(self):  # noqa: N802 - stdlib hook
        self._dispatch(self._route_post)

    def do_PUT(self):  # noqa: N802 - stdlib hook
        self._dispatch(self._route_put)

    def do_DELETE(self):  # noqa: N802 - stdlib hook
        self._dispatch(self._route_delete)

    def do_HEAD(self):  # noqa: N802 - stdlib hook
        # ISS-061: load balancers and uptime checks often probe with HEAD.
        # Support it headers-only for the liveness/readiness endpoints (which
        # is where a HEAD probe is meaningful); other paths get 405 so we
        # don't ship a body-less 200 for routes that imply a payload.
        path = urlparse(self.path).path
        self._head_only = True
        try:
            if path in ("/health", "/ready"):
                self._dispatch(self._route)
            else:
                # Still HEAD semantics: headers only, no body (RFC 9110).
                self._finish(
                    405, "application/json",
                    self._error("METHOD_NOT_ALLOWED",
                                "HEAD is only supported for /health and /ready"))
        finally:
            self._head_only = False

    def log_message(self, fmt, *args):  # noqa: A003 - stdlib hook
        return

    def _host_allowed(self) -> bool:
        """F-016 DNS-rebinding guard: only route trusted Host headers.

        ELI5: a web page in someone's browser is like a stranger phoning your
        house — your phone trusts whatever *name* they dialed. A DNS-rebinding
        attacker tricks the victim's browser into dialing a name the attacker
        owns that now resolves to your LAN IP, so the tab happily reads your
        private API. The defense: only pick up the phone if the caller dialed a
        bare *number* (an IP literal — a rebind attack always arrives as a DNS
        name, never a raw address), or ``localhost``, or a name you put on the
        guest list (``api.allowed_hosts``). Anything else — including no Host at
        all — hangs up (the dispatcher answers 421).
        """
        host = self.headers.get("Host")
        if not host:
            return False
        host = host.strip()
        if not host:
            return False
        # Strip the ":port". IPv6 literals are bracketed ("[::1]:9191"); a bare
        # IPv6 ("::1") has several colons and no brackets — leave those intact
        # for ip_address() to parse. Only a single trailing ":port" is stripped.
        if host.startswith("["):
            end = host.find("]")
            if end == -1:
                return False
            # cubic P2 (round 1): reject trailing junk after the bracket.
            # Without this, "[::1]evil.example" parsed as hostname "::1" and
            # sailed through the IP-literal allow — the exact bypass this
            # gate exists to block. Only "" or a numeric ":port" may follow.
            rest = host[end + 1:]
            if rest and not (rest.startswith(":") and rest[1:].isdigit()):
                return False
            hostname = host[1:end]
        elif host.count(":") == 1:
            hostname = host.rsplit(":", 1)[0]
        else:
            hostname = host
        hostname = hostname.strip()
        if not hostname:
            return False
        # An IP-literal Host is always safe: a DNS-rebind necessarily carries a
        # DNS *name*, so a raw address can't be the rebinding vector.
        try:
            ipaddress.ip_address(hostname)
            return True
        except ValueError:
            pass
        lowered = hostname.lower()
        if lowered == "localhost":
            return True
        allowed = getattr(self.api_config.api, "allowed_hosts", None) or []
        return lowered in {str(h).strip().lower() for h in allowed}

    def _dispatch(self, router: Callable[[], Tuple[int, str, Any]]) -> None:
        """Run a router, map exceptions to responses, and write the result.

        F-018: the whole body runs while HOLDING ``_request_semaphore`` so at
        most ``MAX_CONCURRENT_REQUESTS`` requests are processed at once; the
        (N+1)th blocks here until a slot frees. The slot is acquired only for the
        duration of actually handling a request — the idle wait for the NEXT
        keep-alive request happens in ``handle_one_request`` OUTSIDE this method,
        so an idle keep-alive connection never holds a semaphore slot and cannot
        starve active processing (the keep-alive-vs-bound trap; see the
        ``protocol_version`` note).
        """
        with self._request_semaphore:
            self._dispatch_locked(router)

    def _dispatch_locked(
        self, router: Callable[[], Tuple[int, str, Any]]
    ) -> None:
        # One handler instance can serve many HTTP/1.1 requests. Track body
        # consumption per request so an early response never leaves bytes that
        # the next keep-alive request would misparse as its request line.
        self._request_body_consumed = False
        # F-016: reject an untrusted Host before touching any route — a
        # DNS-rebinding page must never reach the read-open API. 421 Misdirected
        # Request is the precise "you reached the wrong server name" signal.
        if not self._host_allowed():
            self._warn_host_rejected_once()
            self._finish(
                421, "application/json",
                self._error("MISDIRECTED_REQUEST", "Host header not allowed"))
            return
        try:
            status, content_type, body = router()
        except APIBadRequest as exc:
            status, content_type, body = (
                400, "application/json", self._error("INVALID_REQUEST", str(exc)))
        except APIPayloadTooLarge as exc:
            status, content_type, body = (
                413, "application/json", self._error("PAYLOAD_TOO_LARGE", str(exc)))
        except APIUnauthorized as exc:
            status, content_type, body = (
                401, "application/json", self._error("UNAUTHORIZED", str(exc)))
        except APIForbidden as exc:
            status, content_type, body = (
                403, "application/json", self._error("FORBIDDEN", str(exc)))
        except APILengthRequired as exc:
            status, content_type, body = (
                411, "application/json",
                self._error("LENGTH_REQUIRED", str(exc)))
        except Exception:
            # F-030: the client gets a deliberately opaque 500 (no internals
            # leaked), but an unhandled handler exception must NOT vanish -- log
            # the full traceback via the handler's log fn (the same channel the
            # control-audit path uses) so operators can actually diagnose it.
            if self.api_log is not None:
                self.api_log(
                    "⚠️  API request handler raised an unhandled exception "
                    "(returning 500 INTERNAL_ERROR):\n"
                    + traceback.format_exc().rstrip()
                )
            status, content_type, body = (
                500, "application/json",
                {"error": {"code": "INTERNAL_ERROR", "message": "Internal server error"}})
        self._finish(status, content_type, body)

    def _warn_host_rejected_once(self) -> None:
        """Log the first rejected Host with an actionable allowlist hint."""
        cls = type(self)
        with cls._host_rejection_lock:
            if cls._host_rejection_warned:
                return
            cls._host_rejection_warned = True
        if self.api_log is not None:
            raw_host = self.headers.get("Host")
            shown = repr(raw_host) if raw_host is not None else "<missing>"
            self.api_log(
                f"⚠️  API rejected Host {shown} with HTTP 421; add the "
                "hostname to api.allowed_hosts if this is expected."
            )

    def _unread_request_body(self) -> bool:
        """Return whether this response leaves framed request bytes unread."""
        if getattr(self, "_request_body_consumed", False):
            return False
        headers = getattr(self, "headers", {})
        if headers.get("Transfer-Encoding"):
            return True
        raw_length = headers.get("Content-Length")
        if raw_length is None:
            return False
        try:
            return int(raw_length) != 0
        except (TypeError, ValueError):
            return True

    def _finish(self, status: int, content_type: str, body: Any) -> None:
        if content_type == "application/json":
            raw = json.dumps(body, sort_keys=True).encode("utf-8")
        elif isinstance(body, (bytes, bytearray)):
            raw = bytes(body)
        else:
            raw = str(body).encode("utf-8")
        self.send_response(status)
        self.send_header(
            "Content-Type",
            _CONTENT_TYPE_HEADERS.get(content_type,
                                      "application/json; charset=utf-8"))
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        if self._unread_request_body():
            # Closing is safer than draining here: a slow or partial body must
            # not hold the response hostage. The next request gets a clean new
            # connection instead of a phantom 400 from leftover bytes.
            self.close_connection = True
            self.send_header("Connection", "close")
        # N2: nosniff on EVERY response (JSON/JS/CSS/HTML), not just HTML -- the
        # dashboard's static assets are served with specific content types and
        # must not be MIME-sniffed.
        self.send_header("X-Content-Type-Options", "nosniff")
        if content_type == "text/html":
            # The dashboard ships no inline scripts/styles and loads nothing
            # third-party, so a strict same-origin CSP locks it down.
            self.send_header(
                "Content-Security-Policy",
                "default-src 'self'; base-uri 'none'; frame-ancestors 'none'")
        if status == 401:
            self.send_header("WWW-Authenticate", "Bearer")
        self.end_headers()
        # ISS-061: a HEAD response carries the same headers (incl. the
        # would-be Content-Length) but no body, per RFC 9110.
        if getattr(self, "_head_only", False):
            return
        self.wfile.write(raw)

    def _serve_static(self, path: str) -> Optional[Tuple[str, bytes]]:
        """Return ``(content_type, bytes)`` for a dashboard asset, or None.

        Only flat asset names from the ``eneru.web`` package are servable. The
        strict name check (no ``/``, no ``..``) makes path traversal impossible.
        """
        name = _DASHBOARD_INDEX if path == "/" else path.lstrip("/")
        if not re.fullmatch(r"[A-Za-z0-9._-]+", name):
            return None
        content_type = _STATIC_CONTENT_TYPES.get(os.path.splitext(name)[1])
        if content_type is None:
            return None
        try:
            data = (importlib.resources.files("eneru.web") / name).read_bytes()
        except (FileNotFoundError, OSError, ModuleNotFoundError):
            return None
        return content_type, data

    # ----- auth helpers (v6.0) -----

    # Cache for the "do users exist" probe on the read path: every GET calls
    # _authorize(), so an uncached per-request user_count() would add a SQLite
    # open to each scrape. Stored on the base class (shared across the per-start
    # Handler subclass and all worker threads); races are benign — independent
    # writes of a float and a bool, worst case a redundant probe.
    _auth_active_ts: float = 0.0
    _auth_active_val: bool = False
    _auth_active_key: Optional[str] = None
    _AUTH_ACTIVE_TTL: float = 5.0

    def _auth_active(self, *, refresh: bool = False) -> bool:
        """Effective auth state for this request (see :func:`_auth_is_active`).

        Explicit/enabled cases are resolved instantly with no I/O; only the
        unpinned "users exist?" branch consults the DB, behind a short TTL cache
        so a brand-new first user is honored within seconds and no restart is
        ever required.
        """
        auth_cfg = getattr(self.api_config.api, "auth", None)
        if auth_cfg is None:
            return False
        if getattr(auth_cfg, "enabled_explicitly_set", False):
            return bool(auth_cfg.enabled)
        if auth_cfg.enabled:
            return True
        base = EneruAPIHandler
        now = time.time()
        cache_key = str(getattr(auth_cfg, "db_path", ""))
        if (
            refresh
            or base._auth_active_key != cache_key
            or now - base._auth_active_ts > base._AUTH_ACTIVE_TTL
        ):
            base._auth_active_val = _auth_is_active(self.api_config)
            base._auth_active_ts = now
            base._auth_active_key = cache_key
        return base._auth_active_val

    def _bearer_token(self) -> Optional[str]:
        """Return the credential from Authorization: Bearer or X-API-Key."""
        header = self.headers.get("Authorization", "") or ""
        # The auth scheme is case-insensitive per RFC 7235 ("Bearer"/"bearer").
        if header[:7].lower() == "bearer ":
            return header[7:].strip() or None
        api_key = self.headers.get("X-API-Key")
        return api_key.strip() if api_key else None

    def _authenticate_request(self, *, strict: bool = False) -> Optional[Dict[str, Any]]:
        """Resolve the caller from a session token, then an API key. None if neither.

        ``strict`` is set for WRITE/control paths: when a session's user lookup
        fails (auth DB unavailable) the request is denied rather than allowed, so
        a deleted admin can't run control commands during a DB outage. Reads
        stay lenient (``strict=False``) so a transient blip doesn't log out a
        valid user. An *unknown* status never invalidates the token either way,
        so a genuine session recovers once the DB is back (M4).
        """
        token = self._bearer_token()
        if not token:
            return None
        if self.api_sessions is not None:
            principal = self.api_sessions.validate(token)
            if principal is not None:
                status = self._session_user_status(principal)
                if status == "ok":
                    return principal
                if status == "gone":
                    # The backing user was deleted while the session lived — kill
                    # the token so the client (and any later request) 401s.
                    self.api_sessions.invalidate(token)
                    return None
                # status == "unknown" (transient auth-DB error): writes fail
                # closed, reads keep the session. Token left intact.
                return None if strict else principal
        if self.api_auth is not None:
            try:
                principal = self.api_auth.authenticate_api_key(token)
            except Exception:
                principal = None
            if principal is not None:
                return principal
        return None

    def _session_user_status(self, principal: Dict[str, Any]) -> str:
        """Return ``'ok'`` | ``'gone'`` | ``'unknown'`` for a session principal.

        - ``'ok'``      -- the user exists (or this isn't a DB-backed user session)
        - ``'gone'``    -- the user row is definitively absent (deleted)
        - ``'unknown'`` -- the lookup raised (auth DB unavailable)

        Sessions are in-memory and outlive the DB row they were minted from, so a
        deleted user would otherwise stay signed in until TTL. Non-user
        principals (API keys) are re-checked against the DB on their own path.
        """
        if principal.get("kind") != "user":
            return "ok"
        store = self.api_auth
        if store is None:
            return "ok"
        username = principal.get("username")
        if not username:
            return "ok"
        try:
            user = store.get_user(username)
            if user is None:
                return "gone"
            issued_at = principal.get("password_changed_at")
            if issued_at is not None and user.get("password_changed_at") != issued_at:
                return "gone"
            return "ok"
        except Exception:
            return "unknown"

    def _authorize(self, *, write: bool) -> Optional[Dict[str, Any]]:
        """Enforce the tiered auth policy. Returns the principal (may be None).

        - auth disabled: reads are open; **writes are hard-disabled (403)** —
          "auth off" never means "control open".
        - auth enabled: writes require a credential (401 otherwise); reads are
          open unless ``require_for_reads``, then they require one too.
        """
        auth_cfg = getattr(self.api_config.api, "auth", None)
        enabled = self._auth_active()
        if not enabled:
            if write:
                raise APIForbidden(
                    "write operations require api.auth.enabled")
            return None
        # Writes re-check the user account strictly (fail closed on DB error).
        principal = self._authenticate_request(strict=write)
        if write:
            if principal is None:
                raise APIUnauthorized("authentication required")
            return principal
        if auth_cfg.require_for_reads and principal is None:
            raise APIUnauthorized("authentication required")
        return principal

    def _redact_for(self, principal: Optional[Dict[str, Any]]) -> bool:
        """True for an anonymous reader while auth is active (F-109/F-110).

        With auth off there are no identities: the API is a trusted surface
        and the dashboard keeps showing why a remote check failed."""
        return principal is None and self._auth_active()

    def _read_json_body(self) -> Dict[str, Any]:
        """Read + parse a JSON object body, bounded by ``MAX_BODY_BYTES``."""
        # ISS-061: the body reader is strictly Content-Length framed. A
        # chunked Transfer-Encoding has no Content-Length, so it would read as
        # an empty body and silently mis-parse; reject it with 411 instead.
        te = (self.headers.get("Transfer-Encoding") or "").lower()
        if "chunked" in te:
            raise APILengthRequired(
                "chunked Transfer-Encoding is not supported; "
                "send a Content-Length-framed body")
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            raise APIBadRequest("invalid Content-Length")
        if length < 0:
            raise APIBadRequest("invalid Content-Length")
        if length > MAX_BODY_BYTES:
            raise APIPayloadTooLarge(
                f"body exceeds {MAX_BODY_BYTES} bytes")
        deadline = time.monotonic() + REQUEST_READ_TIMEOUT_SECONDS
        timeout_changed = False
        previous_timeout = None
        connection = getattr(self, "connection", None)
        if length and connection is not None:
            try:
                previous_timeout = connection.gettimeout()
                connection.settimeout(REQUEST_READ_TIMEOUT_SECONDS)
                timeout_changed = True
            except Exception:
                # Tests and uncommon socket wrappers may not expose timeout
                # controls. Real sockets get the read-specific timeout above.
                pass
        try:
            try:
                chunks = []
                remaining = length
                reader = getattr(self.rfile, "read1", None)
                if not callable(reader):
                    reader = self.rfile.read
                while remaining:
                    time_left = deadline - time.monotonic()
                    if time_left <= 0:
                        raise APIBadRequest("request body timed out")
                    if timeout_changed:
                        try:
                            connection.settimeout(time_left)
                        except Exception:
                            pass
                    chunk = reader(min(remaining, 65536))
                    if not chunk:
                        break
                    chunks.append(chunk)
                    remaining -= len(chunk)
                raw = b"".join(chunks) if length else b""
            except (socket.timeout, TimeoutError):
                raise APIBadRequest("request body timed out")
            except OSError:
                raise APIBadRequest("failed to read request body")
        finally:
            if timeout_changed:
                try:
                    connection.settimeout(previous_timeout)
                except Exception:
                    pass
        if length and len(raw) != length:
            raise APIBadRequest("incomplete request body")
        self._request_body_consumed = True
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise APIBadRequest("body must be valid JSON")
        if not isinstance(data, dict):
            raise APIBadRequest("body must be a JSON object")
        return data

    def _route(self) -> Tuple[int, str, Any]:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        qs = parse_qs(parsed.query)

        # Dashboard static assets (HTML/CSS/JS) carry no data and are served
        # unauthenticated so the login form can render; the API calls the page
        # then makes are themselves gated. Served whenever the API is enabled.
        static = self._serve_static(path)
        if static is not None:
            content_type, data = static
            return 200, content_type, data

        # Liveness/readiness are always open — Kubernetes probes and load
        # balancers can't carry credentials, and they expose no sensitive data.
        if path == "/health":
            return 200, "application/json", {"status": "ok", "generatedAt": time.time()}

        if path == "/ready":
            payload = readiness(self.api_source)
            status = 200 if payload["ready"] else 503
            # ISS-030: the full readiness payload lists UPS/remote names and
            # not-ready reasons (topology disclosure). Under require_for_reads an
            # unauthenticated probe gets only the boolean; authenticated callers
            # (and the reads-open default) keep the detail. Probes never get 401.
            auth_cfg = getattr(self.api_config.api, "auth", None)
            if (self._auth_active()
                    and getattr(auth_cfg, "require_for_reads", False)
                    and self._authenticate_request(strict=False) is None):
                return status, "application/json", {"ready": payload["ready"]}
            if (self._auth_active()
                    and self._authenticate_request(strict=False) is None):
                _redact_loopback_error(payload)
            return status, "application/json", payload

        # Auth bootstrap must stay open even when require_for_reads=true;
        # otherwise the dashboard cannot learn that it should show the login
        # form before it has a token.
        if path == "/api/v1/auth/state":
            auth_cfg = getattr(self.api_config.api, "auth", None)
            # This is the dashboard bootstrap signal. Refresh it immediately so
            # `eneru user create` can make the Sign-in button appear without a
            # daemon restart or waiting for the read-path cache to expire.
            auth_active = self._auth_active(refresh=True)
            return 200, "application/json", {
                "enabled": auth_active,
                "requireForReads": bool(
                    auth_active and getattr(auth_cfg, "require_for_reads", False)
                ),
            }

        # Every remaining GET is a read: open by default, gated when
        # require_for_reads is set. principal is None for anonymous callers.
        principal = self._authorize(write=False)

        if path == "/metrics":
            if not self.api_config.prometheus.enabled:
                return 404, "application/json", self._not_found("Metrics disabled")
            return 200, "text/plain", render_prometheus_metrics(self.api_source)

        if path == "/api/v1":
            return 200, "application/json", self._api_index()

        if path == "/api/v1/ups":
            payload = collect_status(self.api_source)
            if self._redact_for(principal):
                _redact_status_payload(payload)
            return 200, "application/json", payload

        if path.startswith("/api/v1/redundancy-groups/"):
            parts = path.split("/")
            group_name = unquote(parts[4]) if len(parts) > 4 else ""
            group = next(
                (item for item in self.api_config.redundancy_groups
                 if item.name == group_name), None)
            if group is None:
                return 404, "application/json", self._not_found(
                    "Redundancy group not found")
            executors = getattr(
                self.api_source, "_redundancy_executors", {}) or {}
            executor = executors.get(group_name)
            if len(parts) == 6 and parts[5] == "shutdown-progress":
                tracker = getattr(executor, "_shutdown_progress", None)
                return 200, "application/json", {
                    "group": group_name,
                    # Raw remote command output (redacted) is for signed-in
                    # readers only, like config_summary(extended=True).
                    "progress": (
                        tracker.snapshot(include_detail=principal is not None)
                        if tracker is not None else None),
                    "remoteDetailAvailable": principal is not None,
                }
            if len(parts) == 6 and parts[5] == "shutdown-plan":
                from eneru.config import Config, UPSGroupConfig
                from eneru.shutdown.plan import build_shutdown_plan
                if executor is not None:
                    plan_config = executor.config
                    delegated = executor._uses_loopback_delegate
                else:
                    plan_config = Config(
                        ups_groups=[UPSGroupConfig(
                            remote_servers=list(group.remote_servers),
                            virtual_machines=group.virtual_machines,
                            containers=group.containers,
                            filesystems=group.filesystems,
                            is_local=group.is_local,
                        )],
                        behavior=self.api_config.behavior,
                        local_shutdown=self.api_config.local_shutdown,
                    )
                    delegated = False
                plan = build_shutdown_plan(
                    plan_config,
                    is_local=group.is_local,
                    delegated=bool(delegated),
                    coordinator_mode=True,
                    include_final_sync=False,
                    reveal_commands=False,
                )
                return 200, "application/json", {
                    "group": group_name,
                    "upsSources": list(group.ups_sources),
                    "minHealthy": group.min_healthy,
                    "plan": plan,
                    **_redundancy_plan_extras(group, self.api_config, executor),
                }

        if path.startswith("/api/v1/ups/"):
            parts = path.split("/")
            ups_name = unquote(parts[4]) if len(parts) > 4 else ""
            if len(parts) == 5:
                payload = collect_status(self.api_source)
                row = find_status(payload, ups_name)
                if row is None:
                    return 404, "application/json", self._not_found("UPS not found")
                if self._redact_for(principal):
                    row = _redact_ups_row(row)
                # H4: one-UPS reads carry the server clock too.
                row = dict(row, generatedAt=payload.get("generatedAt"))
                return 200, "application/json", row
            if len(parts) == 6 and parts[5] == "history":
                metric = (qs.get("metric") or ["charge"])[0]
                if metric not in HISTORY_METRICS:
                    allowed = ", ".join(sorted(HISTORY_METRICS))
                    return 400, "application/json", self._error(
                        "INVALID_REQUEST",
                        f"metric must be one of: {allowed}",
                    )
                end = _parse_int_param(qs, "to", int(time.time()))
                # Earliest data that can exist = the hourly-aggregate retention
                # horizon. Omitting `from` ("All") maps here, not to an unbounded
                # scan; an explicit `from` older than this is clamped up to it.
                horizon = end - int(
                    self.api_config.statistics.retention.agg_hourly_days) * 86400
                if "from" in qs:
                    start = _parse_int_param(qs, "from", end - 3600)
                    if start > end:
                        return 400, "application/json", self._error(
                            "INVALID_REQUEST", "'from' must be <= 'to'")
                    start = max(start, horizon)
                else:
                    start = horizon
                rows = query_history(self.api_config, ups_name, metric, start, end)
                if rows is None:
                    return 404, "application/json", self._not_found("UPS not found")
                return 200, "application/json", {
                    "ups": ups_name, "metric": metric, "from": start,
                    "to": end, "data": rows,
                }
            if len(parts) == 6 and parts[5] == "commands":
                return self._list_commands(ups_name)
            if len(parts) == 6 and parts[5] == "variables":
                return self._list_variables(ups_name)
            if len(parts) == 6 and parts[5] == "shutdown-plan":
                # v6.1: read-only structured shutdown plan (phases, parallel
                # groups, steps) for the dashboard DAG view. Mirrors the
                # executor's order without touching the execution path. Built
                # from the monitor's actual runtime flags so it matches reality.
                mon = self._monitor_for(ups_name)
                if mon is None:
                    return 404, "application/json", self._not_found("UPS not found")
                from eneru.shutdown.plan import build_shutdown_plan
                group = (mon.config.ups_groups[0]
                         if getattr(mon.config, "ups_groups", None) else None)
                is_local = group.is_local if group is not None else True
                # Prefer the running monitor's own flag: a reloaded api_config
                # can drift from the restart-only local_shutdown it started with.
                coordinator_handoff = getattr(mon, "_coordinator_handoff", None)
                if coordinator_handoff is None:
                    all_groups = getattr(self.api_config, "ups_groups", []) or []
                    coordinator_handoff = (
                        is_local
                        or (
                            self.api_config.local_shutdown.trigger_on == "any"
                            and not any(item.is_local for item in all_groups)
                        )
                    )
                plan = build_shutdown_plan(
                    mon.config, is_local=is_local,
                    delegated=bool(getattr(mon, "_uses_loopback_delegate", False)),
                    coordinator_mode=bool(getattr(mon, "_coordinator_mode", False)),
                    coordinator_handoff=coordinator_handoff,
                    # Raw shutdown commands can embed sensitive flags/creds, so
                    # they stay redacted for ALL readers — matching the
                    # config_summary(extended=True) / remote-health contract,
                    # which never reveals raw commands even to authenticated users.
                    reveal_commands=False)
                return 200, "application/json", {
                    "ups": ups_name, "plan": plan,
                    **_ups_plan_extras(mon, self.api_config)}
            if len(parts) == 6 and parts[5] == "shutdown-progress":
                mon = self._monitor_for(ups_name)
                if mon is None:
                    return 404, "application/json", self._not_found("UPS not found")
                tracker = getattr(mon, "_shutdown_progress", None)
                return 200, "application/json", {
                    "ups": ups_name,
                    # Raw remote command output (redacted) is for signed-in
                    # readers only, like config_summary(extended=True).
                    "progress": (
                        tracker.snapshot(include_detail=principal is not None)
                        if tracker is not None else None),
                    "remoteDetailAvailable": principal is not None,
                }
            if len(parts) == 6 and parts[5] == "battery-health-history":
                # v6.1 battery-health score TREND for the Battery-tab graph.
                # Battery aging plays out over YEARS, so default to the full
                # retained history (battery_health rows survive the hourly
                # retention horizon, up to ~5y) instead of a short window, and
                # downsample to one point per day so a multi-year span still
                # renders. Also project the replacement date so the UI can mark
                # it (data-driven trend ETA, else the age-based estimate).
                from eneru.health import prediction
                mon = self._monitor_for(ups_name)
                if mon is None:
                    return 404, "application/json", self._not_found("UPS not found")
                store = getattr(mon, "_stats_store", None)
                now_ts = int(time.time())
                end = _parse_int_param(qs, "to", now_ts)
                # `from` unset -> the full retained horizon (5y), so the graph
                # spans the battery's whole recorded life.
                start = _parse_int_param(qs, "from", end - 1825 * 86400)
                if start > end:
                    return 400, "application/json", self._error(
                        "INVALID_REQUEST", "'from' must be <= 'to'")
                rows = []
                if store is not None:
                    try:
                        rows = store.query_battery_health(start, end)
                    except Exception:
                        rows = []
                # Downsample to one point per UTC day (mean score). Hourly rows
                # over years would be tens of thousands of points; a daily trend
                # is what the multi-year view needs.
                buckets: Dict[int, List[float]] = {}
                for r in rows:
                    s = r.get("score")
                    if s is None:
                        continue
                    day = (int(r["ts"]) // 86400) * 86400
                    acc = buckets.setdefault(day, [0.0, 0.0])
                    acc[0] += float(s)
                    acc[1] += 1
                data = [{"ts": d, "score": round(a[0] / a[1], 2)}
                        for d, a in sorted(buckets.items())]
                # Replacement-date projection for the red marker + threshold line.
                replacement: Dict[str, Any] = {
                    "etaTs": None, "etaSource": None, "thresholdScore": None,
                    "days": None, "years": None, "text": "unknown",
                    "capped": False, "beyond": False}
                try:
                    cfg = mon._resolve_battery_health_config()
                except Exception:
                    cfg = getattr(mon.config, "battery_health", None)
                if cfg is not None:
                    rep = cfg.replacement
                    history = [(float(r["ts"]), float(r["score"]))
                               for r in rows if r.get("score") is not None]
                    # H6: the same capped estimate the status block publishes,
                    # so the chart marker and the "Replace in" label agree.
                    replacement = prediction.bounded_replacement_eta(
                        history,
                        threshold_score=rep.threshold_score,
                        horizon_days=rep.horizon_days,
                        min_history_days=rep.min_history_days,
                        battery_install_date=cfg.battery_install_date,
                        expected_life_years=cfg.expected_life_years,
                        now=now_ts)
                    replacement["thresholdScore"] = rep.threshold_score
                return 200, "application/json", {
                    "ups": ups_name, "from": start, "to": end,
                    "data": data, "replacement": replacement}
            if len(parts) == 6 and parts[5] in ("battery-health", "energy"):
                # v6.1 read endpoints (same data the /status row carries). Build
                # only the matched monitor's status — not the whole fleet — so a
                # single-UPS read doesn't run every other UPS's (DB-heavy) energy
                # query.
                mon = self._monitor_for(ups_name)
                if mon is None:
                    return 404, "application/json", self._not_found("UPS not found")
                row = monitor_status(mon)
                key = "batteryHealth" if parts[5] == "battery-health" else "energy"
                return 200, "application/json", {
                    "ups": row.get("name", ups_name), key: row.get(key)}
            if len(parts) == 6 and parts[5] == "power":
                # v6.1 Energy-tab series: per-sample load% + watts (realpower or
                # the load*nominal fallback, flagged estimated). Same retention
                # window handling as /history.
                mon = self._monitor_for(ups_name)
                if mon is None:
                    return 404, "application/json", self._not_found("UPS not found")
                end = _parse_int_param(qs, "to", int(time.time()))
                horizon = end - int(
                    self.api_config.statistics.retention.agg_hourly_days) * 86400
                if "from" in qs:
                    start = _parse_int_param(qs, "from", end - 3600)
                    if start > end:
                        return 400, "application/json", self._error(
                            "INVALID_REQUEST", "'from' must be <= 'to'")
                    start = max(start, horizon)
                else:
                    start = horizon
                store = getattr(mon, "_stats_store", None)
                from eneru.config import resolve_energy_config
                nominal = getattr(
                    resolve_energy_config(mon.config), "nominal_power", None)
                return 200, "application/json", {
                    "ups": ups_name, "from": start, "to": end,
                    "data": power_series(store, start, end, nominal_fallback=nominal),
                }

        if path == "/api/v1/events":
            # Cap ``limit`` so a hostile or accidental ``?limit=10000000``
            # can't fan out into a multi-second SQLite scan across every
            # configured stats DB.
            limit = _parse_int_param(qs, "limit", 100, minimum=1, maximum=10000)
            verbosity = _parse_int_param(qs, "verbosity", 2, minimum=0, maximum=2)
            start_ts = _parse_int_param(qs, "from", None) if "from" in qs else None
            end_ts = _parse_int_param(qs, "to", None) if "to" in qs else None
            if start_ts is not None and end_ts is not None and start_ts > end_ts:
                return 400, "application/json", self._error(
                    "INVALID_REQUEST", "'from' must be <= 'to'")
            before_ts = None
            before_cursor = None
            has_cursor_detail = "beforeSource" in qs or "beforeId" in qs
            if "before" in qs:
                before_ts = _parse_int_param(qs, "before", None)
                if has_cursor_detail:
                    if "beforeSource" not in qs or "beforeId" not in qs:
                        raise APIBadRequest(
                            "'beforeSource' and 'beforeId' must be supplied together")
                    before_source = (qs.get("beforeSource") or [""])[0]
                    if not before_source:
                        raise APIBadRequest("'beforeSource' is required")
                    before_id = _parse_int_param(qs, "beforeId", None, minimum=1)
                    before_cursor = (before_ts, before_source, before_id)
            elif has_cursor_detail:
                raise APIBadRequest("'before' is required with cursor details")
            return 200, "application/json", {
                "generatedAt": time.time(),
                "events": query_events(
                    self.api_config, limit=limit, verbosity=verbosity,
                    start_ts=start_ts, end_ts=end_ts, before_ts=before_ts,
                    before_cursor=before_cursor,
                    # F-109: audit rows name the admin who acted and the IPs of
                    # failed logins; only signed-in readers see them.
                    hide_types=(AUDIT_EVENT_TYPES if self._redact_for(principal)
                                else None)),
            }

        if path == "/api/v1/config":
            # Anonymous -> sanitized; authenticated -> extended (still no secrets).
            summary = config_summary(
                self.api_config, extended=principal is not None)
            # Report the *effective* auth state: auth can be active via existing
            # users even when api.auth.enabled is unset, and the dashboard reads
            # this field to decide whether to show the Sign-in button.
            summary["api"]["auth"]["enabled"] = self._auth_active()
            return 200, "application/json", summary

        if path == "/api/v1/remote-health":
            rows = live_remote_health(self.api_source, self.api_config)
            if self._redact_for(principal):
                # F-110: last_error can quote raw ssh stderr and, for a
                # loopback, both machine-ids (a stable host fingerprint).
                # Anonymous readers learn only THAT the check failed.
                rows = [dict(r, last_error=REDACTED_REMOTE_ERROR)
                        if r.get("last_error") else r for r in rows]
            return 200, "application/json", {"generatedAt": time.time(), "servers": rows}

        return 404, "application/json", self._not_found("Endpoint not found")

    def _route_post(self) -> Tuple[int, str, Any]:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"

        if path == "/api/v1/auth/login":
            return self._handle_login()
        if path == "/api/v1/auth/logout":
            return self._handle_logout()
        if path == "/api/v1/config/reload":
            return self._handle_config_reload()

        # POST /api/v1/ups/{name}/command
        parts = path.split("/")
        if len(parts) == 6 and parts[1:4] == ["api", "v1", "ups"] \
                and parts[5] == "command":
            return self._run_instant_command(unquote(parts[4]))
        # POST /api/v1/ups/{name}/self-test (v6.1)
        if len(parts) == 6 and parts[1:4] == ["api", "v1", "ups"] \
                and parts[5] == "self-test":
            return self._run_self_test(unquote(parts[4]))

        return 404, "application/json", self._not_found("Endpoint not found")

    def _run_self_test(self, ups_name: str) -> Tuple[int, str, Any]:
        """Issue a UPS self-test (auth-gated, audited).

        Authentication (enforced by ``_authorize(write=True)``) is the real
        privilege gate. Permission to issue the command comes from
        ``self_test.self_test_control``: enabling ``self_test`` grants exactly
        ``self_test.command`` (v6.1.2), OR the general control surface allows it
        (``nut_control.enabled`` + allowlist). The general ``/command`` and
        variable endpoints still require ``nut_control.enabled`` independently."""
        principal = self._authorize(write=True)
        real = self._resolve_ups_name(ups_name)
        if real is None:
            return 404, "application/json", self._not_found("UPS not found")
        nc = self._effective_nut_control(real)
        st_cfg = self._effective_self_test(real)
        command = st_cfg.command
        if not command:
            raise APIBadRequest("self_test.command is not configured")
        permitted, nc = selftest.self_test_control(nc, st_cfg, command)
        if not permitted:
            self._audit(principal, "self-test", f"{real}:{command}", "denied")
            raise APIForbidden(
                "self-test is not permitted: enable self_test, or enable "
                "nut_control and add the command to allowed_commands")
        # Preflight against `upscmd -l` like the scheduled/direct paths, so the
        # API honors the same "self-disable if unsupported" contract the docs
        # promise rather than letting NUT reject it after the fact.
        try:
            supported = selftest.list_supported_commands(
                real, username=nc.username, password=nc.password,
                timeout=nc.timeout)
        except selftest.SelfTestUnavailable as exc:
            self._audit(principal, "self-test", f"{real}:{command}", "failed")
            return 502, "application/json", self._error("NUT_ERROR", str(exc))
        if command not in supported:
            self._audit(principal, "self-test", f"{real}:{command}", "failed")
            # Point the operator at what this UPS actually offers — many devices
            # expose test.battery.start.quick/.deep, not the bare default — so a
            # 422 is actionable ("set self_test.command to X") not a dead end.
            candidates = selftest.test_command_candidates(supported)
            hint = (" Available battery-test commands: " + ", ".join(candidates)
                    + " — set this UPS's self_test.command to one of them."
                    ) if candidates else ""
            return 422, "application/json", self._error(
                "UNSUPPORTED",
                f"UPS {real} does not expose {command!r} (upscmd -l).{hint}")
        # A self-test must record a `running` row so its result can be finalised
        # later; without an open stats store it would orphan that state, so
        # refuse (mirrors the CLI --direct and scheduler guards). A store that
        # exists but is closed counts as unavailable too (public is_open mirrors
        # the monitor / battery-health guards).
        store = self._store_for_ups(real)
        if store is None or not getattr(store, "is_open", False):
            self._audit(principal, "self-test", f"{real}:{command}", "failed")
            return 503, "application/json", self._error(
                "STATS_UNAVAILABLE", "the statistics store is unavailable")
        with _ups_lock(real):
            result = selftest.issue_self_test(
                real, command, nc, store, source="api",
                result_poll_after=st_cfg.result_poll_after)
        self._audit(principal, "self-test", f"{real}:{command}",
                    "ok" if result["ok"] else "failed")
        if not result["ok"]:
            return 502, "application/json", self._error("NUT_ERROR", result["error"])
        return 200, "application/json", {"ups": real, "command": command,
                                         "status": "issued",
                                         "testId": result["test_id"]}

    def _route_delete(self) -> Tuple[int, str, Any]:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        parts = path.split("/")
        # DELETE /api/v1/ups/{name}/events
        if len(parts) == 6 and parts[1:4] == ["api", "v1", "ups"] \
                and parts[5] == "events":
            return self._delete_events(unquote(parts[4]))
        return 404, "application/json", self._not_found("Endpoint not found")

    def _delete_events(self, ups_name: str) -> Tuple[int, str, Any]:
        """Delete selected events for one UPS (auth-gated, audited).

        Body: ``{"items": [{"id", "ts", "eventType"}, ...]}``. Each item is
        validated strictly; the store matches on all three fields so a stale
        client can only delete the exact rows it saw.
        """
        principal = self._authorize(write=True)
        data = self._read_json_body()
        items = data.get("items")
        if not isinstance(items, list):
            raise APIBadRequest("'items' must be a list")
        if len(items) > 1000:
            raise APIPayloadTooLarge("too many items (max 1000)")
        normalized = []
        for it in items:
            if not isinstance(it, dict):
                raise APIBadRequest("each item must be an object")
            event_id, ts, event_type = it.get("id"), it.get("ts"), it.get("eventType")
            if not isinstance(event_id, int) or isinstance(event_id, bool):
                raise APIBadRequest("item 'id' must be an integer")
            if not isinstance(ts, int) or isinstance(ts, bool):
                raise APIBadRequest("item 'ts' must be an integer")
            if not isinstance(event_type, str) or not event_type:
                raise APIBadRequest("item 'eventType' is required")
            normalized.append((event_id, ts, event_type))
        # F-108: the audit trail can't be erased through the API. Audit rows
        # are skipped (not a 400, so a dashboard "delete selected" that
        # includes one still removes the rest) and counted as `protected`.
        protected = sum(1 for _i, _t, et in normalized if et in AUDIT_EVENT_TYPES)
        normalized = [n for n in normalized if n[2] not in AUDIT_EVENT_TYPES]
        real = self._resolve_ups_name(ups_name)
        if real is None:
            return 404, "application/json", self._not_found("UPS not found")
        source = self.api_source
        deleted = (source.delete_events(real, normalized)
                   if hasattr(source, "delete_events") else None)
        if deleted is None:
            return 503, "application/json", self._error(
                "STATS_UNAVAILABLE", "the statistics store is unavailable")
        note = f"{deleted} rows" + (f", {protected} audit rows kept" if protected else "")
        self._audit(principal, "events", f"{real}:delete", note)
        return 200, "application/json", {"ups": real, "deleted": deleted,
                                         "protected": protected}

    def _route_put(self) -> Tuple[int, str, Any]:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        parts = path.split("/")
        # PUT /api/v1/ups/{name}/variables/{var}
        if len(parts) == 7 and parts[1:4] == ["api", "v1", "ups"] \
                and parts[5] == "variables":
            return self._set_variable(unquote(parts[4]), unquote(parts[6]))
        return 404, "application/json", self._not_found("Endpoint not found")

    def _handle_login(self) -> Tuple[int, str, Any]:
        # Refresh the first-user probe here too: a user may create the initial
        # account in another shell and submit the login form before any
        # background dashboard poll has refreshed /auth/state.
        if not self._auth_active(refresh=True):
            return 404, "application/json", self._not_found("Authentication is disabled")
        client_addr = getattr(self, "client_address", None)
        client_ip = client_addr[0] if client_addr else "?"
        # ISS-032 / F-040: reject brute-force bursts before touching the auth
        # backend — per-IP first, then the global ceiling that catches an
        # attacker rotating source IPs past the per-IP guard.
        if _login_is_blocked(client_ip) or _global_login_is_blocked():
            return 429, "application/json", self._error(
                "TOO_MANY_ATTEMPTS",
                "too many failed login attempts; try again shortly")
        data = self._read_json_body()
        username = data.get("username")
        password = data.get("password")
        if not isinstance(username, str) or not isinstance(password, str) \
                or not username or not password:
            raise APIBadRequest("username and password are required")
        try:
            principal = self.api_auth.authenticate(username, password)
        except Exception:
            # bcrypt missing / store error — fail closed without leaking detail.
            return 503, "application/json", self._error(
                "AUTH_UNAVAILABLE", "authentication backend unavailable")
        if principal is None:
            # ISS-032: count the failure (per IP) and audit it so credential-
            # stuffing is both throttled and visible. Audit the SOURCE IP, not
            # the attempted username -- a user who fat-fingers a password into
            # the username field would otherwise have it persisted verbatim.
            source_throttled = _login_record_failure(client_ip)
            global_throttled = _global_login_record_failure()
            self._audit(
                None, "login", client_ip,
                "throttled" if source_throttled or global_throttled else "failed",
            )
            raise APIUnauthorized("invalid credentials")
        _login_clear(client_ip)  # ISS-032: reset the counter on success
        token = self.api_sessions.create(principal)
        return 200, "application/json", {
            "token": token,
            "tokenType": "bearer",
            # Report the manager's effective TTL (clamped), not the raw config,
            # so the client's expiry matches the server's.
            "expiresIn": self.api_sessions.ttl,
        }

    def _handle_logout(self) -> Tuple[int, str, Any]:
        if not self._auth_active():
            return 404, "application/json", self._not_found("Authentication is disabled")
        token = self._bearer_token()
        # Only an active session token can be logged out (API keys aren't
        # sessions). Treat anything else as unauthenticated.
        if not token or self.api_sessions.validate(token) is None:
            raise APIUnauthorized("authentication required")
        self.api_sessions.invalidate(token)
        return 200, "application/json", {"status": "ok"}

    # ----- config hot-reload (v6.0) -----

    def _handle_config_reload(self) -> Tuple[int, str, Any]:
        principal = self._authorize(write=True)
        source = self.api_source
        if not hasattr(source, "reload_config"):
            return 503, "application/json", self._error(
                "RELOAD_UNAVAILABLE", "config reload is not supported here")
        report = source.reload_config()
        reloaded = report.get("reloaded")
        self._audit(principal, "config", "reload",
                    "ok" if reloaded else "rejected")
        if reloaded:
            return 200, "application/json", report
        # ISS-028: return the standard {"error":{code,message}} envelope on
        # rejection (with the full reload report under `details`) instead of the
        # raw report dict, so clients get a consistent error shape.
        body = self._error(
            "RELOAD_REJECTED", "config reload rejected; running config kept")
        body["details"] = report
        return 400, "application/json", body

    # ----- UPS control (v6.0) -----

    def _require_nut_control(self):
        """Return the nut_control config, or raise if the feature is off."""
        nc = getattr(self.api_config, "nut_control", None)
        if not (nc and nc.enabled):
            raise APIForbidden("UPS control is disabled (set nut_control.enabled)")
        return nc

    def _resolve_ups_name(self, ups_name: str) -> Optional[str]:
        """Return the real NUT name for a UPS id/name, or None if unknown.

        Resolves through ``_monitor_for`` first so both resolvers share one
        matching path (no drift) and a control lookup skips the DB-heavy
        ``collect_status``; falls back to status matching for rows without a
        local monitor (e.g. remote-only UPSes)."""
        mon = self._monitor_for(ups_name)
        if mon is not None:
            return mon.config.ups.name
        row = find_status(collect_status(self.api_source), ups_name)
        return row["name"] if row is not None else None

    def _effective_nut_control(self, ups_name: str):
        """Resolve the nut_control config for one UPS.

        A per-group override is already fully resolved at parse time (unset fields
        inherited the global config), so it's used as-is — no per-field fallback
        that could silently widen a deliberately-narrowed allowlist. The
        ``enabled`` flag is always forced from the global config: a per-group
        block can never enable control when the global gate is off.
        """
        glob = self.api_config.nut_control
        for group in getattr(self.api_config, "ups_groups", []):
            if group.ups.name == ups_name and getattr(group, "nut_control", None):
                override = group.nut_control
                from eneru.config import NutControlConfig
                return NutControlConfig(
                    enabled=glob.enabled,
                    username=override.username,
                    password=override.password,
                    allowed_commands=override.allowed_commands,
                    allowed_variables=override.allowed_variables,
                    timeout=override.timeout,
                )
        return glob

    def _effective_self_test(self, ups_name: str):
        """Resolve the self_test config for one UPS (per-group override if set),
        mirroring _effective_nut_control so a per-UPS `self_test.command` is
        honored instead of always using the global command."""
        glob = self.api_config.self_test
        for group in getattr(self.api_config, "ups_groups", []):
            if group.ups.name == ups_name and getattr(group, "self_test", None):
                return group.self_test
        return glob

    def _monitor_for(self, ups_name: str):
        """Return the live monitor object owning ``ups_name`` (raw or sanitized
        match), or None. Used to reach a single UPS's stats store / status
        without walking the whole fleet."""
        from eneru.status import iter_monitors, sanitize_name
        target = sanitize_name(ups_name)
        for mon in iter_monitors(self.api_source):
            name = getattr(getattr(mon, "config", None), "ups", None)
            name = getattr(name, "name", None)
            if name and (name == ups_name or sanitize_name(name) == target):
                return mon
        return None

    def _store_for_ups(self, ups_name: str):
        """The per-UPS stats store for ``ups_name``, or None when unavailable
        (the store methods no-op on None, matching the daemon's failure
        isolation)."""
        mon = self._monitor_for(ups_name)
        return getattr(mon, "_stats_store", None) if mon is not None else None

    def _list_commands(self, ups_name: str) -> Tuple[int, str, Any]:
        self._authorize(write=True)
        self._require_nut_control()
        real = self._resolve_ups_name(ups_name)
        if real is None:
            return 404, "application/json", self._not_found("UPS not found")
        nc = self._effective_nut_control(real)
        ok, commands, err = nutctl.list_commands(
            real, username=nc.username, password=nc.password, timeout=nc.timeout)
        if not ok:
            return 502, "application/json", self._error("NUT_ERROR", err)
        allowed = set(nc.allowed_commands)
        return 200, "application/json", {
            "ups": real,
            "commands": sorted(c for c in commands if c in allowed),
            "supported": sorted(commands),
        }

    def _list_variables(self, ups_name: str) -> Tuple[int, str, Any]:
        self._authorize(write=True)
        self._require_nut_control()
        real = self._resolve_ups_name(ups_name)
        if real is None:
            return 404, "application/json", self._not_found("UPS not found")
        nc = self._effective_nut_control(real)
        ok, variables, err = nutctl.list_variables(real, timeout=nc.timeout)
        if not ok:
            return 502, "application/json", self._error("NUT_ERROR", err)
        allowed = set(nc.allowed_variables)
        return 200, "application/json", {
            "ups": real,
            "variables": [v for v in variables if v["name"] in allowed],
        }

    def _run_instant_command(self, ups_name: str) -> Tuple[int, str, Any]:
        principal = self._authorize(write=True)
        self._require_nut_control()
        data = self._read_json_body()
        command = data.get("command")
        if not isinstance(command, str) or not command:
            raise APIBadRequest("command is required")
        real = self._resolve_ups_name(ups_name)
        if real is None:
            return 404, "application/json", self._not_found("UPS not found")
        nc = self._effective_nut_control(real)
        if not nutctl.command_allowed(command, nc.allowed_commands):
            self._audit(principal, "command", f"{real}:{command}", "denied")
            raise APIForbidden(f"command {command!r} is not in allowed_commands")
        with _ups_lock(real):
            ok, out, err = nutctl.run_instant_command(
                real, command, nc.username, nc.password, timeout=nc.timeout)
        self._audit(principal, "command", f"{real}:{command}",
                    "ok" if ok else "failed")
        if not ok:
            return 502, "application/json", self._error("NUT_ERROR", err)
        return 200, "application/json", {"ups": real, "command": command,
                                         "status": "ok", "output": out}

    def _set_variable(self, ups_name: str, variable: str) -> Tuple[int, str, Any]:
        principal = self._authorize(write=True)
        self._require_nut_control()
        data = self._read_json_body()
        value = data.get("value")
        if not isinstance(value, (str, int, float)) or isinstance(value, bool):
            raise APIBadRequest("value is required (string or number)")
        value = str(value)
        # The value is the only non-allowlisted user input that reaches the NUT
        # CLI; constrain it to a safe charset (defense-in-depth — the call is an
        # execve arg list, not a shell).
        if not _SAFE_NUT_VALUE.match(value):
            raise APIBadRequest("value contains unsupported characters")
        real = self._resolve_ups_name(ups_name)
        if real is None:
            return 404, "application/json", self._not_found("UPS not found")
        nc = self._effective_nut_control(real)
        if variable not in set(nc.allowed_variables):
            self._audit(principal, "variable", f"{real}:{variable}", "denied")
            raise APIForbidden(f"variable {variable!r} is not in allowed_variables")
        with _ups_lock(real):
            ok, out, err = nutctl.set_variable(
                real, variable, value, nc.username, nc.password, timeout=nc.timeout)
        self._audit(principal, "variable", f"{real}:{variable}",
                    "ok" if ok else "failed")
        if not ok:
            return 502, "application/json", self._error("NUT_ERROR", err)
        return 200, "application/json", {"ups": real, "variable": variable,
                                         "value": value, "status": "ok"}

    @staticmethod
    def _principal_label(principal: Optional[Dict[str, Any]]) -> str:
        if not principal:
            return "anonymous"
        if principal.get("kind") == "api_key":
            return f"apikey:{principal.get('label', principal.get('id'))}"
        return str(principal.get("username", "unknown"))

    _AUDIT_EVENT_TYPES = _AUDIT_EVENT_TYPE_BY_KIND

    @staticmethod
    def _scrub(text: str) -> str:
        """Strip control characters so audit values can't forge log/event lines."""
        return "".join(c for c in str(text)
                       if ord(c) >= 0x20 and ord(c) != 0x7f)

    def _audit(self, principal, kind: str, target: str, result: str) -> None:
        """Record a control action to the daemon log AND the SQLite events table
        (v7.0 adds a tamper-evident audit log; this is the groundwork)."""
        label = self._scrub(self._principal_label(principal))
        target = self._scrub(target)
        line = f"🔌  control: {label} {kind} {target} -> {result}"
        if self.api_log is not None:
            try:
                self.api_log(line)
            except Exception:
                pass
        source = self.api_source
        if hasattr(source, "record_control_event"):
            # target is "{ups}:{command_or_var}"; the UPS NUT name itself can
            # contain a colon (e.g. UPS@host:3493), so split on the LAST one.
            # Login audits carry a client IP as the target, not ups:command --
            # never split those (an IPv6 address would be truncated); the full
            # address stays in the detail string and the ups column is empty.
            if kind == "login":
                ups = ""
            else:
                ups = target.rsplit(":", 1)[0] if ":" in target else ""
            event_type = self._AUDIT_EVENT_TYPES.get(kind, "CONTROL")
            try:
                source.record_control_event(ups, event_type,
                                            f"{label} {target} -> {result}")
            except Exception as exc:
                if self.api_log is not None:
                    try:
                        self.api_log(f"⚠️  control audit event failed: {exc}")
                    except Exception:
                        pass

    @staticmethod
    def _error(code: str, message: str) -> Dict[str, Dict[str, str]]:
        return {"error": {"code": code, "message": message}}

    def _not_found(self, message: str) -> Dict[str, Any]:
        payload = self._error("NOT_FOUND", message)
        payload["availableEndpoints"] = self._available_endpoints()
        return payload

    def _api_index(self) -> Dict[str, Any]:
        return {
            "generatedAt": time.time(),
            "version": "v1",
            "endpoints": self._available_endpoints(),
        }

    def _available_endpoints(self) -> List[Dict[str, Any]]:
        # Only advertise endpoints that are actually reachable in the active
        # config — listing a route that returns 404/403 would mislead clients
        # discovering the API via availableEndpoints.
        prometheus_enabled = bool(getattr(self.api_config.prometheus, "enabled", False))
        auth_enabled = self._auth_active()
        nut_enabled = bool(getattr(getattr(self.api_config, "nut_control", None),
                                   "enabled", False))
        # v6.1.2: self-test is reachable when self_test is enabled (its own narrow
        # permission) OR the general control surface is on — global or per-UPS.
        self_test_enabled = bool(
            getattr(getattr(self.api_config, "self_test", None), "enabled", False)
            or any(getattr(getattr(g, "self_test", None), "enabled", False)
                   for g in getattr(self.api_config, "ups_groups", [])))

        def _visible(path: str) -> bool:
            if path == "/metrics":
                return prometheus_enabled
            if path == "/api/v1/auth/state":
                return True
            if path.startswith("/api/v1/auth/") or path == "/api/v1/config/reload":
                return auth_enabled
            if path == "/api/v1/ups/{name}/events":
                return auth_enabled
            if path.startswith("/api/v1/ups/{name}/command") or \
                    path.startswith("/api/v1/ups/{name}/variables"):
                return nut_enabled
            if path == "/api/v1/ups/{name}/self-test":
                # POST self-test needs auth (write) AND permission — either
                # self_test enabled (its own narrow grant) or the general
                # nut_control surface.
                return auth_enabled and (self_test_enabled or nut_enabled)
            return True

        return [dict(e) for e in API_ENDPOINTS if _visible(e["path"])]


def _ups_plan_extras(mon: Any, api_config: Any) -> Dict[str, Any]:
    """H3c: the full trigger list + role next to the per-UPS shutdown plan."""
    try:
        from eneru.outlook import (
            describe_trigger_conditions, monitor_outlook)
        blocks = monitor_outlook(mon, api_config)
        outlook = blocks["triggerOutlook"]
        armed = any(t["id"] == "selfTestFailure" and t["enabled"]
                    for t in outlook["triggers"])
        triggers = mon.config.triggers
        return {
            "triggers": {
                "conditions": describe_trigger_conditions(
                    triggers, self_test_failure_armed=armed),
                "stabilizationDelay": triggers.on_battery_stabilization_delay,
                "outlook": outlook,
                "action": outlook["action"],
            },
            "role": blocks["role"],
        }
    except Exception:
        return {"triggers": None, "role": None}


def _redundancy_plan_extras(group: Any, api_config: Any,
                            executor: Any) -> Dict[str, Any]:
    """H3c for redundancy groups: quorum rule + member criticality rules."""
    try:
        from eneru.outlook import (
            describe_trigger_conditions, redundancy_role, trigger_action)
        role = redundancy_role(group, api_config, executor)
        members = len(group.ups_sources)
        return {
            "triggers": {
                "conditions": [
                    f"fewer than {group.min_healthy} of {members} members healthy",
                ],
                "memberConditions": describe_trigger_conditions(group.triggers),
                "stabilizationDelay": group.triggers.on_battery_stabilization_delay,
                "action": trigger_action(role),
            },
            "role": role,
        }
    except Exception:
        return {"triggers": None, "role": None}


def _parse_int_param(
    qs: Dict[str, list],
    name: str,
    default: int,
    *,
    minimum: Optional[int] = None,
    maximum: Optional[int] = None,
) -> Optional[int]:
    """Return one integer query parameter or raise ``APIBadRequest``.

    Returns None when the param is absent and ``default`` is None (ISS-029)."""
    # ISS-029: a caller may pass default=None to mean "optional / absent". Return
    # None rather than stringifying None -> int("None") -> a spurious 400 (the
    # latent foot-gun of the assembled-handler bug class).
    if name not in qs and default is None:
        return None
    raw = (qs.get(name) or [str(default)])[0]
    try:
        value = int(raw)
    except (TypeError, ValueError):
        raise APIBadRequest(f"{name} must be an integer") from None
    if minimum is not None and value < minimum:
        raise APIBadRequest(f"{name} must be >= {minimum}")
    if maximum is not None and value > maximum:
        raise APIBadRequest(f"{name} must be <= {maximum}")
    return value


def _escape_label_value(value: Any) -> str:
    """Escape a Prometheus label value."""
    return (
        str(value)
        .replace("\\", "\\\\")
        .replace("\n", "\\n")
        .replace("\r", "\\n")
        .replace('"', '\\"')
    )


def _metric_line(name: str, labels: Dict[str, str], value) -> str:
    label_text = ",".join(
        f'{k}="{_escape_label_value(v)}"'
        for k, v in labels.items()
    )
    # Prometheus exposition treats NaN as "no data" rather than as a
    # genuine zero reading. Emitting 0.0 for an unreported NUT field
    # (e.g. a UPS that never publishes input.voltage) would let alert
    # rules confuse "no telemetry" with "voltage collapsed to zero".
    # The exposition format also requires the canonical sentinels
    # ``NaN``, ``+Inf``, ``-Inf`` (case-sensitive); Python's default
    # float repr produces lowercase ``nan``/``inf`` which strict parsers
    # reject — drop the whole scrape, blank dashboards, mute alerts.
    if value is None or value == "":
        numeric_text = "NaN"
    else:
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            numeric_text = "NaN"
        else:
            if math.isnan(numeric):
                numeric_text = "NaN"
            elif math.isinf(numeric):
                numeric_text = "+Inf" if numeric > 0 else "-Inf"
            else:
                numeric_text = f"{numeric}"
    return f"{name}{{{label_text}}} {numeric_text}"


# State-machine metric labels. Standard Prometheus practice for
# enum/state metrics is to emit one series per possible label with
# 0 or 1, so transitions appear as flips rather than series gaps.
# Keep these tuples aligned with the values written by
# src/eneru/health/voltage.py.
_VOLTAGE_STATE_LABELS = ("NORMAL", "LOW", "HIGH")
_AVR_STATE_LABELS = ("INACTIVE", "BOOST", "TRIM")
_BINARY_STATE_LABELS = ("INACTIVE", "ACTIVE")


def _state_metric_lines(
    name: str,
    labels: Dict[str, str],
    current: Any,
    possible_labels: Sequence[str],
    default: str,
) -> List[str]:
    # Build the labels dict once and only mutate the "state" entry per
    # iteration; the previous {**labels, "state": label} comprehension
    # allocated one fresh dict per state per UPS per scrape (10 per UPS
    # across the four state metrics). _metric_line consumes the dict
    # synchronously so reusing the same instance is safe.
    active = current if current in possible_labels else default
    line_labels = dict(labels)
    lines = []
    for label in possible_labels:
        line_labels["state"] = label
        lines.append(_metric_line(name, line_labels, 1 if label == active else 0))
    return lines


_LOOPBACK_BINDS = frozenset({"127.0.0.1", "::1", "localhost"})


def _is_loopback_bind(bind: str) -> bool:
    """Return True if the configured bind address is loopback-only."""
    return (bind or "").strip().lower() in _LOOPBACK_BINDS


# Prometheus exposition format expects every metric to be preceded by
# its own HELP/TYPE block exactly once per scrape. Centralising the
# catalogue keeps render_prometheus_metrics() honest as new metrics are
# added — every entry here gets emitted, regardless of whether any UPS
# row currently produces a sample.
_METRIC_CATALOGUE = (
    ("eneru_up", "gauge", "Whether the Eneru API is serving metrics (1) or not."),
    ("eneru_ups_battery_charge", "gauge", "UPS battery charge percentage."),
    ("eneru_ups_runtime_seconds", "gauge", "UPS runtime estimate in seconds."),
    ("eneru_ups_load_percent", "gauge", "UPS load percentage."),
    ("eneru_ups_input_voltage", "gauge", "UPS input voltage in volts."),
    ("eneru_ups_output_voltage", "gauge", "UPS output voltage in volts."),
    ("eneru_ups_battery_voltage", "gauge", "UPS battery voltage in volts."),
    ("eneru_ups_temperature_celsius", "gauge", "UPS temperature in degrees Celsius."),
    ("eneru_ups_input_frequency_hz", "gauge", "UPS input frequency in hertz."),
    ("eneru_ups_output_frequency_hz", "gauge", "UPS output frequency in hertz."),
    ("eneru_ups_nominal_voltage", "gauge", "Snapped nominal grid voltage in volts."),
    ("eneru_ups_voltage_warning_low", "gauge", "Derived low-voltage warning threshold."),
    ("eneru_ups_voltage_warning_high", "gauge", "Derived high-voltage warning threshold."),
    ("eneru_ups_voltage_state", "gauge",
     "Grid-quality voltage state (one series per label, 1 if active)."),
    ("eneru_ups_avr_state", "gauge",
     "AVR state (one series per label, 1 if active)."),
    ("eneru_ups_bypass_state", "gauge",
     "Bypass state (one series per label, 1 if active)."),
    ("eneru_ups_overload_state", "gauge",
     "Overload state (one series per label, 1 if active)."),
    ("eneru_ups_depletion_rate_percent_per_minute", "gauge",
     "UPS battery depletion rate (charge percent per minute on battery)."),
    ("eneru_ups_time_on_battery_seconds", "gauge",
     "Seconds the UPS has been continuously on battery (0 when on line)."),
    ("eneru_ups_connection_failed", "gauge",
     "1 if the upsd connection for this UPS is in the FAILED state, 0 otherwise."),
    ("eneru_ups_trigger_active", "gauge",
     "1 if a shutdown trigger is currently active for this UPS, 0 otherwise."),
    ("eneru_remote_health_status", "gauge",
     "Remote SSH target status indicator (1 per status label combination)."),
    ("eneru_remote_health_consecutive_failures", "gauge",
     "Consecutive failed remote-health probes for this SSH target."),
    # v6.1
    ("eneru_ups_battery_health_score", "gauge",
     "Composite battery-health score 0-100 (omitted when unknown)."),
    ("eneru_ups_replacement_days_remaining", "gauge",
     "Projected days until the battery-health score crosses the replacement "
     "threshold (omitted when not projectable)."),
    ("eneru_ups_energy_kwh", "gauge",
     "Energy consumed in kWh, by period label (today|month). A gauge, NOT a "
     "_total: it is recomputed per window and is not monotonic."),
    ("eneru_ups_energy_cost", "gauge",
     "Energy cost by period label (today|month); omitted entirely when "
     "energy.cost_per_kwh is unset."),
    ("eneru_ups_self_test_result", "gauge",
     "Latest self-test result, one series per normalized result label "
     "(passed|warning|failed|aborted|running|unknown|unsupported)."),
)


def render_prometheus_metrics(source: Any) -> str:
    """Render Prometheus text exposition for live Eneru state."""
    payload = collect_status(source)
    lines = []
    for name, mtype, help_text in _METRIC_CATALOGUE:
        lines.append(f"# HELP {name} {help_text}")
        lines.append(f"# TYPE {name} {mtype}")
    lines.append("eneru_up 1")
    for row in payload.get("ups", []):
        labels = {"ups": row["name"], "label": row["label"]}
        power = row.get("powerQuality", {})
        lines.append(_metric_line("eneru_ups_battery_charge", labels, row["batteryCharge"]))
        lines.append(_metric_line("eneru_ups_runtime_seconds", labels, row["runtime"]))
        lines.append(_metric_line("eneru_ups_load_percent", labels, row["load"]))
        lines.append(_metric_line("eneru_ups_input_voltage", labels, power.get("inputVoltage")))
        lines.append(_metric_line("eneru_ups_output_voltage", labels, power.get("outputVoltage")))
        lines.append(_metric_line("eneru_ups_battery_voltage", labels, power.get("batteryVoltage")))
        lines.append(_metric_line("eneru_ups_temperature_celsius", labels, power.get("temperature")))
        lines.append(_metric_line("eneru_ups_input_frequency_hz", labels, power.get("inputFrequency")))
        lines.append(_metric_line("eneru_ups_output_frequency_hz", labels, power.get("outputFrequency")))
        lines.append(_metric_line("eneru_ups_nominal_voltage", labels, power.get("nominalVoltage")))
        lines.append(_metric_line("eneru_ups_voltage_warning_low", labels, power.get("warningLow")))
        lines.append(_metric_line("eneru_ups_voltage_warning_high", labels, power.get("warningHigh")))
        lines.extend(_state_metric_lines(
            "eneru_ups_voltage_state", labels,
            power.get("voltageState"), _VOLTAGE_STATE_LABELS, "NORMAL",
        ))
        lines.extend(_state_metric_lines(
            "eneru_ups_avr_state", labels,
            power.get("avrState"), _AVR_STATE_LABELS, "INACTIVE",
        ))
        lines.extend(_state_metric_lines(
            "eneru_ups_bypass_state", labels,
            power.get("bypassState"), _BINARY_STATE_LABELS, "INACTIVE",
        ))
        lines.extend(_state_metric_lines(
            "eneru_ups_overload_state", labels,
            power.get("overloadState"), _BINARY_STATE_LABELS, "INACTIVE",
        ))
        lines.append(_metric_line("eneru_ups_depletion_rate_percent_per_minute", labels, row["depletionRate"]))
        lines.append(_metric_line("eneru_ups_time_on_battery_seconds", labels, row["timeOnBattery"]))
        lines.append(_metric_line(
            "eneru_ups_connection_failed",
            labels,
            1 if row["connectionState"] == "FAILED" else 0,
        ))
        lines.append(_metric_line(
            "eneru_ups_trigger_active",
            labels,
            1 if row["triggerActive"] else 0,
        ))
        # v6.1: battery health, replacement, energy, self-test. Omit a series
        # when its value is unknown rather than emitting a misleading 0.
        bh = row.get("batteryHealth") or {}
        if bh.get("score") is not None:
            lines.append(_metric_line(
                "eneru_ups_battery_health_score", labels, bh["score"]))
        if bh.get("replacementDaysRemaining") is not None:
            lines.append(_metric_line(
                "eneru_ups_replacement_days_remaining", labels,
                bh["replacementDaysRemaining"]))
        energy = row.get("energy") or {}
        for period, kwh_key, cost_key in (("today", "todayKwh", "todayCost"),
                                          ("month", "monthKwh", "monthCost"),
                                          ("year", "yearKwh", "yearCost")):
            if energy.get(kwh_key) is not None:
                lines.append(_metric_line(
                    "eneru_ups_energy_kwh", {**labels, "period": period},
                    energy[kwh_key]))
            if energy.get(cost_key) is not None:
                lines.append(_metric_line(
                    "eneru_ups_energy_cost", {**labels, "period": period},
                    energy[cost_key]))
        st = row.get("selfTest") or {}
        if st.get("result"):
            lines.append(_metric_line(
                "eneru_ups_self_test_result",
                {**labels, "result": st["result"]}, 1))
        for server in row.get("remoteHealth", []):
            s_labels = {
                "ups": row["name"],
                "server": server.get("server", ""),
                "host": server.get("host", ""),
            }
            lines.append(_metric_line(
                "eneru_remote_health_status",
                {**s_labels, "status": server.get("status", "UNKNOWN")},
                1,
            ))
            lines.append(_metric_line(
                "eneru_remote_health_consecutive_failures",
                s_labels,
                server.get("consecutive_failures", 0),
            ))
    # Redundancy-group-owned remote targets (configured under
    # ``redundancy_groups[*].remote_servers``) need the same coverage as
    # ups-owned ones — otherwise a Prometheus consumer scraping for
    # ``eneru_remote_health_status`` silently misses every target attached
    # to a redundancy group. Use ``redundancy_group`` as the grouping
    # label so a downstream alert can ``by (redundancy_group)`` cleanly.
    for group in payload.get("redundancyGroups", []):
        for server in group.get("remoteHealth", []):
            s_labels = {
                "redundancy_group": group.get("name", ""),
                "server": server.get("server", ""),
                "host": server.get("host", ""),
            }
            lines.append(_metric_line(
                "eneru_remote_health_status",
                {**s_labels, "status": server.get("status", "UNKNOWN")},
                1,
            ))
            lines.append(_metric_line(
                "eneru_remote_health_consecutive_failures",
                s_labels,
                server.get("consecutive_failures", 0),
            ))
    return "\n".join(lines) + "\n"
