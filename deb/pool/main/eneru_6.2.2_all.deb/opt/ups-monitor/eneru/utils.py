"""Utility functions for Eneru."""

import math
import shutil
import subprocess
import os
import re
import stat
from typing import Any, Dict, Iterable, List, Optional, Tuple


CONTAINER_DEFAULT_KNOWN_HOSTS_FILE = "/var/lib/eneru/ssh/known_hosts"
KNOWN_HOSTS_ENV = "ENERU_SSH_KNOWN_HOSTS_FILE"

NUT_STATUS_LABELS = {
    "FSD": "Shutdown in progress",
    "OFF": "UPS output off",
    "WAIT": "Waiting for UPS data",
    "OB": "Running on battery",
    "OL": "Utility power",
    "LB": "Battery low",
    "HB": "Battery charge sufficient",
    "RB": "Battery replacement needed",
    "BYPASS": "Bypass active",
    "OVER": "UPS overloaded",
    "ALARM": "UPS alarm active",
    "CAL": "Battery calibration in progress",
    "CHRG": "Battery charging",
    "DISCHRG": "Battery discharging",
    "BOOST": "Voltage boost active",
    "TRIM": "Voltage trim active",
}

EVENT_TYPE_LABELS = {
    "ON_BATTERY": "Power failure",
    "POWER_RESTORED": "Power restored",
    "SELF_TEST_ON_BATTERY": "Self-test running on battery",
    "SELF_TEST_POWER_RESTORED": "Self-test power restored",
    "BROWNOUT_DETECTED": "Low input voltage",
    "OVER_VOLTAGE_DETECTED": "High input voltage",
    "VOLTAGE_NORMALIZED": "Input voltage normal",
    "AVR_BOOST_ACTIVE": "Voltage boost started",
    "AVR_TRIM_ACTIVE": "Voltage trim started",
    "AVR_INACTIVE": "Automatic voltage regulation inactive",
    "BYPASS_MODE_ACTIVE": "UPS entered bypass mode",
    "BYPASS_MODE_INACTIVE": "UPS left bypass mode",
    "OVERLOAD_ACTIVE": "UPS overload detected",
    "OVERLOAD_RESOLVED": "UPS overload resolved",
    "CONNECTION_LOST": "UPS connection lost",
    "CONNECTION_RESTORED": "UPS connection restored",
    "BATTERY_LOW": "Low battery detected",
}


def redact_apprise_url(url: Any) -> str:
    """Return an Apprise/notification URL with credentials stripped to scheme.

    ISS-008/ISS-034: Apprise URLs embed webhook tokens/passwords
    (e.g. ``discord://id/token``). Never log or print them verbatim -- emit only
    ``scheme://***`` so the service type is still visible for debugging without
    leaking the secret. Shared by the notification worker and the CLI.
    """
    text = str(url)
    scheme = text.split("://", 1)[0] if "://" in text else "unknown"
    return f"{scheme}://***"


def sanitize_name(name: Any) -> str:
    """Return the path-safe per-UPS identifier used by stats/state files.

    ISS-013: single source of truth for the ``@``/``:``/``/`` → ``-``
    substitution that was previously copy-pasted as inline ``.replace()``
    chains in ``multi_ups.py``, a local ``_sanitize`` in ``redundancy.py``,
    a nested ``_sanitize_name`` in ``config.py``, and ``status.sanitize_name``.
    Lives in ``utils`` (which imports nothing from the daemon) so config.py
    and redundancy.py can share it without an import cycle; ``status`` and
    the rest re-export from here. Tolerates ``None`` (→ ``""``) to preserve
    the config-path behaviour.
    """
    return (name or "").replace("@", "-").replace(":", "-").replace("/", "-")


def runs_coordinator(config: Any) -> bool:
    """True when ``eneru run`` starts the multi-UPS coordinator.

    F-181: the coordinator (and its per-UPS suffixed state/stats paths) runs
    for a multi-UPS list OR any redundancy group, even with a single UPS.
    Every reader that derives those paths asks here, so it can't drift from
    ``cli._cmd_run``.
    """
    return bool(getattr(config, "multi_ups", False)
                or getattr(config, "redundancy_groups", None))


def ups_state_file_path(config: Any, group: Any) -> str:
    """The state file the daemon writes for ``group`` (suffixed under the
    coordinator, bare in single-UPS mode)."""
    base = config.logging.state_file
    if runs_coordinator(config):
        return base + f".{sanitize_name(group.ups.name)}"
    return base


# Reads of daemon-written side files (state file, progress sidecar) are
# capped: a container-writable bind mount must not be able to point them at
# /dev/zero or a FIFO and hang the operator's shell (F-183).
SIDE_FILE_MAX_BYTES = 64 * 1024


def read_side_file(path: Any, max_bytes: int = SIDE_FILE_MAX_BYTES) -> str:
    """Read at most ``max_bytes`` of a regular, non-symlink file as text.

    Raises ``OSError`` when the file is missing, a symlink, or not a
    regular file. Undecodable bytes are replaced, never raised.
    """
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    fd = os.open(str(path), flags)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise OSError(f"not a regular file: {path}")
        data = os.read(fd, max_bytes)
    finally:
        os.close(fd)
    return data.decode("utf-8", errors="replace")


def write_side_file(path: Any, text: str) -> None:
    """Atomically replace a daemon-written side file with ``text``.

    The ``<name>.tmp`` staging file is unlinked first and re-created with
    ``O_EXCL|O_NOFOLLOW``, so a symlink planted there in a writable bind
    mount cannot redirect the write to another file.
    """
    path = str(path)
    tmp = path + ".tmp"
    try:
        os.unlink(tmp)
    except FileNotFoundError:
        pass
    flags = (os.O_WRONLY | os.O_CREAT | os.O_EXCL
             | getattr(os, "O_NOFOLLOW", 0))
    fd = os.open(tmp, flags, 0o644)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


_ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b[@-_]")


def clean(text: Any) -> str:
    """Strip terminal escapes/control characters from EXTERNAL text.

    Remote stderr, a NUT banner or a state-file value is printed to the
    operator's terminal; a compromised source must not be able to repaint
    it (clear the screen, retitle the window, write the clipboard).
    """
    text = _ANSI.sub("", str(text))
    return "".join(ch if (ch.isprintable() or ch == " ") else " " for ch in text)


def is_numeric(value: Any) -> bool:
    """Check if a value is numeric (int or float).

    Rejects NaN and ±Inf — callers (UPS metrics, voltages, runtimes)
    expect a real comparable number, and `int(float("nan"))` raises
    while `float("inf")` propagates into bucket math as garbage.
    """
    if value is None:
        return False
    if isinstance(value, bool):
        # bool is a subtype of int — NUT/UPS data should never be a
        # bool, and treating True as 1 silently conceals upstream bugs.
        return False
    if isinstance(value, (int, float)):
        return math.isfinite(value)
    if isinstance(value, str):
        try:
            return math.isfinite(float(value))
        except (ValueError, TypeError):
            return False
    return False


def run_command(
    cmd: List[str],
    timeout: int = 30,
    capture_output: bool = True,
    env_overrides: Optional[Dict[str, str]] = None,
) -> Tuple[int, str, str]:
    """Run a shell command and return (exit_code, stdout, stderr)."""
    # A None timeout means "wait forever" to subprocess.run. No caller wants
    # that during a shutdown sequence: a config value that slipped through as
    # None (e.g. `unmount.timeout:` with no value) would otherwise let a busy
    # umount hang the drain phase indefinitely. Fall back to the default bound.
    if timeout is None:
        timeout = 30
    try:
        result = subprocess.run(
            cmd,
            capture_output=capture_output,
            text=True,
            timeout=timeout,
            env={**os.environ, 'LC_NUMERIC': 'C', **(env_overrides or {})}
        )
        # subprocess.run returns stdout/stderr=None when capture_output
        # is False; normalize to empty strings so callers can always
        # `.strip()` / index the values without a TypeError.
        return (
            result.returncode,
            result.stdout if result.stdout is not None else "",
            result.stderr if result.stderr is not None else "",
        )
    except subprocess.TimeoutExpired:
        return 124, "", "Command timed out"
    except FileNotFoundError:
        return 127, "", f"Command not found: {cmd[0]}"
    except (TypeError, ValueError):
        # ISS-056: these signal a programming error in the CALLER (e.g. a
        # non-list cmd, or an invalid argument to subprocess.run), not a
        # runtime failure of the command. Masking them as a generic exit-1
        # hides real bugs -- let them propagate. OSError / subprocess errors
        # below stay swallowed (they're legitimate runtime conditions).
        raise
    except Exception as e:
        return 1, "", str(e)


def running_in_container() -> bool:
    """Best-effort check for Docker/Podman/Kubernetes runtime context."""
    if os.path.exists("/.dockerenv") or os.path.exists("/run/.containerenv"):
        return True
    if os.environ.get("KUBERNETES_SERVICE_HOST"):
        return True
    if os.environ.get("container", "").strip():
        return True
    try:
        with open("/proc/1/cgroup", encoding="utf-8") as fh:
            cgroup_text = fh.read()
    except OSError:
        cgroup_text = ""
    return any(marker in cgroup_text for marker in (
        "docker", "kubepods", "containerd", "lxc",
    ))


def ssh_option_configured(ssh_options: List[str], option_name: str) -> bool:
    """Return True when an OpenSSH option is already set by the user."""
    needle = option_name.lower()
    pending_o = False
    for opt in ssh_options:
        if not isinstance(opt, str):
            continue
        value = opt.strip()
        lower = value.lower()
        if pending_o:
            if _ssh_option_matches(lower, needle):
                return True
            pending_o = False
            continue
        if lower == "-o":
            pending_o = True
            continue
        if lower.startswith("-o "):
            value = value.split(None, 1)[1]
            lower = value.lower()
        if _ssh_option_matches(lower, needle):
            return True
    return False


def _ssh_option_matches(value: str, option_name: str) -> bool:
    return (
        value == option_name
        or value.startswith(f"{option_name}=")
        or value.startswith(f"{option_name} ")
    )


def runtime_default_ssh_options(ssh_options: List[str]) -> List[str]:
    """Return SSH defaults that depend on the runtime environment.

    Bare-metal installs should use the running user's normal OpenSSH trust
    store. Containers keep Eneru's documented SSH mount contract instead:
    `/srv/eneru/ssh` on the host maps to `/var/lib/eneru/ssh` in the
    container, so accept-new host keys are written there unless an explicit
    override is configured.
    """
    known_hosts = os.environ.get(KNOWN_HOSTS_ENV, "").strip()
    if not known_hosts and running_in_container():
        known_hosts = CONTAINER_DEFAULT_KNOWN_HOSTS_FILE
    if known_hosts and not ssh_option_configured(ssh_options, "UserKnownHostsFile"):
        return [f"UserKnownHostsFile={known_hosts}"]
    return []


def command_exists(cmd: str) -> bool:
    """Check if a command exists in the system PATH."""
    # F-031: resolve via shutil.which -- a pure PATH walk -- instead of shelling
    # out to `which`. ELI5: to know if a tool is in the toolbox you look in the
    # toolbox; you don't hire a second person (a subprocess) whose only job is to
    # look for you. Cheaper, and it doesn't assume a `which` binary exists (many
    # minimal container images ship without one).
    return shutil.which(cmd) is not None


def status_has_token(status: Any, token: str) -> bool:
    """True when ``token`` is a whitespace-separated flag in a NUT ``ups.status``.

    ELI5: a UPS status like ``"OB LB"`` is a row of separate passport stamps,
    not one long word. Checking ``"OB" in status`` reads the passport
    cross-eyed -- ``"CHRG"`` would match ``"DISCHRG"`` and a contrived value like
    ``"NOTOB"`` would match ``"OB"``. Splitting on whitespace and matching a whole
    stamp fixes that aliasing structurally (F-051). Shared by monitor.py's
    handlers and health/voltage.py so every status check uses the same rule.
    """
    return token in str(status or "").split()


def humanize_nut_status(status: Any) -> str:
    """Return a safety-first English label without dropping vendor tokens."""
    tokens = str(status or "").upper().strip().split()
    if not tokens:
        return "Status unknown"

    parts = []
    primary = next(
        (token for token in ("FSD", "OFF", "OB", "WAIT", "OL")
         if token in tokens),
        None,
    )
    if primary in ("FSD", "OFF"):
        parts.append(NUT_STATUS_LABELS[primary])
    for token in (
        "ALARM", "OVER", "LB", "RB", "BYPASS",
    ):
        if token in tokens:
            parts.append(NUT_STATUS_LABELS[token])
    if primary and primary not in ("FSD", "OFF"):
        parts.append(NUT_STATUS_LABELS[primary])
    for token in ("DISCHRG", "CAL", "CHRG", "BOOST", "TRIM", "HB"):
        if token in tokens:
            parts.append(NUT_STATUS_LABELS[token])

    unknown = list(dict.fromkeys(
        token for token in tokens if token not in NUT_STATUS_LABELS
    ))
    if unknown:
        label = "Custom state: " if len(unknown) == 1 else "Custom states: "
        parts.append(label + ", ".join(unknown))
    return " · ".join(parts)


def humanize_event_type(event_type: Any) -> str:
    """Return a notification label while preserving the caller's raw value."""
    raw = str(event_type or "").strip()
    if not raw:
        return "Event"
    upper = raw.upper()
    tokens = upper.split()
    if any(token in NUT_STATUS_LABELS for token in tokens):
        return humanize_nut_status(raw)
    if upper in EVENT_TYPE_LABELS:
        return EVENT_TYPE_LABELS[upper]

    words = [word for word in upper.replace("-", "_").split("_") if word]
    rendered = []
    for index, word in enumerate(words):
        if word in ("UPS", "API", "AVR"):
            rendered.append(word)
        else:
            lower = word.lower()
            rendered.append(lower.capitalize() if index == 0 else lower)
    return " ".join(rendered)


# ---------------------------------------------------------------------------
# M1: one status vocabulary + a 3-level severity scale for every surface.
#
# ELI5: a traffic light, not a dictionary. NUT hands us a row of stamps
# ("OB DISCHRG LB"); every screen used to translate them its own way, so the
# same outage read "ON BATTERY - DISCHARGING" in the TUI and "Running on
# battery · Battery discharging" on the web, and "on battery, fine" blinked as
# red as "about to die". status_summary() picks ONE short word per state and
# ONE of three colours; the long token-by-token text stays in ``detail``.
# ---------------------------------------------------------------------------
SEVERITY_OK = "ok"
SEVERITY_WARN = "warn"
SEVERITY_CRIT = "crit"
SEVERITY_LEVELS = (SEVERITY_OK, SEVERITY_WARN, SEVERITY_CRIT)

# state -> (short label, base severity). Order of the checks lives in
# status_summary(); this table is the single wording source.
STATUS_STATES = {
    "shutting_down": ("Shutting down", SEVERITY_CRIT),
    "trigger_active": ("Shutdown triggered", SEVERITY_CRIT),
    "connection_lost": ("Connection lost", SEVERITY_WARN),
    "stale": ("Stale data", SEVERITY_WARN),
    "output_off": ("UPS output off", SEVERITY_CRIT),
    "low_battery": ("Low battery", SEVERITY_CRIT),
    "on_battery": ("On battery", SEVERITY_WARN),
    "bypass": ("On bypass", SEVERITY_WARN),
    "online": ("On mains", SEVERITY_OK),
    "waiting": ("Waiting for data", SEVERITY_WARN),
    "unknown": ("Status unknown", SEVERITY_WARN),
}
_BLINK_STATES = frozenset({"shutting_down", "trigger_active"})


def status_summary(status: Any, *, trigger_active: bool = False,
                   shutting_down: bool = False, connection_state: str = "OK",
                   stale: bool = False) -> Dict[str, Any]:
    """Classify a NUT status (+ Eneru context) into the shared vocabulary.

    Returns ``{state, label, severity, blink, detail, tokens}``. First match
    wins: shutting down (or FSD) > trigger active > connection lost > stale >
    output off > low battery > on battery > bypass > on mains > waiting >
    unknown. Only the two "the host is about to go down" states blink.
    """
    tokens = str(status or "").upper().split()
    if shutting_down or "FSD" in tokens:
        state = "shutting_down"
    elif trigger_active:
        state = "trigger_active"
    elif str(connection_state or "OK").upper() == "FAILED":
        state = "connection_lost"
    elif stale:
        state = "stale"
    elif "OFF" in tokens:
        state = "output_off"
    elif "LB" in tokens:
        state = "low_battery"
    elif "OB" in tokens:
        state = "on_battery"
    elif "BYPASS" in tokens:
        state = "bypass"
    elif "OL" in tokens:
        state = "online"
    elif not tokens or "WAIT" in tokens:
        state = "waiting"
    else:
        state = "unknown"
    label, severity = STATUS_STATES[state]
    if state == "connection_lost" and "OB" in tokens:
        # Losing NUT while on battery is the FAILSAFE path, not a hiccup.
        severity = SEVERITY_CRIT
    if state == "online" and any(t in tokens for t in ("ALARM", "OVER", "RB")):
        severity = SEVERITY_WARN
    return {
        "state": state,
        "label": label,
        "severity": severity,
        "blink": state in _BLINK_STATES,
        "detail": humanize_nut_status(status) if tokens else "Status unknown",
        "tokens": tokens,
    }


def severity_rank(severity: Any) -> int:
    """ok=0, warn=1, crit=2; anything unrecognised ranks as warn."""
    try:
        return SEVERITY_LEVELS.index(severity)
    except ValueError:
        return 1


def worst_severity(severities: Iterable[Any]) -> str:
    """The most severe level in ``severities`` ("ok" when empty)."""
    worst = SEVERITY_OK
    for sev in severities:
        if severity_rank(sev) > severity_rank(worst):
            worst = SEVERITY_LEVELS[severity_rank(sev)]
    return worst


def format_age(seconds: Any) -> str:
    """Relative age for "updated 4s ago" / "14d ago" labels."""
    if not is_numeric(seconds):
        return "unknown"
    seconds = max(0, int(float(seconds)))
    if seconds < 2:
        return "just now"
    if seconds < 60:
        return f"{seconds}s ago"
    if seconds < 3600:
        return f"{seconds // 60}m ago"
    if seconds < 86400:
        return f"{seconds // 3600}h ago"
    return f"{seconds // 86400}d ago"


def format_seconds(seconds: Any) -> str:
    """Format seconds into a human-readable string.

    Negative inputs are clamped to 0 — UPS runtime/uptime values are
    never negative semantically, but a misbehaving driver can briefly
    return one (e.g. clock-skew during a hot-swap), and "-1m 30s" in
    the TUI is more confusing than "0s".
    """
    if not is_numeric(seconds):
        return "N/A"
    seconds = max(0, int(float(seconds)))
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        mins = seconds // 60
        secs = seconds % 60
        return f"{mins}m {secs}s"
    else:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{hours}h {minutes}m"
