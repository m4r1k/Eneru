"""Per-UPS SQLite statistics: buffered writer + read API.

A lightweight, *always-on* metrics store. The hot path is
``buffer_sample()`` -- a constant-time append to an in-memory deque with
zero I/O. A separate :class:`StatsWriter` thread flushes the buffer to
SQLite every 10 s, then runs aggregation + purge every 5 min.

Failure isolation contract: every public method except :meth:`open`
catches ``sqlite3.Error`` and ``OSError`` and logs once with rate-limit.
A SQLite outage never raises into the daemon loop.
"""

import json
import math
import sqlite3
import threading
import time
from collections import deque
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple
from urllib.parse import quote as urlquote

from eneru.utils import status_has_token


# Sample columns: 12 raw NUT metrics from spec 2.12 (battery.charge,
# battery.runtime, ups.load, input.voltage, output.voltage, battery.voltage,
# ups.temperature, input.frequency, output.frequency, ups.status, plus
# ups.realpower / ups.realpower.nominal / ups.power.nominal for energy tracking)
# plus 3
# Eneru-derived state fields (depletion_rate, time_on_battery,
# connection_state) that are the foundation for the future API.
# Order is locked: appending only keeps INSERT tuples stable for migrations.
SAMPLE_FIELDS: Tuple[str, ...] = (
    "ts",                # epoch seconds
    "status",            # ups.status string
    "battery_charge",    # %
    "battery_runtime",   # seconds
    "ups_load",          # %
    "input_voltage",     # V
    "output_voltage",    # V
    "depletion_rate",    # %/min  (Eneru-derived)
    "time_on_battery",   # seconds since on-battery start (Eneru-derived)
    "connection_state",  # OK / GRACE_PERIOD / FAILED  (Eneru-derived)
    "battery_voltage",   # V                 (added v2)
    "ups_temperature",   # °C                (added v2)
    "input_frequency",   # Hz                (added v2)
    "output_frequency",  # Hz                (added v2)
    "real_power",        # W   ups.realpower      (added v7, energy)
    "power_nominal",     # VA  ups.power.nominal  (added v7, energy)
    "real_power_nominal", # W  ups.realpower.nominal (added v8, energy)
)

# Bump and add a migration block in StatsStore._init_schema whenever the
# samples / agg_5min / agg_hourly / events / meta / notifications schema
# gains a column or table. See src/eneru/AGENTS.md "Stats schema evolution".
SCHEMA_VERSION = 8

# If the daemon or one-shot deferred-delivery helper dies after claiming a
# notification but before marking it sent/pending, the next daemon open moves
# the in-flight claim back to pending so it can be retried instead of looking
# delivered forever.
DELIVERING_RECOVERY_GRACE_SECONDS = 5 * 60

# Bucket sizes for aggregation tiers.
BUCKET_5MIN = 5 * 60
BUCKET_HOURLY = 60 * 60

# Numeric sample columns that query_range may select. `metric` is interpolated
# into the SQL column position there, so this internal allowlist (L11) is
# defense-in-depth: callers already validate against status.HISTORY_METRICS, but
# a future caller that forgets cannot inject. Derived from SAMPLE_FIELDS so it
# stays in sync; the non-numeric/identity columns are excluded.
_QUERYABLE_METRICS = frozenset(SAMPLE_FIELDS) - {"ts", "status", "connection_state"}


def _to_float(value) -> Optional[float]:
    """Lenient float coercion. Returns ``None`` for empty / non-numeric.

    R2-05: non-finite readings (NUT ``inf``, ``nan``, ``1e400``) are dropped
    too. Stored, they would reach ``/history`` as a literal ``Infinity``
    (invalid JSON) and sit in the 5-year hourly tier.
    """
    if value is None or value == "":
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _to_int(value) -> Optional[int]:
    f = _to_float(value)
    return int(f) if f is not None else None


def _to_input_voltage(value, *, ups_status: str) -> Optional[float]:
    """Sanitize ``input.voltage`` against on-line phantom zeros.

    A reading of 0 V is meaningful when the UPS is on battery (mains is
    actually gone, the inverter holds the output). On line, 0 V is a
    sensor glitch or poll race against a NUT driver mid-transition --
    keeping it pollutes the graph and drags the AVG/MIN aggregates. Drop
    only the latter case; outage history stays intact.

    The "is OB present" predicate matches the convention used by
    ``_handle_on_battery`` in ``monitor.py`` -- ``OL OB`` (a transient
    mid-transition status) is treated as "on battery", so its 0 V is
    kept. ``BOOST`` / ``TRIM`` / ``BYPASS`` etc. are AVR/bypass states
    *of* the on-line condition; they're excluded from the drop set
    below by the explicit ``"OL" in status`` check.
    """
    f = _to_float(value)
    if f is None:
        return None
    status = ups_status or ""
    if (f <= 0.0 and status_has_token(status, "OL")
            and not status_has_token(status, "OB")
            and not status_has_token(status, "FSD")):
        return None
    return f


def _to_battery_charge(value, *, ups_status: str) -> Optional[float]:
    """Sanitize ``battery.charge`` against on-line phantom zeros.

    A network-polled UPS (notably a monitoring-only NUT slave) occasionally
    returns ``0`` for ``battery.charge`` on a partial / mid-transition poll --
    seen as brief ``OL LB RB`` / ``ALARM OL`` flaps in the log. Stored
    verbatim it draws a false plunge-to-zero on the charge graph and drags the
    AVG/MIN aggregates. A genuine 0% only occurs deep in an outage -- on line
    power the UPS would have shut down long before -- so drop a ``<= 0`` reading
    only while on-line (mirrors ``_to_input_voltage``); on battery / FSD the low
    reading is kept so real depletion history stays intact.
    """
    f = _to_float(value)
    if f is None:
        return None
    status = ups_status or ""
    if (f <= 0.0 and status_has_token(status, "OL")
            and not status_has_token(status, "OB")
            and not status_has_token(status, "FSD")):
        return None
    return f


def _sample_from_ups_data(
    ups_data: Dict[str, str],
    *,
    depletion_rate: float = 0.0,
    time_on_battery: int = 0,
    connection_state: str = "OK",
    ts: Optional[int] = None,
) -> Tuple:
    """Project a raw upsc dict + state context into a SAMPLE_FIELDS tuple.

    Tuple positions are locked to the SAMPLE_FIELDS order so the same
    ``executemany`` works against any schema version reached via
    additive migrations.
    """
    status = ups_data.get("ups.status", "")
    return (
        int(ts if ts is not None else time.time()),
        status,
        _to_battery_charge(ups_data.get("battery.charge"), ups_status=status),
        _to_float(ups_data.get("battery.runtime")),
        _to_float(ups_data.get("ups.load")),
        _to_input_voltage(ups_data.get("input.voltage"), ups_status=status),
        _to_float(ups_data.get("output.voltage")),
        float(depletion_rate or 0.0),
        int(time_on_battery or 0),
        connection_state or "OK",
        _to_float(ups_data.get("battery.voltage")),
        _to_float(ups_data.get("ups.temperature")),
        _to_float(ups_data.get("input.frequency")),
        _to_float(ups_data.get("output.frequency")),
        _to_float(ups_data.get("ups.realpower")),
        _to_float(ups_data.get("ups.power.nominal")),
        _to_float(ups_data.get("ups.realpower.nominal")),
    )


class StatsStore:
    """Per-UPS SQLite store with WAL, in-memory buffer, and tiered retention.

    Construction is cheap; call :meth:`open` once before use. The store
    is single-writer (the :class:`StatsWriter` thread); read methods are
    safe from any thread because each opens its own short-lived
    connection.
    """

    def __init__(
        self,
        db_path: Path,
        *,
        retention_raw_hours: int = 24,
        retention_5min_days: int = 30,
        retention_hourly_days: int = 1825,
        buffer_maxlen: int = 100_000,
        logger=None,
    ):
        self.db_path = Path(db_path)
        self.retention_raw_hours = max(1, int(retention_raw_hours))
        self.retention_5min_days = max(1, int(retention_5min_days))
        self.retention_hourly_days = max(1, int(retention_hourly_days))
        self._buffer: deque = deque(maxlen=buffer_maxlen)
        self._buffer_lock = threading.Lock()
        self._conn: Optional[sqlite3.Connection] = None
        # v5.2: serialize ALL _conn access across threads — the
        # notification-worker thread polls pending rows while the main
        # thread inserts + caps the queue, while the StatsWriter thread
        # runs flush/aggregate/purge every 10 s / 5 min, while the TUI
        # may call query_events / query_range concurrently. Python
        # 3.13's stricter sqlite3 binding raises "SystemError: error
        # return without exception set" when concurrent execute()s
        # share a connection (CPython issue #118172). WAL underneath
        # already serializes writes; this lock keeps the Python
        # wrapper consistent. The lock is acquired by every public
        # method that touches self._conn AFTER open() returns.
        self._db_lock = threading.Lock()
        self._logger = logger
        # Rate-limit error logging (per error message text).
        self._last_error_log: Dict[str, float] = {}
        self._error_log_interval = 300.0  # 5 minutes

    # ----- lifecycle -----

    def open(self, *, recover_delivering: bool = True) -> None:
        """Open the SQLite connection and ensure the schema exists.

        Creates the parent directory if missing. Pragmas: WAL mode for
        concurrent reads, NORMAL synchronous mode (safe with WAL),
        foreign_keys off (we have none). Daemon startup should keep
        ``recover_delivering`` at the default so rows claimed by a crashed
        process are retried; one-shot helpers that already own a live claim can
        disable it so their own verification reads do not reset the claim.
        """
        # Defensive: pip installs don't run nfpm's directory entry, so
        # the daemon must be willing to create /var/lib/eneru itself.
        try:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            self._log_error_once(f"stats: mkdir {self.db_path.parent} failed: {e}")
            raise
        # Default deferred isolation: sqlite3 opens an implicit
        # transaction on first DML, and the `with self._conn:` blocks
        # below commit/rollback as expected. With isolation_level=None
        # the connection runs in autocommit mode and the `with` blocks
        # become no-ops, so executemany() would have committed every
        # row individually instead of batching the flush.
        conn = sqlite3.connect(
            str(self.db_path),
            check_same_thread=False,
        )
        try:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA synchronous = NORMAL")
            conn.execute("PRAGMA temp_store = MEMORY")
            # Bound the writer's wait if a slow reader (TUI) is mid-query
            # on slow storage (SD card on a Raspberry Pi). 500 ms is well
            # under the 10 s flush interval, so a stalled reader can never
            # hold up the writer thread for longer than that bound.
            conn.execute("PRAGMA busy_timeout = 500")
            self._conn = conn
            self._init_schema()
            if recover_delivering:
                self._recover_delivering_notifications()
        except Exception:
            self._conn = None
            try:
                conn.close()
            except Exception:
                pass
            raise

    def apply_reload(self, stats_config) -> bool:
        """Live-apply retention changes from a reloaded config.

        Retention windows are plain attributes read by the purge cycle, so
        updating them is safe at runtime. The DB path is NOT changed here (that
        needs a restart). Returns True.
        """
        r = stats_config.retention
        # Hold the store lock so the purge thread doesn't read a half-updated
        # set of the three retention windows.
        with self._db_lock:
            self.retention_raw_hours = max(1, int(r.raw_hours))
            self.retention_5min_days = max(1, int(r.agg_5min_days))
            self.retention_hourly_days = max(1, int(r.agg_hourly_days))
        return True

    @property
    def is_open(self) -> bool:
        """True when the store has a live DB connection (open, not yet closed)."""
        return self._conn is not None

    @contextmanager
    def _write(self):
        """Run a write transaction under the DB lock, re-checking the
        connection AFTER acquiring it.

        A caller's pre-lock ``if self._conn is None`` guard is stale once the
        lock is released: a concurrent ``close()`` (which nulls ``_conn`` while
        holding ``_db_lock``) can win the race, after which ``with self._conn:``
        would raise ``AttributeError`` on ``None``. Yields the live connection,
        or ``None`` when the store closed concurrently — callers must treat
        ``None`` as a no-op and return their empty result."""
        with self._db_lock:
            conn = self._conn
            if conn is None:
                yield None
                return
            with conn:
                yield conn

    def close(self) -> None:
        try:
            self.flush()
        except Exception:  # pragma: no cover -- defensive
            pass
        with self._db_lock:
            conn = self._conn
            self._conn = None
            if conn is None:
                return
            try:
                conn.close()
            except Exception:  # pragma: no cover -- defensive
                pass

    # ----- schema -----

    def _init_schema(self) -> None:
        cols_samples = ",\n  ".join(
            f"{name} {dtype}" for name, dtype in (
                ("ts", "INTEGER NOT NULL"),
                ("status", "TEXT"),
                ("battery_charge", "REAL"),
                ("battery_runtime", "REAL"),
                ("ups_load", "REAL"),
                ("input_voltage", "REAL"),
                ("output_voltage", "REAL"),
                ("depletion_rate", "REAL"),
                ("time_on_battery", "INTEGER"),
                ("connection_state", "TEXT"),
                # v2 additions:
                ("battery_voltage", "REAL"),
                ("ups_temperature", "REAL"),
                ("input_frequency", "REAL"),
                ("output_frequency", "REAL"),
                # v7 additions (energy tracking):
                ("real_power", "REAL"),
                ("power_nominal", "REAL"),
                # v8 addition (reported rated real power in watts):
                ("real_power_nominal", "REAL"),
            )
        )
        agg_cols = """
            ts INTEGER PRIMARY KEY,
            battery_charge_avg REAL,
            battery_charge_min REAL,
            battery_charge_max REAL,
            battery_runtime_avg REAL,
            ups_load_avg REAL,
            ups_load_max REAL,
            input_voltage_avg REAL,
            input_voltage_min REAL,
            input_voltage_max REAL,
            samples_count INTEGER,
            -- v2 additions:
            output_voltage_avg REAL,
            battery_voltage_avg REAL,
            ups_temperature_avg REAL,
            ups_temperature_min REAL,
            ups_temperature_max REAL,
            input_frequency_avg REAL,
            output_frequency_avg REAL,
            real_power_avg REAL,
            power_nominal_avg REAL,
            real_power_nominal_avg REAL
        """
        # F-027: was this DB already populated before we (re)create the tables?
        # A DB that has the `samples` table but NO `schema_version` meta row is
        # NOT brand-new -- it is an older binary's DB that crashed after the DDL
        # committed but before the version stamp. ELI5: you find a fully-furnished
        # house with no "built in YYYY" plaque. Treating it as a bare lot (brand
        # new) skips every renovation (migration) and leaves it missing rooms
        # (columns) the current code expects -> silent stats loss. Capture the
        # fact here, BEFORE `CREATE TABLE IF NOT EXISTS` makes the table appear.
        pre_existing = self._table_exists("samples")
        with self._conn:
            self._conn.executescript(f"""
                CREATE TABLE IF NOT EXISTS samples (
                    {cols_samples}
                );
                CREATE INDEX IF NOT EXISTS idx_samples_ts ON samples(ts);

                CREATE TABLE IF NOT EXISTS agg_5min (
                    {agg_cols}
                );

                CREATE TABLE IF NOT EXISTS agg_hourly (
                    {agg_cols}
                );

                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts INTEGER NOT NULL,
                    event_type TEXT NOT NULL,
                    detail TEXT,
                    notification_sent INTEGER DEFAULT 1
                );
                CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);

                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT
                );

                -- v4: persistent notification queue. The worker reads/writes
                -- through this table so messages survive process death and
                -- prolonged endpoint outages. Pending rows are NEVER pruned
                -- by retention TTL — only sent/cancelled rows are.
                CREATE TABLE IF NOT EXISTS notifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts INTEGER NOT NULL,
                    body TEXT NOT NULL,
                    notify_type TEXT NOT NULL,
                    category TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    sent_at INTEGER,
                    delivering_at INTEGER,
                    cancel_reason TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_notifications_status_ts
                    ON notifications(status, ts);

                -- v7: battery-health history (one row per periodic
                -- computation; feeds replacement-prediction trending). A
                -- NULL term column means "unavailable" -- deliberately
                -- distinct from a 0 sub-score, so an unknown score is never
                -- confused with a failing one. detail carries the JSON
                -- breakdown (weights, confidence, raw inputs).
                CREATE TABLE IF NOT EXISTS battery_health (
                    ts INTEGER PRIMARY KEY,
                    score REAL,
                    capacity REAL,
                    runtime REAL,
                    self_test REAL,
                    anomaly REAL,
                    age REAL,
                    detail TEXT
                );

                -- v7: self-test results. One row per issued or device-observed
                -- test; an active row starts 'running' and is updated once
                -- upsd reports a result. result_enum is the normalized form
                -- (passed|warning|failed|aborted|running|unknown|unsupported) the
                -- API/Prometheus/UI consume; result_raw keeps the original
                -- ups.test.result string.
                CREATE TABLE IF NOT EXISTS self_tests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_ts INTEGER NOT NULL,
                    command TEXT NOT NULL,
                    result_raw TEXT,
                    result_enum TEXT,
                    result_date TEXT,
                    source TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_self_tests_started
                    ON self_tests(started_ts);
            """)
            self._migrate_schema(pre_existing=pre_existing)
            self._conn.execute(
                "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
                ("schema_version", str(SCHEMA_VERSION)),
            )

    def _migrate_schema(self, *, pre_existing: bool = False) -> None:
        """Apply additive schema migrations keyed off ``meta.schema_version``.

        See ``src/eneru/AGENTS.md`` ("Stats schema evolution") for the
        full pattern. Rules:

        1. Migrations are append-only — never modify a previous block.
        2. Each ``ALTER TABLE`` is wrapped so duplicate columns are a
           no-op (idempotent on retries / partially-migrated DBs).
        3. ``meta.schema_version`` is bumped *after* the migrations
           succeed so a crash mid-migration is replayed safely.

        ``pre_existing`` (F-027): the ``samples`` table already existed before
        this open. When True and there is NO ``schema_version`` row, the DB is a
        crashed older instance -- NOT brand-new -- so we replay the full additive
        chain from v1. Every step is idempotent (``_safe_alter`` tolerates
        duplicate columns, DDL uses ``IF NOT EXISTS``), so re-running the chain
        against an already-current schema is a harmless no-op; the point is that a
        versionless-but-populated DB gets migrated + stamped instead of silently
        mistaken for fresh.
        """
        cur = self._conn.execute(
            "SELECT value FROM meta WHERE key='schema_version'"
        ).fetchone()
        if cur is None:
            if not pre_existing:
                # Genuinely brand-new DB; CREATE TABLE above already includes
                # every current column, so no ALTERs are needed.
                return
            # Versionless but populated: recover as the oldest schema and let the
            # idempotent chain below bring it fully current.
            current = 1
        else:
            try:
                current = int(cur[0])
            except (TypeError, ValueError):
                current = 1

        if current < 2:
            # v1 -> v2: 4 raw NUT metric columns on samples; matching
            # *_avg (and *_min/*_max for temperature) on the agg tables;
            # plus output_voltage_avg that closes the long-standing gap
            # in _agg_column_for.
            v2_samples = (
                "battery_voltage REAL",
                "ups_temperature REAL",
                "input_frequency REAL",
                "output_frequency REAL",
            )
            v2_agg = (
                "output_voltage_avg REAL",
                "battery_voltage_avg REAL",
                "ups_temperature_avg REAL",
                "ups_temperature_min REAL",
                "ups_temperature_max REAL",
                "input_frequency_avg REAL",
                "output_frequency_avg REAL",
            )
            for col in v2_samples:
                self._safe_alter("samples", col)
            for table in ("agg_5min", "agg_hourly"):
                for col in v2_agg:
                    self._safe_alter(table, col)

        if current < 3:
            # v2 -> v3: events.notification_sent (1 = logged + notified,
            # 0 = logged but suppressed). Default 1 for backfilled rows
            # so historical events stay queryable without losing the
            # "yes, this fired before suppression existed" interpretation.
            # Lets users audit muted events:
            #   SELECT event_type, COUNT(*) FROM events
            #   WHERE notification_sent = 0 GROUP BY event_type;
            self._safe_alter("events",
                             "notification_sent INTEGER DEFAULT 1")

        if current < 4:
            # v3 -> v4: persistent notification queue. New table + index;
            # no ALTERs to existing tables. Idempotent via CREATE IF NOT
            # EXISTS so a partially-migrated DB heals on next open.
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS notifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts INTEGER NOT NULL,
                    body TEXT NOT NULL,
                    notify_type TEXT NOT NULL,
                    category TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    sent_at INTEGER,
                    delivering_at INTEGER,
                    cancel_reason TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_notifications_status_ts
                    ON notifications(status, ts);
            """)

        if current < 5:
            # v4 -> v5: give events a stable, never-reused id
            # (INTEGER PRIMARY KEY AUTOINCREMENT). SQLite can't ALTER ADD a
            # PRIMARY KEY column, so rebuild the table, preserving each row's
            # identity as id = old rowid. AUTOINCREMENT guarantees a deleted
            # event's id is never handed to a later row -- that's what makes the
            # API's delete-by-id safe.
            self._migrate_events_to_v5()

        if current < 6:
            # v5 -> v6: timestamp claimed deferred-delivery rows. Startup
            # recovery only steals stale claims, so a live one-shot helper that
            # is actively sending a stop notification is not duplicated.
            self._safe_alter("notifications", "delivering_at INTEGER")

        if current < 7:
            # v6 -> v7: energy tracking + battery-health/self-test history.
            # Two raw NUT power columns on samples and their *_avg on the agg
            # tables (kWh is integrated on read in energy.py, so no stored
            # cumulative column). Plus two new tables, created idempotently
            # via CREATE IF NOT EXISTS so a partially-migrated DB heals.
            for col in ("real_power REAL", "power_nominal REAL"):
                self._safe_alter("samples", col)
            for table in ("agg_5min", "agg_hourly"):
                for col in ("real_power_avg REAL", "power_nominal_avg REAL"):
                    self._safe_alter(table, col)
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS battery_health (
                    ts INTEGER PRIMARY KEY,
                    score REAL,
                    capacity REAL,
                    runtime REAL,
                    self_test REAL,
                    anomaly REAL,
                    age REAL,
                    detail TEXT
                );
                CREATE TABLE IF NOT EXISTS self_tests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_ts INTEGER NOT NULL,
                    command TEXT NOT NULL,
                    result_raw TEXT,
                    result_enum TEXT,
                    result_date TEXT,
                    source TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_self_tests_started
                    ON self_tests(started_ts);
            """)

        if current < 8:
            # v7 -> v8: preserve NUT's rated real power (W) separately from
            # ups.power.nominal (VA). Energy estimation must prefer watts and
            # must never silently label apparent power as measured watts.
            self._safe_alter("samples", "real_power_nominal REAL")
            for table in ("agg_5min", "agg_hourly"):
                self._safe_alter(table, "real_power_nominal_avg REAL")

    def _migrate_events_to_v5(self) -> None:
        """Rebuild ``events`` with a stable id column.

        DDL in ``executescript`` can commit outside the surrounding context
        manager, so the destructive rebuild uses an explicit savepoint. That
        keeps the old table intact if a crash or SQLite error lands between the
        copy and the rename.
        """
        self._conn.execute("SAVEPOINT migrate_events_v5")
        try:
            if self._events_has_v5_id():
                # Recover a DB opened after an older unsafe rebuild died after
                # copying rows and dropping events, but before the final rename.
                if self._table_exists("events_v5_new"):
                    event_count = self._conn.execute(
                        "SELECT COUNT(*) FROM events"
                    ).fetchone()[0]
                    scratch_count = self._conn.execute(
                        "SELECT COUNT(*) FROM events_v5_new"
                    ).fetchone()[0]
                    if event_count == 0 and scratch_count > 0:
                        self._conn.execute("DROP TABLE events")
                        self._conn.execute(
                            "ALTER TABLE events_v5_new RENAME TO events"
                        )
                    else:
                        self._conn.execute("DROP TABLE events_v5_new")
            else:
                self._conn.execute("DROP TABLE IF EXISTS events_v5_new")
                self._conn.execute("""
                    CREATE TABLE events_v5_new (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ts INTEGER NOT NULL,
                        event_type TEXT NOT NULL,
                        detail TEXT,
                        notification_sent INTEGER DEFAULT 1
                    )
                """)
                self._conn.execute("""
                    INSERT INTO events_v5_new
                        (id, ts, event_type, detail, notification_sent)
                    SELECT rowid, ts, event_type, detail, notification_sent
                    FROM events
                """)
                self._conn.execute("DROP TABLE events")
                self._conn.execute("ALTER TABLE events_v5_new RENAME TO events")

            self._conn.execute("CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts)")
            # Pin the AUTOINCREMENT high-water mark to the max preserved id so a
            # later delete of the highest row can never let a new event reuse it
            # (belt-and-suspenders alongside RENAME's sqlite_sequence fixup).
            self._conn.execute(
                "INSERT OR REPLACE INTO sqlite_sequence(name, seq) "
                "SELECT 'events', COALESCE(MAX(id), 0) FROM events"
            )
            self._conn.execute("RELEASE SAVEPOINT migrate_events_v5")
        except Exception:
            self._conn.execute("ROLLBACK TO SAVEPOINT migrate_events_v5")
            self._conn.execute("RELEASE SAVEPOINT migrate_events_v5")
            raise

    def _table_exists(self, name: str) -> bool:
        row = self._conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (name,),
        ).fetchone()
        return row is not None

    def _events_has_v5_id(self) -> bool:
        return any(
            row[1] == "id" and row[5] == 1
            for row in self._conn.execute("PRAGMA table_info(events)")
        )

    def _recover_delivering_notifications(self) -> None:
        """Move abandoned deferred-delivery claims back to pending."""
        if self._conn is None:
            return
        cutoff = int(time.time()) - DELIVERING_RECOVERY_GRACE_SECONDS
        try:
            with self._conn:
                self._conn.execute(
                    "UPDATE notifications SET status='pending', sent_at=NULL, "
                    "delivering_at=NULL WHERE status='delivering' "
                    "AND (delivering_at IS NULL OR delivering_at <= ?)",
                    (cutoff,),
                )
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: recover notification deliveries failed: {e}"
            )
            raise

    def _safe_alter(self, table: str, column_def: str) -> None:
        """Idempotent ``ALTER TABLE ... ADD COLUMN``; ignores duplicates."""
        try:
            self._conn.execute(f"ALTER TABLE {table} ADD COLUMN {column_def}")
        except sqlite3.OperationalError as exc:
            # Column already exists -- benign on retries / partial migrations.
            if "duplicate column name" in str(exc).lower():
                return
            raise

    # ----- hot path: zero-I/O sample buffering -----

    def buffer_sample(
        self,
        ups_data: Dict[str, str],
        *,
        depletion_rate: float = 0.0,
        time_on_battery: int = 0,
        connection_state: str = "OK",
        ts: Optional[int] = None,
    ) -> None:
        """Append one sample to the in-memory buffer. Constant time, no I/O."""
        sample = _sample_from_ups_data(
            ups_data,
            depletion_rate=depletion_rate,
            time_on_battery=time_on_battery,
            connection_state=connection_state,
            ts=ts,
        )
        with self._buffer_lock:
            self._buffer.append(sample)

    # ----- writer-thread operations -----

    def flush(self) -> int:
        """Persist the buffered samples in one transaction.

        Returns the number of rows actually written (0 if the buffer was
        empty or the DB is unavailable).
        """
        if self._conn is None:
            return 0
        with self._buffer_lock:
            if not self._buffer:
                return 0
            in_flight = self._buffer
            self._buffer = deque(maxlen=in_flight.maxlen)
            batch: List[Tuple] = list(in_flight)
        try:
            with self._db_lock:
                conn = self._conn
                if conn is None:
                    raise sqlite3.Error("connection closed")
                placeholders = ", ".join("?" for _ in SAMPLE_FIELDS)
                with conn:
                    conn.executemany(
                        f"INSERT INTO samples ({', '.join(SAMPLE_FIELDS)}) "
                        f"VALUES ({placeholders})",
                        batch,
                    )
            return len(batch)
        except (sqlite3.Error, OSError) as e:
            with self._buffer_lock:
                maxlen = self._buffer.maxlen
                merged = list(in_flight) + list(self._buffer)
                if maxlen is not None and len(merged) > maxlen:
                    merged = merged[-maxlen:]
                self._buffer = deque(merged, maxlen=maxlen)
            self._log_error_once(f"stats: flush failed: {e}")
            return 0

    def aggregate(self) -> Tuple[int, int]:
        """Roll samples into 5-min buckets, and 5-min into hourly buckets.

        Returns ``(rows_inserted_5min, rows_inserted_hourly)``.

        ISS-037: instead of re-GROUP-BYing the entire ``samples`` /
        ``agg_5min`` tables every cycle (rewriting every finalized bucket
        on each tick), each tier keeps a persisted *watermark* — the
        newest bucket start seen on the previous run. A run reprocesses
        only buckets from ``watermark - one_bucket`` forward, so the
        boundary bucket (which may still be collecting rows) is recomputed
        from its full membership while older, already-finalized buckets
        are left untouched. Samples are appended in time order, so a
        bucket is never revisited once the watermark passes it. The
        watermark lives in the key/value ``meta`` table, so this needs no
        column change and therefore no ``SCHEMA_VERSION`` bump. When no
        watermark exists yet (fresh DB / first run after upgrade) the
        whole table is processed, which reproduces the pre-ISS-037 result
        exactly.

        Correctness rests on samples arriving in time order (they are
        appended live at ~1 Hz). The one divergence from a full
        re-aggregation is a backward wall-clock step larger than a bucket
        (e.g. a big NTP correction): a sample landing in an
        already-finalized older bucket would be folded in by a full
        re-scan but skipped here. That is an accepted trade — buckets use
        wall-clock ``ts`` and such a step corrupts the tiering regardless.
        """
        if self._conn is None:
            return (0, 0)
        try:
            with self._write() as conn:
                if conn is None:
                    return (0, 0)

                # ---- 5-min tier ----
                row = conn.execute(
                    "SELECT value FROM meta WHERE key='agg_5min_watermark'"
                ).fetchone()
                # cubic P2: tolerant parse — a malformed watermark (corrupt/
                # tampered meta row) becomes None (full re-scan) instead of
                # raising ValueError, which would bypass this method's
                # sqlite/OSError handler and stop aggregation silently.
                lo_5 = _to_int(row[0]) if row else None
                if lo_5 is None:
                    where_5, params_5 = "", ()
                else:
                    where_5 = f"WHERE ts >= {max(0, lo_5 - BUCKET_5MIN)}"
                    params_5 = ()
                inserted_5 = conn.execute(f"""
                    INSERT OR REPLACE INTO agg_5min (
                        ts,
                        battery_charge_avg, battery_charge_min, battery_charge_max,
                        battery_runtime_avg,
                        ups_load_avg, ups_load_max,
                        input_voltage_avg, input_voltage_min, input_voltage_max,
                        samples_count,
                        output_voltage_avg, battery_voltage_avg,
                        ups_temperature_avg, ups_temperature_min, ups_temperature_max,
                        input_frequency_avg, output_frequency_avg,
                        real_power_avg, power_nominal_avg,
                        real_power_nominal_avg
                    )
                    SELECT
                        (ts / {BUCKET_5MIN}) * {BUCKET_5MIN} AS bucket,
                        AVG(battery_charge), MIN(battery_charge), MAX(battery_charge),
                        AVG(battery_runtime),
                        AVG(ups_load), MAX(ups_load),
                        AVG(input_voltage), MIN(input_voltage), MAX(input_voltage),
                        COUNT(*),
                        AVG(output_voltage), AVG(battery_voltage),
                        AVG(ups_temperature), MIN(ups_temperature), MAX(ups_temperature),
                        AVG(input_frequency), AVG(output_frequency),
                        AVG(real_power), AVG(power_nominal),
                        AVG(real_power_nominal)
                    FROM samples
                    {where_5}
                    GROUP BY bucket
                """, params_5).rowcount
                new_lo_5 = conn.execute(
                    f"SELECT MAX((ts / {BUCKET_5MIN}) * {BUCKET_5MIN}) "
                    "FROM samples"
                ).fetchone()[0]
                if new_lo_5 is not None:
                    conn.execute(
                        "INSERT OR REPLACE INTO meta(key, value) VALUES "
                        "('agg_5min_watermark', ?)", (str(int(new_lo_5)),),
                    )

            # F-044: aggregate() used to hold _db_lock across BOTH tiers in ONE
            # transaction, so the first run after a gap re-scanned ~86k rows
            # while the monitor thread blocked on the same lock (seconds on an
            # SD-card host). ELI5: don't hog the kitchen for the whole meal —
            # finish the appetizer (the 5-min tier), step out so the next cook
            # can grab a pot (a monitor-thread sample write), then come back for
            # the main course (the hourly tier). Each tier commits in its OWN
            # transaction now; the hourly tier reads the agg_5min rows the first
            # tier just committed, and the persisted watermarks keep both tiers
            # idempotent, so splitting the lock changes nothing about the result.
            # The optional hook lets tests prove the lock is genuinely free here.
            hook = getattr(self, "_aggregate_between_tiers", None)
            if hook is not None:
                hook()

            with self._write() as conn:
                if conn is None:
                    return (max(0, inserted_5), 0)

                # ---- hourly tier ----
                row = conn.execute(
                    "SELECT value FROM meta WHERE key='agg_hourly_watermark'"
                ).fetchone()
                lo_h = _to_int(row[0]) if row else None  # cubic P2: tolerant parse
                if lo_h is None:
                    where_h, params_h = "", ()
                else:
                    where_h = f"WHERE ts >= {max(0, lo_h - BUCKET_HOURLY)}"
                    params_h = ()
                inserted_h = conn.execute(f"""
                    INSERT OR REPLACE INTO agg_hourly (
                        ts,
                        battery_charge_avg, battery_charge_min, battery_charge_max,
                        battery_runtime_avg,
                        ups_load_avg, ups_load_max,
                        input_voltage_avg, input_voltage_min, input_voltage_max,
                        samples_count,
                        output_voltage_avg, battery_voltage_avg,
                        ups_temperature_avg, ups_temperature_min, ups_temperature_max,
                        input_frequency_avg, output_frequency_avg,
                        real_power_avg, power_nominal_avg,
                        real_power_nominal_avg
                    )
                    SELECT
                        (ts / {BUCKET_HOURLY}) * {BUCKET_HOURLY} AS bucket,
                        AVG(battery_charge_avg),
                        MIN(battery_charge_min), MAX(battery_charge_max),
                        AVG(battery_runtime_avg),
                        AVG(ups_load_avg), MAX(ups_load_max),
                        AVG(input_voltage_avg),
                        MIN(input_voltage_min), MAX(input_voltage_max),
                        SUM(samples_count),
                        AVG(output_voltage_avg), AVG(battery_voltage_avg),
                        AVG(ups_temperature_avg),
                        MIN(ups_temperature_min), MAX(ups_temperature_max),
                        AVG(input_frequency_avg), AVG(output_frequency_avg),
                        AVG(real_power_avg), AVG(power_nominal_avg),
                        AVG(real_power_nominal_avg)
                    FROM agg_5min
                    {where_h}
                    GROUP BY bucket
                """, params_h).rowcount
                new_lo_h = conn.execute(
                    f"SELECT MAX((ts / {BUCKET_HOURLY}) * {BUCKET_HOURLY}) "
                    "FROM agg_5min"
                ).fetchone()[0]
                if new_lo_h is not None:
                    conn.execute(
                        "INSERT OR REPLACE INTO meta(key, value) VALUES "
                        "('agg_hourly_watermark', ?)", (str(int(new_lo_h)),),
                    )
            return (max(0, inserted_5), max(0, inserted_h))
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: aggregate failed: {e}")
            return (0, 0)

    def purge(self) -> Tuple[int, int, int]:
        """Apply retention. Returns ``(samples, agg_5min, agg_hourly)`` deleted.

        ``events``, ``battery_health`` and ``self_tests`` are also trimmed to the
        hourly cutoff (not reflected in the returned tuple, which stays the
        three metric tiers for back-compat). battery_health/self_tests are
        otherwise unbounded — one row per update_interval / per issued test —
        so a small update_interval would grow them without limit.
        """
        if self._conn is None:
            return (0, 0, 0)
        now = int(time.time())
        cutoff_raw = now - self.retention_raw_hours * 3600
        cutoff_5min = now - self.retention_5min_days * 86400
        cutoff_hourly = now - self.retention_hourly_days * 86400
        # M5: align the raw/5-min cutoffs DOWN to the next-tier bucket boundary
        # so purge only ever deletes WHOLE buckets' worth of rows. Otherwise it
        # trims the early rows of the bucket straddling the cutoff, and the next
        # aggregate() re-derives that already-finalized bucket from the reduced
        # set -- overwriting its avg/min/max with wrong values that then
        # propagate into the hourly tier. Keeping at most one extra bucket of raw
        # data (~5 min) / 5-min data (~1 h) is a negligible retention cost.
        cutoff_raw = (cutoff_raw // BUCKET_5MIN) * BUCKET_5MIN
        cutoff_5min = (cutoff_5min // BUCKET_HOURLY) * BUCKET_HOURLY
        try:
            with self._write() as conn:
                if conn is None:
                    return (0, 0, 0)
                deleted_raw = conn.execute(
                    "DELETE FROM samples WHERE ts < ?", (cutoff_raw,),
                ).rowcount
                deleted_5min = conn.execute(
                    "DELETE FROM agg_5min WHERE ts < ?", (cutoff_5min,),
                ).rowcount
                deleted_hourly = conn.execute(
                    "DELETE FROM agg_hourly WHERE ts < ?", (cutoff_hourly,),
                ).rowcount
                conn.execute(
                    "DELETE FROM events WHERE ts < ?", (cutoff_hourly,),
                )
                # v7 history tables: one row per periodic computation / issued
                # test, so they grow unbounded at a small update_interval. Trim
                # them on the same hourly cutoff as events. self_tests keys on
                # its own timestamp column (started_ts).
                conn.execute(
                    "DELETE FROM battery_health WHERE ts < ?", (cutoff_hourly,),
                )
                conn.execute(
                    "DELETE FROM self_tests WHERE started_ts < ?",
                    (cutoff_hourly,),
                )
            return (
                max(0, deleted_raw),
                max(0, deleted_5min),
                max(0, deleted_hourly),
            )
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: purge failed: {e}")
            return (0, 0, 0)

    # ----- events API -----

    def log_event(self, event_type: str, detail: str = "",
                  ts: Optional[int] = None,
                  *, notification_sent: bool = True) -> None:
        """Insert one event row. Safe to call from any thread.

        ``notification_sent`` (v3+) records whether the daemon dispatched
        a notification for this event. Pass ``False`` when the event
        was logged but the notification was suppressed (via
        ``notifications.suppress`` or hysteresis debounce). Logs are
        sacred -- this column lets users audit what was muted:

            SELECT event_type, COUNT(*) FROM events
            WHERE notification_sent = 0 GROUP BY event_type;
        """
        if self._conn is None:
            return
        ts = int(ts if ts is not None else time.time())
        try:
            with self._write() as conn:
                if conn is None:
                    return
                conn.execute(
                    "INSERT INTO events (ts, event_type, detail, "
                    "notification_sent) VALUES (?, ?, ?, ?)",
                    (ts, str(event_type), str(detail),
                     1 if notification_sent else 0),
                )
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: log_event failed: {e}")

    def query_events(self, start_ts: int, end_ts: int) -> List[Tuple]:
        """Return events in ``[start_ts, end_ts]`` ascending by ts."""
        if self._conn is None:
            return []
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return []
                cur = self._conn.execute(
                    "SELECT ts, event_type, detail FROM events "
                    "WHERE ts BETWEEN ? AND ? ORDER BY ts ASC",
                    (int(start_ts), int(end_ts)),
                )
                return cur.fetchall()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: query_events failed: {e}")
            return []

    def latest_event_ts(self, event_type: str) -> Optional[int]:
        """Return MAX(ts) for one event_type, or None if there are none.

        ISS-038: lets callers resolve e.g. the latest DAEMON_START without
        loading every retained event row into Python just to take a max().
        ``event_type`` is an internal identifier (never user input)."""
        if self._conn is None:
            return None
        try:
            with self._db_lock:
                if self._conn is None:
                    return None
                cur = self._conn.execute(
                    "SELECT MAX(ts) FROM events WHERE event_type = ?",
                    (str(event_type),),
                )
                row = cur.fetchone()
                return int(row[0]) if row and row[0] is not None else None
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: latest_event_ts failed: {e}")
            return None

    def query_recent_events(
        self,
        *,
        end_ts: int,
        limit: int,
        start_ts: Optional[int] = None,
        include_types: Optional[set] = None,
        exclude_types: Optional[set] = None,
        include_id: bool = False,
        before_id: Optional[int] = None,
    ) -> List[Tuple]:
        """Return recent events ascending by ts without loading full history.

        * ``end_ts`` — inclusive upper bound (``ts <= end_ts``); "load older"
          paging sets this to the oldest timestamp already shown.
        * ``start_ts`` — inclusive lower bound (``ts >= start_ts``).
        * ``include_id`` — prepend the row's ``id`` to each returned tuple (off by
          default, so existing 3-tuple callers are unaffected). The id is unique
          only within this one per-UPS DB; the aggregating layer source-qualifies
          it and the dashboard de-dups by ``(source, id)`` across pages.
        * ``before_id`` — with ``end_ts``, use a strict same-second upper bound
          ``(ts, id) < (end_ts, before_id)`` for source-qualified paging.
        """
        if self._conn is None:
            return []
        limit = max(1, int(limit))
        if before_id is None:
            clauses = ["ts <= ?"]
            params: List[Any] = [int(end_ts)]
        else:
            clauses = ["(ts < ? OR (ts = ? AND id < ?))"]
            params = [int(end_ts), int(end_ts), int(before_id)]
        if start_ts is not None:
            clauses.append("ts >= ?")
            params.append(int(start_ts))
        if include_types:
            placeholders = ", ".join("?" for _ in include_types)
            clauses.append(f"event_type IN ({placeholders})")
            params.extend(sorted(str(item) for item in include_types))
        if exclude_types:
            placeholders = ", ".join("?" for _ in exclude_types)
            clauses.append(f"event_type NOT IN ({placeholders})")
            params.extend(sorted(str(item) for item in exclude_types))
        params.append(limit)
        # ``rowid`` is the implicit insertion-order key — using it as
        # the tiebreaker makes "latest N events" deterministic when
        # multiple events share the same second (notification fanout,
        # rapid trigger flap), so paginated reads don't return
        # different subsets across calls.
        cols = "id, ts, event_type, detail" if include_id else \
            "ts, event_type, detail"
        query = (
            f"SELECT {cols} FROM events "
            f"WHERE {' AND '.join(clauses)} "
            "ORDER BY ts DESC, id DESC LIMIT ?"
        )
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return []
                cur = self._conn.execute(query, params)
                return list(reversed(cur.fetchall()))
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: query_recent_events failed: {e}")
            return []

    def delete_events(self, items) -> int:
        """Delete events by ``(id, ts, event_type)``. Returns the count removed.

        Each row is matched on all three columns, not just ``id``: the id alone
        is authoritative (AUTOINCREMENT never reuses one), but the ts/type guard
        means a stale client request can only ever delete the exact row it saw —
        a mismatch deletes nothing (counts as 0, not an error). Idempotent on
        duplicates, and atomic: any SQLite error rolls the whole batch back.
        ``items`` is an iterable of ``(id, ts, event_type)``.
        """
        if self._conn is None:
            return 0
        seen = set()
        rows = []
        for it in items:
            key = (int(it[0]), int(it[1]), str(it[2]))
            if key not in seen:
                seen.add(key)
                rows.append(key)
        if not rows:
            return 0
        try:
            count = 0
            with self._write() as conn:
                if conn is None:
                    return 0
                for event_id, ts, event_type in rows:
                    cur = conn.execute(
                        "DELETE FROM events WHERE id = ? AND ts = ? "
                        "AND event_type = ?",
                        (event_id, ts, event_type),
                    )
                    count += cur.rowcount
            return count
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: delete_events failed: {e}")
            return 0

    # ----- notification queue (v4+) -----

    def enqueue_notification(self, body: str, notify_type: str,
                             category: str,
                             ts: Optional[int] = None,
                             meta_updates: Optional[Dict[str, str]] = None,
                             ) -> Optional[int]:
        """Persist a pending notification. Returns the new row id, or
        ``None`` if the store isn't open (caller should fall back).

        Safe to call from any thread (serialized via ``_db_lock``).
        """
        if self._conn is None:
            return None
        ts = int(ts if ts is not None else time.time())
        try:
            with self._write() as conn:
                if conn is None:
                    return None
                cur = conn.execute(
                    "INSERT INTO notifications "
                    "(ts, body, notify_type, category) "
                    "VALUES (?, ?, ?, ?)",
                    (ts, str(body), str(notify_type), str(category)),
                )
                if meta_updates:
                    conn.executemany(
                        "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
                        [(str(key), str(value))
                         for key, value in meta_updates.items()],
                    )
                return int(cur.lastrowid)
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: enqueue_notification failed: {e}")
            return None

    def next_pending_notifications(self,
                                   limit: int = 10,
                                   offset: int = 0) -> List[Tuple]:
        """Return up to ``limit`` oldest pending rows starting at
        ``offset``, as ``(ts, id, body, notify_type, attempts, category)``
        tuples. Order: ts ASC then id ASC for deterministic FIFO across
        same-ts ties.

        ``offset`` lets the worker paginate when the head of the queue
        is occupied by backoff-delayed rows, so newer due rows aren't
        starved (CR P1).
        """
        if self._conn is None:
            return []
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return []
                cur = self._conn.execute(
                    "SELECT ts, id, body, notify_type, attempts, category "
                    "FROM notifications WHERE status='pending' "
                    "ORDER BY ts ASC, id ASC LIMIT ? OFFSET ?",
                    (int(limit), int(offset)),
                )
                return cur.fetchall()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: next_pending_notifications failed: {e}"
            )
            return []

    def find_pending_by_category(self, category: str,
                                 since_ts: Optional[int] = None
                                 ) -> List[Tuple]:
        """Return pending rows with the given category as
        ``(id, ts, body, notify_type)`` tuples. Used by the worker's
        coalescing pass (Slice 4): scan for an open on-battery / on-line
        pair to fold into one summary."""
        if self._conn is None:
            return []
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return []
                if since_ts is None:
                    cur = self._conn.execute(
                        "SELECT id, ts, body, notify_type FROM notifications "
                        "WHERE status='pending' AND category=? "
                        "ORDER BY ts ASC",
                        (str(category),),
                    )
                else:
                    cur = self._conn.execute(
                        "SELECT id, ts, body, notify_type FROM notifications "
                        "WHERE status='pending' AND category=? AND ts>=? "
                        "ORDER BY ts ASC",
                        (str(category), int(since_ts)),
                    )
                return cur.fetchall()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: find_pending_by_category failed: {e}"
            )
            return []

    def mark_notification_sent(self, notification_id: int,
                               sent_at: Optional[int] = None,
                               *, require_delivering: bool = False) -> bool:
        """Mark a notification as delivered. Returns True when the write committed.

        ``require_delivering`` (F-058): only flip a row that is still
        ``delivering``. The deferred-delivery helper claims a row before sending
        and passes this so a classifier that cancelled the row mid-send is not
        clobbered back to ``sent`` (which would reopen the duplicate-lifecycle
        race the claim exists to close). The bool return lets that helper keep its
        "sent but mark-sent failed" audit breadcrumb when SQLite errors mid-flip.
        """
        if self._conn is None:
            return False
        sent_at = int(sent_at if sent_at is not None else time.time())
        try:
            with self._write() as conn:
                if conn is None:
                    return False
                if require_delivering:
                    conn.execute(
                        "UPDATE notifications SET status='sent', sent_at=?, "
                        "delivering_at=NULL "
                        "WHERE id=? AND status='delivering'",
                        (sent_at, int(notification_id)),
                    )
                else:
                    conn.execute(
                        "UPDATE notifications SET status='sent', sent_at=?, "
                        "delivering_at=NULL "
                        "WHERE id=?",
                        (sent_at, int(notification_id)),
                    )
            return True
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: mark_notification_sent failed: {e}"
            )
            return False

    def read_notification(
        self, notification_id: int,
    ) -> Optional[Tuple[str, str, str]]:
        """Return ``(body, notify_type, status)`` for one row, or ``None``.

        F-058: promoted onto the store so ``deferred_delivery`` no longer reaches
        into ``self._conn`` for its initial read.
        """
        if self._conn is None:
            return None
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return None
                cur = self._conn.execute(
                    "SELECT body, notify_type, status FROM notifications "
                    "WHERE id=?",
                    (int(notification_id),),
                )
                row = cur.fetchone()
                return (row[0], row[1], row[2]) if row is not None else None
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: read_notification failed: {e}")
            return None

    def claim_notification(self, notification_id: int,
                           *, now: Optional[int] = None) -> bool:
        """Atomically transition a row ``pending`` → ``delivering``.

        F-058: the deferred-delivery helper's atomic claim, promoted onto the
        store API. Returns ``True`` only if THIS caller won the row (the classifier
        hadn't already cancelled it), so exactly one deliverer ships the stop
        notification. Stamps ``delivering_at`` (startup recovery re-pends stale
        claims) and bumps ``attempts``.
        """
        if self._conn is None:
            return False
        now = int(now if now is not None else time.time())
        try:
            with self._write() as conn:
                if conn is None:
                    return False
                cur = conn.execute(
                    "UPDATE notifications SET status='delivering', sent_at=NULL, "
                    "delivering_at=?, attempts=attempts+1 "
                    "WHERE id=? AND status='pending'",
                    (now, int(notification_id)),
                )
                return cur.rowcount > 0
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: claim_notification failed: {e}")
            return False

    def revert_claim(self, notification_id: int) -> None:
        """Transition a claimed row ``delivering`` → ``pending`` (give it up).

        F-058: promoted onto the store. Used when a claimed delivery could not be
        sent (Apprise unavailable / rejected) so the next daemon start retries the
        row instead of leaving it stuck ``delivering``.
        """
        if self._conn is None:
            return
        try:
            with self._write() as conn:
                if conn is None:
                    return
                conn.execute(
                    "UPDATE notifications SET status='pending', "
                    "sent_at=NULL, delivering_at=NULL "
                    "WHERE id=? AND status='delivering'",
                    (int(notification_id),),
                )
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: revert_claim failed: {e}")

    def mark_notification_attempt(self, notification_id: int) -> None:
        """Increment a notification's attempt counter (it stays pending
        — the worker will retry on the next loop iteration)."""
        if self._conn is None:
            return
        try:
            with self._write() as conn:
                if conn is None:
                    return
                conn.execute(
                    "UPDATE notifications SET attempts=attempts+1 "
                    "WHERE id=?",
                    (int(notification_id),),
                )
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: mark_notification_attempt failed: {e}"
            )

    def cancel_notification(self, notification_id: int,
                            reason: str) -> None:
        """Mark a notification as cancelled (won't retry, eligible for
        TTL pruning). Reason is one of ``max_attempts``, ``too_old``,
        ``backlog_overflow``, ``coalesced``, ``superseded``."""
        if self._conn is None:
            return
        try:
            with self._write() as conn:
                if conn is None:
                    return
                conn.execute(
                    "UPDATE notifications SET status='cancelled', "
                    "sent_at=NULL, delivering_at=NULL, cancel_reason=? WHERE id=?",
                    (str(reason), int(notification_id)),
                )
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: cancel_notification failed: {e}"
            )

    def pending_notification_count(self) -> int:
        """Return queued or in-flight rows that have not finished delivery.

        The legacy method name predates atomic delivery claims. ``delivering``
        rows must count too: otherwise a shutdown-time ``flush()`` sees zero as
        soon as the worker claims its final row and can exit while Apprise is
        still sending it.
        """
        if self._conn is None:
            return 0
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return 0
                cur = self._conn.execute(
                    "SELECT COUNT(*) FROM notifications "
                    "WHERE status IN ('pending', 'delivering')"
                )
                row = cur.fetchone()
                return int(row[0]) if row else 0
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: pending_notification_count failed: {e}"
            )
            return 0

    def pending_notification_ids(self) -> Optional[List[int]]:
        """Return the ids of all pending rows in this store, or ``None`` if
        the query could not run (store closed / transient SQLite error).

        Used by the notification worker to reconcile its in-memory
        per-message backoff map against the live queue (ISS-036), so
        entries for rows cancelled out-of-band (cap / coalesce / TTL)
        don't leak. The ``None`` return is distinct from an empty list so
        the caller can tell "nothing pending" (safe to prune) apart from
        "couldn't check" (must NOT prune, or a transient error would wipe
        live backoff timers)."""
        if self._conn is None:
            return None
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return None
                cur = self._conn.execute(
                    "SELECT id FROM notifications WHERE status='pending'"
                )
                return [int(r[0]) for r in cur.fetchall()]
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: pending_notification_ids failed: {e}"
            )
            return None

    def cap_pending_notifications(self, max_pending: int) -> int:
        """Enforce the backlog cap. If pending count exceeds
        ``max_pending``, cancel the oldest rows down to the cap with
        ``cancel_reason='backlog_overflow'``. Returns number cancelled.

        Pass 0 / negative to disable (no cap)."""
        if self._conn is None or max_pending <= 0:
            return 0
        try:
            with self._write() as conn:
                if conn is None:
                    return 0
                cur = conn.execute(
                    "SELECT COUNT(*) FROM notifications "
                    "WHERE status='pending'"
                )
                row = cur.fetchone()
                pending = int(row[0]) if row else 0
                excess = pending - int(max_pending)
                if excess <= 0:
                    return 0
                # Cancel the `excess` oldest pending rows.
                conn.execute(
                    "UPDATE notifications SET status='cancelled', "
                    "cancel_reason='backlog_overflow' "
                    "WHERE id IN ("
                    "  SELECT id FROM notifications WHERE status='pending' "
                    "  ORDER BY ts ASC, id ASC LIMIT ?"
                    ")",
                    (int(excess),),
                )
                return excess
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: cap_pending_notifications failed: {e}"
            )
            return 0

    def prune_old_notifications(self, retention_days: int,
                                max_age_days: int = 0) -> Tuple[int, int]:
        """Two-step cleanup:

        1. ``DELETE`` rows in (``sent``, ``cancelled``) older than
           ``retention_days``. The sent log isn't an audit log; that's
           ``events``. Default 7d keeps the recent flush history for
           debugging without unbounded growth.
        2. ``UPDATE`` pending rows older than ``max_age_days`` to
           ``cancelled`` with ``cancel_reason='too_old'``. Skipped when
           ``max_age_days <= 0`` (pending lives forever — the panic-attack
           guarantee). Default 30d means a month-long sabbatical still
           delivers; longer than that is probably stale anyway.

        Returns ``(deleted, expired)`` for logging."""
        if self._conn is None:
            return (0, 0)
        cutoff_sent = int(time.time()) - max(1, int(retention_days)) * 86400
        deleted = 0
        expired = 0
        try:
            with self._write() as conn:
                if conn is None:
                    return (0, 0)
                cur = conn.execute(
                    "DELETE FROM notifications "
                    "WHERE status IN ('sent','cancelled') AND ts < ?",
                    (cutoff_sent,),
                )
                deleted = cur.rowcount or 0
                if max_age_days > 0:
                    cutoff_pending = (
                        int(time.time()) - int(max_age_days) * 86400
                    )
                    cur = conn.execute(
                        "UPDATE notifications SET status='cancelled', "
                        "cancel_reason='too_old' "
                        "WHERE status='pending' AND ts < ?",
                        (cutoff_pending,),
                    )
                    expired = cur.rowcount or 0
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: prune_old_notifications failed: {e}"
            )
        return (deleted, expired)

    # ----- generic meta key/value store -----

    def get_meta(self, key: str) -> Optional[str]:
        """Read a value from the ``meta`` table. Used by Slice 3 to
        track ``last_seen_version`` for the pip-path lifecycle classifier."""
        if self._conn is None:
            return None
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return None
                cur = self._conn.execute(
                    "SELECT value FROM meta WHERE key=?", (str(key),),
                )
                row = cur.fetchone()
                return str(row[0]) if row else None
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: get_meta failed: {e}")
            return None

    def set_meta(self, key: str, value: str) -> bool:
        """Write a value to the ``meta`` table (insert-or-replace).

        Returns ``True`` when the write committed, ``False`` when the store was
        closed or a SQLite/OS error swallowed the write. F-028: the report
        scheduler stamps its ``last_report_sent_<period>`` dedup key BEFORE
        enqueuing the digest and only sends when this returns True, so a silently
        failed stamp can't re-send the same digest every tick.
        """
        if self._conn is None:
            return False
        try:
            with self._write() as conn:
                if conn is None:
                    return False
                conn.execute(
                    "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
                    (str(key), str(value)),
                )
            return True
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: set_meta failed: {e}")
            return False

    def set_meta_many(self, values: Dict[str, str]) -> bool:
        """Commit several ``meta`` values atomically."""
        if self._conn is None:
            return False
        try:
            with self._write() as conn:
                if conn is None:
                    return False
                conn.executemany(
                    "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
                    [(str(key), str(value)) for key, value in values.items()],
                )
            return True
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: set_meta_many failed: {e}")
            return False

    # ----- v7: battery-health, self-test, energy data -----

    def record_battery_health(
        self,
        score: Optional[float],
        terms: Optional[Dict[str, Optional[float]]] = None,
        *,
        detail: Optional[Dict[str, Any]] = None,
        ts: Optional[int] = None,
    ) -> None:
        """Persist one battery-health computation.

        ``score`` is the composite 0-100 (``None`` = unknown). ``terms`` maps
        the five sub-scores (capacity/runtime/self_test/anomaly/age) to a
        0-100 value or ``None`` when that term is unavailable -- the NULL is
        what keeps "unknown" distinct from "0" in the stored trend. ``detail``
        is any extra JSON-serialisable context (weights, confidence, inputs).
        """
        if self._conn is None:
            return
        terms = terms or {}
        row_ts = int(ts if ts is not None else time.time())
        payload: Optional[str]
        try:
            payload = json.dumps(detail, sort_keys=True) if detail else None
        except (TypeError, ValueError):
            payload = None
        try:
            # F-055: route through the shared _write() context manager instead of
            # hand-rolling `with _db_lock: ... with _conn:` (which re-checks the
            # connection under the lock for us). Behaviour is identical.
            with self._write() as conn:
                if conn is None:
                    return
                conn.execute(
                    """
                    INSERT OR REPLACE INTO battery_health
                        (ts, score, capacity, runtime, self_test, anomaly, age, detail)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row_ts, score,
                        terms.get("capacity"), terms.get("runtime"),
                        terms.get("self_test"), terms.get("anomaly"),
                        terms.get("age"), payload,
                    ),
                )
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: record_battery_health failed: {e}")

    def query_battery_health(
        self, start_ts: int, end_ts: int,
    ) -> List[Dict[str, Any]]:
        """Return battery-health rows in ``[start_ts, end_ts]`` ascending.

        Each row is a dict with ts, score, the five term columns, and the
        decoded ``detail``. Feeds replacement-prediction trending over the
        ``score`` series.
        """
        if self._conn is None:
            return []
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return []
                cur = self._conn.execute(
                    """
                    SELECT ts, score, capacity, runtime, self_test, anomaly, age, detail
                    FROM battery_health
                    WHERE ts BETWEEN ? AND ?
                    ORDER BY ts ASC
                    """,
                    (int(start_ts), int(end_ts)),
                )
                rows = cur.fetchall()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: query_battery_health failed: {e}")
            return []
        out: List[Dict[str, Any]] = []
        for r in rows:
            detail = None
            if r[7]:
                try:
                    detail = json.loads(r[7])
                except (TypeError, ValueError):
                    detail = None
            out.append({
                "ts": int(r[0]), "score": r[1],
                "capacity": r[2], "runtime": r[3], "self_test": r[4],
                "anomaly": r[5], "age": r[6], "detail": detail,
            })
        return out

    def latest_battery_health(self) -> Optional[Dict[str, Any]]:
        """Return the newest stored battery-health row."""
        if self._conn is None:
            return None
        try:
            with self._db_lock:
                if self._conn is None:
                    return None
                row = self._conn.execute(
                    """
                    SELECT ts, score, capacity, runtime, self_test, anomaly,
                           age, detail
                    FROM battery_health ORDER BY ts DESC LIMIT 1
                    """
                ).fetchone()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: latest_battery_health failed: {e}")
            return None
        if row is None:
            return None
        detail = None
        if row[7]:
            try:
                detail = json.loads(row[7])
            except (TypeError, ValueError):
                pass
        return {
            "ts": int(row[0]), "score": row[1], "capacity": row[2],
            "runtime": row[3], "self_test": row[4], "anomaly": row[5],
            "age": row[6], "detail": detail,
        }

    def record_self_test(
        self,
        command: str,
        source: str,
        *,
        started_ts: Optional[int] = None,
        result_raw: Optional[str] = None,
        result_enum: str = "running",
        result_date: Optional[str] = None,
    ) -> Optional[int]:
        """Insert a self-test row and return its id (``None`` on failure).

        An issued test starts as ``running``; poll upsd later and finalise it
        with :meth:`update_self_test_result`.
        """
        if self._conn is None:
            return None
        row_ts = int(started_ts if started_ts is not None else time.time())
        try:
            # F-055: use the shared _write() context manager (identical behaviour
            # to the previous hand-rolled lock + connection re-check).
            with self._write() as conn:
                if conn is None:
                    return None
                cur = conn.execute(
                    """
                    INSERT INTO self_tests
                        (started_ts, command, result_raw, result_enum,
                         result_date, source)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (row_ts, str(command), result_raw, result_enum,
                     result_date, str(source)),
                )
                return int(cur.lastrowid)
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: record_self_test failed: {e}")
            return None

    def update_self_test_result(
        self,
        test_id: int,
        *,
        result_raw: Optional[str],
        result_enum: str,
        result_date: Optional[str] = None,
    ) -> None:
        """Finalise a self-test row once upsd reports a result."""
        if self._conn is None:
            return
        try:
            # F-055: shared _write() context manager (identical behaviour to the
            # previous hand-rolled lock + connection re-check).
            with self._write() as conn:
                if conn is None:
                    return
                conn.execute(
                    """
                    UPDATE self_tests
                    SET result_raw = ?, result_enum = ?, result_date = ?
                    WHERE id = ?
                    """,
                    (result_raw, result_enum, result_date, int(test_id)),
                )
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: update_self_test_result failed: {e}")

    def latest_self_test(self) -> Optional[Dict[str, Any]]:
        """Return the most-recently-started self-test row, or ``None``."""
        if self._conn is None:
            return None
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return None
                cur = self._conn.execute(
                    """
                    SELECT id, started_ts, command, result_raw, result_enum,
                           result_date, source
                    FROM self_tests
                    ORDER BY started_ts DESC, id DESC
                    LIMIT 1
                    """
                )
                r = cur.fetchone()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: latest_self_test failed: {e}")
            return None
        if r is None:
            return None
        return {
            "id": int(r[0]), "started_ts": int(r[1]), "command": r[2],
            "result_raw": r[3], "result_enum": r[4], "result_date": r[5],
            "source": r[6],
        }

    def get_self_test(self, test_id: int) -> Optional[Dict[str, Any]]:
        """Return one self-test row by id, or ``None`` when absent."""
        if self._conn is None:
            return None
        try:
            with self._db_lock:
                if self._conn is None:
                    return None
                r = self._conn.execute(
                    """
                    SELECT id, started_ts, command, result_raw, result_enum,
                           result_date, source
                    FROM self_tests WHERE id = ?
                    """,
                    (int(test_id),),
                ).fetchone()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: get_self_test failed: {e}")
            return None
        if r is None:
            return None
        return {
            "id": int(r[0]), "started_ts": int(r[1]), "command": r[2],
            "result_raw": r[3], "result_enum": r[4], "result_date": r[5],
            "source": r[6],
        }

    def query_self_tests(self, start_ts: int, end_ts: int) -> List[Dict[str, Any]]:
        """Return self-tests started inside an inclusive time window."""
        if self._conn is None:
            return []
        try:
            with self._db_lock:
                if self._conn is None:
                    return []
                rows = self._conn.execute(
                    """
                    SELECT id, started_ts, command, result_raw, result_enum,
                           result_date, source
                    FROM self_tests
                    WHERE started_ts BETWEEN ? AND ?
                    ORDER BY started_ts, id
                    """,
                    (int(start_ts), int(end_ts)),
                ).fetchall()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: query_self_tests failed: {e}")
            return []
        return [{
            "id": int(r[0]), "started_ts": int(r[1]), "command": r[2],
            "result_raw": r[3], "result_enum": r[4], "result_date": r[5],
            "source": r[6],
        } for r in rows]

    def latest_power_event_before(self, ts: int) -> Optional[Tuple[int, str, str]]:
        """Return the last ordinary outage transition before ``ts``."""
        if self._conn is None:
            return None
        try:
            with self._db_lock:
                if self._conn is None:
                    return None
                row = self._conn.execute(
                    """
                    SELECT ts, event_type, detail FROM events
                    WHERE ts < ?
                      AND event_type IN ('ON_BATTERY', 'POWER_RESTORED')
                    ORDER BY ts DESC, id DESC LIMIT 1
                    """,
                    (int(ts),),
                ).fetchone()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: latest_power_event_before failed: {e}")
            return None
        if row is None:
            return None
        return int(row[0]), str(row[1]), str(row[2] or "")

    def latest_running_self_test(self) -> Optional[Dict[str, Any]]:
        """Return the most-recent running self-test row, or ``None``."""
        if self._conn is None:
            return None
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return None
                cur = self._conn.execute(
                    """
                    SELECT id, started_ts, command, result_raw, result_enum,
                           result_date, source
                    FROM self_tests
                    WHERE result_enum = 'running'
                    ORDER BY started_ts DESC, id DESC
                    LIMIT 1
                    """
                )
                r = cur.fetchone()
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: latest_running_self_test failed: {e}")
            return None
        if r is None:
            return None
        return {
            "id": int(r[0]), "started_ts": int(r[1]), "command": r[2],
            "result_raw": r[3], "result_enum": r[4], "result_date": r[5],
            "source": r[6],
        }

    def repair_self_test_power_events(self) -> Optional[int]:
        """Relabel high-confidence historical self-test OB/OL event pairs.

        Only short, closed outages with exactly one self-test timestamp within
        30 seconds of the pair are changed. Ambiguous or long outages remain
        ordinary power events.
        """
        if self._conn is None:
            return None
        try:
            with self._write() as conn:
                if conn is None:
                    return None
                events = conn.execute(
                    """
                    SELECT id, ts, event_type FROM events
                    WHERE event_type IN ('ON_BATTERY', 'POWER_RESTORED')
                    ORDER BY ts, id
                    """
                ).fetchall()
                tests = conn.execute(
                    "SELECT started_ts FROM self_tests "
                    "WHERE source != 'device' AND command != '' "
                    "AND result_enum != 'aborted' "
                    "ORDER BY started_ts"
                ).fetchall()
                test_times = [int(row[0]) for row in tests]
                changed = 0
                pending = None
                for event_id, ts, event_type in events:
                    ts = int(ts)
                    if event_type == "ON_BATTERY":
                        pending = (int(event_id), ts)
                        continue
                    if pending is None:
                        continue
                    ob_id, ob_ts = pending
                    pending = None
                    if ts - ob_ts > 120:
                        continue
                    candidates = [test_ts for test_ts in test_times
                                  if ob_ts - 30 <= test_ts <= ts + 30]
                    if len(candidates) != 1:
                        continue
                    conn.execute(
                        "UPDATE events SET event_type = 'SELF_TEST_ON_BATTERY' "
                        "WHERE id = ?", (ob_id,))
                    conn.execute(
                        "UPDATE events SET event_type = 'SELF_TEST_POWER_RESTORED' "
                        "WHERE id = ?", (int(event_id),))
                    changed += 1
                return changed
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(
                f"stats: repair_self_test_power_events failed: {e}")
            return None

    def power_samples(
        self,
        start_ts: int,
        end_ts: int,
        *,
        prefer_tier: Optional[str] = None,
    ) -> List[Tuple[int, Optional[float], Optional[float], Optional[float],
                    Optional[float]]]:
        """Return power rows for energy integration.

        Rows are ``(ts, real_power, ups_load, real_power_nominal,
        power_nominal)``. Picks the same retention tier as :meth:`query_range`
        so an energy integral never mixes raw and aggregated rows.
        Unlike query_range this keeps NULL cells (returned as ``None``) so the
        integrator can mark gaps rather than silently dropping them.
        """
        if self._conn is None:
            return []
        tier = prefer_tier or self._pick_tier(start_ts, end_ts)
        if tier == "samples":
            cols = (
                "ts, real_power, ups_load, real_power_nominal, power_nominal"
            )
            table = "samples"
        else:
            cols = (
                "ts, real_power_avg, ups_load_avg, "
                "real_power_nominal_avg, power_nominal_avg"
            )
            table = "agg_5min" if tier == "agg_5min" else "agg_hourly"
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return []
                cur = self._conn.execute(
                    f"SELECT {cols} FROM {table} "
                    "WHERE ts BETWEEN ? AND ? ORDER BY ts ASC",
                    (int(start_ts), int(end_ts)),
                )
                return [
                    (
                        int(r[0]),
                        float(r[1]) if r[1] is not None else None,
                        float(r[2]) if r[2] is not None else None,
                        float(r[3]) if r[3] is not None else None,
                        float(r[4]) if r[4] is not None else None,
                    )
                    for r in cur.fetchall()
                ]
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: power_samples failed: {e}")
            return []

    # ----- metric query API -----

    def query_range(
        self,
        metric: str,
        start_ts: int,
        end_ts: int,
        *,
        prefer_tier: Optional[str] = None,
    ) -> List[Tuple[int, float]]:
        """Return ``[(ts, value)]`` for a metric across a time window.

        Picks the smallest-resolution tier that still fits the window:
        samples (24 h), agg_5min (30 d), agg_hourly (5 y). Override with
        ``prefer_tier``.

        ``metric`` is one of: ``battery_charge``, ``battery_runtime``,
        ``ups_load``, ``input_voltage``, ``output_voltage``,
        ``depletion_rate``.
        """
        if self._conn is None:
            return []

        # L11: reject any metric not on the internal allowlist before it reaches
        # the interpolated column position.
        if metric not in _QUERYABLE_METRICS:
            return []

        tier = prefer_tier or self._pick_tier(start_ts, end_ts)
        try:
            with self._db_lock:
                if self._conn is None:   # re-check: close() may have raced
                    return []
                if tier == "samples":
                    column = metric
                    cur = self._conn.execute(
                        f"SELECT ts, {column} FROM samples "
                        f"WHERE ts BETWEEN ? AND ? AND {column} IS NOT NULL "
                        "ORDER BY ts ASC",
                        (int(start_ts), int(end_ts)),
                    )
                else:
                    table = "agg_5min" if tier == "agg_5min" else "agg_hourly"
                    column = self._agg_column_for(metric)
                    cur = self._conn.execute(
                        f"SELECT ts, {column} FROM {table} "
                        f"WHERE ts BETWEEN ? AND ? AND {column} IS NOT NULL "
                        "ORDER BY ts ASC",
                        (int(start_ts), int(end_ts)),
                    )
                # Rows written before non-finite readings were dropped at
                # ingest can still hold inf; never hand those to /history.
                return [(int(r[0]), float(r[1])) for r in cur.fetchall()
                        if math.isfinite(float(r[1]))]
        except (sqlite3.Error, OSError) as e:
            self._log_error_once(f"stats: query_range failed: {e}")
            return []

    @staticmethod
    def _pick_tier(start_ts: int, end_ts: int) -> str:
        span = max(1, end_ts - start_ts)
        if span <= 24 * 3600:
            return "samples"
        if span <= 30 * 86400:
            return "agg_5min"
        return "agg_hourly"

    @staticmethod
    def _agg_column_for(metric: str) -> str:
        """Map a raw-metric name to its ``*_avg`` column on the agg tables.

        ``depletion_rate``, ``time_on_battery`` and ``connection_state``
        are not aggregated (state-shaped, not signal-shaped) and fall
        through to a column that doesn't exist on agg tables -- callers
        receive an empty result, which is the right behavior.
        """
        avg_map = {
            "battery_charge": "battery_charge_avg",
            "battery_runtime": "battery_runtime_avg",
            "ups_load": "ups_load_avg",
            "input_voltage": "input_voltage_avg",
            "output_voltage": "output_voltage_avg",
            "battery_voltage": "battery_voltage_avg",
            "ups_temperature": "ups_temperature_avg",
            "input_frequency": "input_frequency_avg",
            "output_frequency": "output_frequency_avg",
            "real_power": "real_power_avg",
            "power_nominal": "power_nominal_avg",
            "real_power_nominal": "real_power_nominal_avg",
        }
        return avg_map.get(metric, metric)

    # ----- read-only API for the TUI -----

    @classmethod
    def open_readonly(cls, db_path: Path) -> Optional[sqlite3.Connection]:
        """Open a read-only ``sqlite3.Connection`` (URI mode=ro).

        Returns ``None`` if the file doesn't exist; otherwise the
        connection is the caller's responsibility to close. Designed for
        the TUI to query metrics without contending for the writer.
        """
        path = Path(db_path)
        if not path.exists():
            return None
        # urlquote so a path containing '?' or '#' (legal on POSIX
        # filesystems, illegal in a SQLite URI without escaping) doesn't
        # truncate the path or get parsed as the URI's query / fragment.
        uri = f"file:{urlquote(str(path))}?mode=ro"
        conn = None
        try:
            conn = sqlite3.connect(uri, uri=True, check_same_thread=False)
            # Same bound as the writer connection: a slow query against the
            # writer's WAL can't stall the TUI refresh for more than 500 ms.
            conn.execute("PRAGMA busy_timeout = 500")
            # sqlite3.connect() can return a handle for a corrupt file; force a
            # schema read now so callers receive None instead of a later
            # DatabaseError from their first real query.
            conn.execute("SELECT name FROM sqlite_master LIMIT 1").fetchone()
            return conn
        except (sqlite3.Error, OSError):
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
            return None

    @classmethod
    def from_connection(cls, conn: sqlite3.Connection) -> "StatsStore":
        """Wrap an existing SQLite connection without taking ownership."""
        store = cls(Path(":memory:"))
        # N5: __init__ does NOT open a connection (self._conn stays None until
        # open()), so there is no throw-away handle to close here -- the previous
        # store._conn.close() always raised AttributeError into a swallowed
        # except. Just rebind to the caller-owned connection.
        store._conn = conn
        return store

    # ----- error rate-limiting -----

    def _log_error_once(self, message: str) -> None:
        now = time.time()
        last = self._last_error_log.get(message, 0.0)
        if now - last < self._error_log_interval:
            return
        self._last_error_log[message] = now
        if self._logger is not None:
            try:
                self._logger.log(message)
            except Exception:  # pragma: no cover
                pass


class StatsWriter(threading.Thread):
    """Background thread: flushes buffer every 10 s, aggregates+purges every 5 min.

    All work is wrapped in a try/except that logs once per error message
    -- a misbehaving SQLite never raises into the daemon's main loop.
    """

    def __init__(
        self,
        store: StatsStore,
        stop_event: threading.Event,
        *,
        flush_interval: float = 10.0,
        maintenance_interval: float = 300.0,
        log_prefix: str = "",
    ):
        super().__init__(name="stats-writer", daemon=True)
        self._store = store
        self._stop_event = stop_event
        self._flush_interval = flush_interval
        self._maintenance_interval = maintenance_interval
        self._log_prefix = log_prefix
        self._last_maintenance = time.monotonic()

    def run(self) -> None:  # pragma: no cover -- exercised by integration test
        try:
            while not self._stop_event.is_set():
                try:
                    self._store.flush()
                    if (time.monotonic() - self._last_maintenance
                            >= self._maintenance_interval):
                        self._store.aggregate()
                        self._store.purge()
                        self._last_maintenance = time.monotonic()
                except Exception:
                    # Defensive: every error path inside the store already
                    # logs once and swallows; this is a final guard.
                    pass
                self._stop_event.wait(self._flush_interval)
        finally:
            try:
                self._store.flush()
            except Exception:
                pass
