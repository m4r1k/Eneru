"use strict";
// Eneru dashboard — a thin client over the REST API. No third-party code; all
// logic stays server-side. The auth token (session or API key) lives in
// sessionStorage and is sent as a Bearer header, so there is no cookie and thus
// no CSRF surface.
//
// v6.1: the UI is a tabbed SPA (Overview / Power / Battery / Energy / Events /
// Control / Config). Tabs are real ARIA tabs (arrow-key nav + hash routing).
// Charts are a reusable vanilla-SVG factory (makeChart) with optional voltage
// threshold bands and power-event overlays. Zero build toolchain.

const TOKEN_KEY = "eneru_token";
const THEME_KEY = "eneru_theme";
const SVG_NS = "http://www.w3.org/2000/svg";
let lastEvents = [];
let knownEventSources = [];
// Whether the server has API auth enabled. Learned from /api/v1/config at start;
// when false there is nothing to sign into, so the Sign-in button stays hidden.
let authEnabled = false;
// Snapshots fetched once per refresh and shared by the drill-down, so opening a
// detail panel never triggers per-card config/remote-health requests.
let cfgSnapshot = null;
let remoteHealthSnapshot = [];
let lastUpsRows = [];
let lastGroups = [];
let eventSortDirection = "desc";   // L2: newest first by default

// Pure refresh helpers kept separate from DOM work so the state transitions can
// be exercised in the no-browser Node harness.
function nutStatusTokens(status) {
  return new Set(String(status || "").toUpperCase().trim().split(/\s+/).filter(Boolean));
}

const NUT_STATUS_LABELS = {
  FSD: "Shutdown in progress",
  OFF: "UPS output off",
  WAIT: "Waiting for UPS data",
  OB: "Running on battery",
  OL: "Utility power",
  LB: "Battery low",
  HB: "Battery charge sufficient",
  RB: "Battery replacement needed",
  BYPASS: "Bypass active",
  OVER: "UPS overloaded",
  ALARM: "UPS alarm active",
  CAL: "Battery calibration in progress",
  CHRG: "Battery charging",
  DISCHRG: "Battery discharging",
  BOOST: "Voltage boost active",
  TRIM: "Voltage trim active",
};

// Lead with hazards, choose one primary electrical state, then retain routine
// modifiers. Unknown vendor tokens stay visible instead of disappearing.
function humanNutStatus(status) {
  const tokens = nutStatusTokens(status);
  if (tokens.size === 0) return "Status unknown";

  const parts = [];
  const primary = ["FSD", "OFF", "OB", "WAIT", "OL"].find((token) => tokens.has(token));
  if (["FSD", "OFF"].includes(primary)) parts.push(NUT_STATUS_LABELS[primary]);
  ["ALARM", "OVER", "LB", "RB", "BYPASS"]
    .filter((token) => tokens.has(token))
    .forEach((token) => parts.push(NUT_STATUS_LABELS[token]));
  if (primary && !["FSD", "OFF"].includes(primary)) parts.push(NUT_STATUS_LABELS[primary]);
  ["DISCHRG", "CAL", "CHRG", "BOOST", "TRIM", "HB"]
    .filter((token) => tokens.has(token))
    .forEach((token) => parts.push(NUT_STATUS_LABELS[token]));

  const unknown = Array.from(tokens).filter(
    (token) => !Object.prototype.hasOwnProperty.call(NUT_STATUS_LABELS, token));
  if (unknown.length) {
    parts.push((unknown.length === 1 ? "Custom state: " : "Custom states: ")
      + unknown.join(", "));
  }
  return parts.join(" · ");
}

const EVENT_TYPE_LABELS = {
  ON_BATTERY: "Power failure",
  POWER_RESTORED: "Power restored",
  SELF_TEST_ON_BATTERY: "Self-test running on battery",
  SELF_TEST_POWER_RESTORED: "Self-test power restored",
  BROWNOUT_DETECTED: "Low input voltage",
  OVER_VOLTAGE_DETECTED: "High input voltage",
  VOLTAGE_NORMALIZED: "Input voltage normal",
  AVR_BOOST_ACTIVE: "Voltage boost started",
  AVR_TRIM_ACTIVE: "Voltage trim started",
  AVR_INACTIVE: "Automatic voltage regulation inactive",
  BYPASS_MODE_ACTIVE: "UPS entered bypass mode",
  BYPASS_MODE_INACTIVE: "UPS left bypass mode",
  OVERLOAD_ACTIVE: "UPS overload detected",
  OVERLOAD_RESOLVED: "UPS overload resolved",
  CONNECTION_LOST: "UPS connection lost",
  CONNECTION_RESTORED: "UPS connection restored",
  BATTERY_LOW: "Low battery detected",
};

function humanEventType(type) {
  const raw = String(type || "").trim();
  if (!raw) return "Event";
  const statusTokens = nutStatusTokens(raw);
  if (Array.from(statusTokens).some(
    (token) => Object.prototype.hasOwnProperty.call(NUT_STATUS_LABELS, token))) {
    return humanNutStatus(raw);
  }
  if (EVENT_TYPE_LABELS[raw.toUpperCase()]) return EVENT_TYPE_LABELS[raw.toUpperCase()];
  return raw.toLowerCase().split(/[_\s-]+/).filter(Boolean).map((word, index) => {
    const upper = word.toUpperCase();
    if (["UPS", "API", "AVR"].includes(upper)) return upper;
    return index === 0 ? word.charAt(0).toUpperCase() + word.slice(1) : word;
  }).join(" ");
}

function humanEventDetail(detail) {
  return String(detail || "").replace(
    /(\bStatus:\s*)([^)]+)(?=\))/gi,
    (_match, prefix, status) => prefix + humanNutStatus(status),
  );
}

function powerStateSignature(rows) {
  return (Array.isArray(rows) ? rows : []).map((row) => {
    const tokens = nutStatusTokens(row && row.status);
    const state = ["OL", "OB", "LB", "FSD"].filter((t) => tokens.has(t)).join("+");
    return String((row && row.name) || "") + "=" + state;
  }).sort().join("|");
}

function authStateRequiresClear(authState, cfg, hasToken) {
  if (!hasToken) return false;
  const explicitlyDisabled = !!(authState && authState.ok && authState.data
    && authState.data.enabled === false);
  const treatedAsAnonymous = !!(cfg && cfg.ok && cfg.data
    && cfg.data.detail === "sanitized");
  return explicitlyDisabled || treatedAsAnonymous;
}

function responseInvalidatesAuth(status, path) {
  return status === 401 && path !== "/api/v1/auth/login";
}

// ----- theme (light / dark / system) -----

function applyTheme(value) {
  const v = (value === "light" || value === "dark") ? value : "system";
  // "system" -> no attribute, so the pure-CSS @media(prefers-color-scheme) rules
  // apply (flash-free default). An explicit choice pins data-theme.
  if (v === "system") delete document.documentElement.dataset.theme;
  else document.documentElement.dataset.theme = v;
  try { localStorage.setItem(THEME_KEY, v); } catch (_e) { /* private mode */ }
}

function initTheme() {
  let saved = "system";
  try { saved = localStorage.getItem(THEME_KEY) || "system"; } catch (_e) { /* */ }
  applyTheme(saved);
  const sel = document.getElementById("theme-select");
  if (sel) {
    sel.value = saved;
    sel.addEventListener("change", () => applyTheme(sel.value));
  }
}

function token() { return sessionStorage.getItem(TOKEN_KEY) || ""; }
function setToken(t) {
  if (t) sessionStorage.setItem(TOKEN_KEY, t);
  else sessionStorage.removeItem(TOKEN_KEY);
}

async function api(path, opts) {
  opts = opts || {};
  const headers = opts.headers || {};
  if (token()) headers["Authorization"] = "Bearer " + token();
  if (opts.body) headers["Content-Type"] = "application/json";
  let res;
  try {
    res = await fetch(path, { method: opts.method || "GET", headers, body: opts.body });
  } catch (_e) {
    // L14: a network error (daemon down, or connectivity lost during a power
    // event -- exactly when the dashboard matters) rejects the fetch. Return a
    // non-ok result with status 0 so callers show a "connection lost" indicator
    // instead of an unhandled rejection that silently freezes the poll loop.
    return { ok: false, status: 0, data: null };
  }
  if (responseInvalidatesAuth(res.status, path)) clearAuthState();
  let data = null;
  try { data = await res.json(); } catch (_e) { /* non-JSON (static) */ }
  return { ok: res.ok, status: res.status, data };
}

function el(tag, attrs, children) {
  const node = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    if (k === "class") node.className = attrs[k];
    else if (k === "text") node.textContent = attrs[k];
    else node.setAttribute(k, attrs[k]);
  }
  (children || []).forEach((c) => node.appendChild(c));
  return node;
}

// ----- inline SVG icons -----------------------------------------------------
// A tiny stroke-icon set drawn with currentColor, so icons inherit text/status
// color and theme automatically — no color-emoji font dependency (the host has
// none, which is why the old emoji rendered as tofu). Each value is one path `d`
// (multiple M-segments allowed).
const ICONS = {
  home:    "M3 11.5 12 4l9 7.5 M5.5 10.5V20h13v-9.5",
  bolt:    "M13 3 6 13h5l-1 8 8-11h-5z",
  battery: "M3 8.5h13v7H3z M18.5 11v3 M5.5 10.5v3",
  chart:   "M4 5v14h16 M8 14l3-3 2.4 2L19 8",
  bell:    "M6 9a6 6 0 0 1 12 0c0 5 2.2 7 2.2 7H3.8S6 14 6 9 M10 21h4",
  sliders: "M5 8h14 M5 16h14 M9 6v4 M15 14v4",
  gear:    "M19.43 12.98c.04-.32.07-.64.07-.98 0-.34-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98 0 .33.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z",
  shield:  "M12 3 19 6v5c0 4.5-3 7.6-7 8.6-4-1-7-4.1-7-8.6V6z",
  gauge:   "M4.5 16.5a8 8 0 1 1 15 0 M12 13l3-3",
  check:   "M5 12.5 9.5 17 19 7",
  alert:   "M12 4 21 19H3z M12 10v4 M12 16.6v.4",
  info:    "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18 M12 11v5 M12 7.6v.4",
  close:   "M6 6l12 12 M18 6 6 18",
  power:   "M12 3v9 M7.8 6.4a7 7 0 1 0 8.4 0",
  vm:      "M3 5h18v11H3z M8 20h8 M11 16v4",
  box:     "M12 3 21 7.5v9L12 21 3 16.5v-9z M3 7.5 12 12l9-4.5 M12 12v9",
  disk:    "M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3z M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6 M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3",
  globe:   "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M3 12h18 M12 3c2.6 2.7 2.6 15.3 0 18 M12 3c-2.6 2.7-2.6 15.3 0 18",
};
const SD_PHASE_ICONS = { vms: "vm", containers: "box", "filesystem-sync": "disk",
  "filesystem-unmount": "disk", remote: "globe", "final-sync": "disk",
  "local-poweroff": "power" };
function icon(name, cls) {
  const s = document.createElementNS(SVG_NS, "svg");
  s.setAttribute("viewBox", "0 0 24 24");
  s.setAttribute("class", "ic" + (cls ? " " + cls : ""));
  s.setAttribute("aria-hidden", "true");
  const p = document.createElementNS(SVG_NS, "path");
  p.setAttribute("d", ICONS[name] || "");
  s.appendChild(p);
  return s;
}
const TAB_ICONS = { overview: "home", power: "bolt", battery: "battery",
  energy: "chart", events: "bell", control: "sliders", shutdown: "power",
  config: "gear" };

// ----- floating tooltip + help hints ---------------------------------------
// One reused element. Native SVG <title> / title="" only surface after a ~1s
// browser delay and render as a plain OS tooltip; this appears immediately and
// is themed. Shared by chart event markers and the "?" help hints.
let _tip = null;
function tipEl() {
  if (!_tip) {
    _tip = el("div", { class: "tip" });
    _tip.hidden = true;
    document.body.appendChild(_tip);
  }
  return _tip;
}
function moveTip(x, y) {
  const t = tipEl();
  const r = t.getBoundingClientRect();
  let left = x + 14, top = y + 16;
  if (left + r.width > window.innerWidth - 8) left = x - r.width - 14;
  if (top + r.height > window.innerHeight - 8) top = y - r.height - 16;
  t.style.left = Math.max(8, left) + "px";
  t.style.top = Math.max(8, top) + "px";
}
function showTip(content, x, y, accent) {
  const t = tipEl();
  t.className = "tip" + (accent ? " " + accent : "");
  if (typeof content === "string") t.replaceChildren(document.createTextNode(content));
  else t.replaceChildren(...(Array.isArray(content) ? content : [content]));
  t.hidden = false;
  moveTip(x, y);
}
function hideTip() { if (_tip) _tip.hidden = true; }

// Wire instant hover/focus tooltips onto `node`. `build` returns string|DOM|DOM[];
// `accent` (optional) is a CSS class that colors the tip's accent border.
function bindTip(node, build, accent) {
  node.addEventListener("mouseenter", (ev) => showTip(build(), ev.clientX, ev.clientY, accent));
  node.addEventListener("mousemove", (ev) => moveTip(ev.clientX, ev.clientY));
  node.addEventListener("mouseleave", hideTip);
  node.addEventListener("focus", () => {
    const r = node.getBoundingClientRect();
    showTip(build(), r.left, r.bottom, accent);
  });
  node.addEventListener("blur", hideTip);
}

// A small focusable "?" that reveals `text` on hover/focus (replaces verbose
// inline footnotes; keyboard-accessible).
function helpHint(text) {
  const h = el("span", { class: "help", tabindex: "0", role: "button",
    "aria-label": text, text: "?" });
  bindTip(h, () => text);
  return h;
}

// Title-case a NUT state token ("INACTIVE" -> "Inactive") for display.
function titleCase(s) {
  s = String(s == null ? "" : s).toLowerCase();
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : "—";
}

// "x ago" for remote-health epoch-second timestamps.
function relTime(epoch) {
  if (!epoch) return "never";
  const s = Math.max(0, Math.floor(Date.now() / 1000 - epoch));
  if (s < 60) return s + "s ago";
  if (s < 3600) return Math.floor(s / 60) + "m ago";
  if (s < 86400) return Math.floor(s / 3600) + "h ago";
  return Math.floor(s / 86400) + "d ago";
}

// `spoken` is the stable headline screen readers hear (defaults to msg). The
// live region is written only when that headline changes, so a message whose
// visible age ticks every poll is not re-announced every 10 seconds.
function showError(msg, spoken) {
  const box = document.getElementById("error");
  const live = document.getElementById("error-status");
  const say = msg ? (spoken || msg) : "";
  if (live && live.textContent !== say) live.textContent = say;
  if (!msg) { box.hidden = true; return; }
  box.textContent = msg; box.hidden = false;
}

function numOrNull(v) {
  if (v === undefined || v === null || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

// Format a numeric telemetry value with its unit, or null when it's
// missing/empty. An empty string ("") from a monitoring-only UPS passes a bare
// `!= null` check, so callers that concatenated a unit first rendered a stray
// " V"/" Hz"/" °C" with no number. Routing unit'd fields through here makes a
// blank read as "—" (null → detailRow/configKv/hintedRow render the dash).
function fmtUnit(v, unit) {
  return numOrNull(v) != null ? v + " " + unit : null;
}

function formatFleetMetric(v, unit) {
  const number = numOrNull(v);
  return number == null ? "—" : number + unit;
}

// v6.2 shared status vocabulary (M1). One short label and one 3-level
// severity per state, identical to eneru.utils.status_summary so the dashboard,
// the TUI and notifications say the same thing. The daemon sends the result as
// `statusSummary`; localStatusSummary() is the same table in JS, used only when
// talking to an older daemon that doesn't send it.
// ELI5: a traffic light with exactly three colors. Amber means "on battery,
// fine for now"; red means "the host is going down (or about to)". Only the two
// "going down" states blink, so a blinking badge always means act now.
const STATUS_STATES = {
  shutting_down: ["Shutting down", "crit", true],
  trigger_active: ["Shutdown triggered", "crit", true],
  connection_lost: ["Connection lost", "warn", false],
  stale: ["Stale data", "warn", false],
  output_off: ["UPS output off", "crit", false],
  low_battery: ["Low battery", "crit", false],
  on_battery: ["On battery", "warn", false],
  bypass: ["On bypass", "warn", false],
  online: ["On mains", "ok", false],
  waiting: ["Waiting for data", "warn", false],
  unknown: ["Status unknown", "warn", false],
};
const SEVERITY_RANK = { ok: 0, warn: 1, crit: 2 };

function localStatusSummary(status, opts) {
  opts = opts || {};
  const tokens = nutStatusTokens(status);
  const conn = String(opts.connectionState || "OK").toUpperCase();
  let state;
  if (opts.shuttingDown || tokens.has("FSD")) state = "shutting_down";
  else if (opts.triggerActive) state = "trigger_active";
  else if (conn === "FAILED") state = "connection_lost";
  else if (opts.stale) state = "stale";
  else if (tokens.has("OFF")) state = "output_off";
  else if (tokens.has("LB")) state = "low_battery";
  else if (tokens.has("OB")) state = "on_battery";
  else if (tokens.has("BYPASS")) state = "bypass";
  else if (tokens.has("OL")) state = "online";
  else if (tokens.size === 0 || tokens.has("WAIT")) state = "waiting";
  else state = "unknown";
  const def = STATUS_STATES[state];
  let severity = def[1];
  // Losing NUT while on battery is the failsafe path, not a hiccup.
  if (state === "connection_lost" && tokens.has("OB")) severity = "crit";
  if (state === "online" && ["ALARM", "OVER", "RB"].some((t) => tokens.has(t))) {
    severity = "warn";
  }
  return { state, label: def[0], severity, blink: def[2],
    detail: humanNutStatus(status), tokens: Array.from(tokens) };
}

// The status summary for one /api/v1/ups row: the daemon's own when present,
// otherwise the local twin of it.
function statusInfo(u) {
  const s = u && u.statusSummary;
  if (s && typeof s.label === "string" && s.label) {
    const severity = SEVERITY_RANK[s.severity] !== undefined ? s.severity : "warn";
    return { state: s.state || "unknown", label: s.label, severity,
      blink: !!s.blink, detail: s.detail || humanNutStatus(u.status),
      tokens: s.tokens || [] };
  }
  const fresh = u && u.freshness;
  return localStatusSummary(u && u.status, {
    triggerActive: !!(u && u.triggerActive),
    connectionState: u && u.connectionState,
    stale: !!(fresh && fresh.stale && fresh.lastPollAt != null),
  });
}

// Legacy helper kept for callers that only have a raw NUT status string.
function statusClass(status) {
  return localStatusSummary(status).severity;
}

function worstSeverity(list) {
  return (list || []).reduce((worst, s) =>
    ((SEVERITY_RANK[s] || 0) > (SEVERITY_RANK[worst] || 0) ? s : worst), "ok");
}

// ----- rendering -----

// A UPS counts as electrically available for a redundancy rollup only when it
// is reachable, has a known powered state, and has no unsafe status flags.
function upsHealthy(u) {
  const state = (u.connectionState || "").toUpperCase();
  if (state && state !== "OK" && state !== "CONNECTED") return false;
  const tokens = nutStatusTokens(u.status);
  if (["OB", "LB", "RB", "FSD", "OFF", "OVER", "ALARM", "WAIT"]
    .some((t) => tokens.has(t))) return false;
  return ["OL", "BOOST", "TRIM", "BYPASS", "CHRG", "HB", "CAL"]
    .some((t) => tokens.has(t));
}

function groupHealthyCount(g, rows) {
  if (typeof g.healthyCount === "number") return g.healthyCount;
  const byName = {};
  rows.forEach((u) => { byName[u.name] = u; });
  return (g.upsSources || []).filter((n) => byName[n] && upsHealthy(byName[n])).length;
}

function groupQuorumLost(g, rows) {
  if (typeof g.quorumLost === "boolean") return g.quorumLost;
  if (typeof g.minHealthy !== "number") return false;
  return groupHealthyCount(g, rows) < g.minHealthy;
}

function batteryClass(charge) {
  if (isNaN(charge)) return "";
  if (charge < 20) return "crit";
  if (charge < 50) return "warn";
  return "ok";
}

function formatRuntimeSeconds(value) {
  if (value === undefined || value === null || value === "") return "—";
  const seconds = Math.trunc(Number(value));
  if (!Number.isFinite(seconds)) return "—";
  if (seconds >= 3600) {
    return Math.floor(seconds / 3600) + "h " +
      Math.floor((seconds % 3600) / 60) + "m";
  }
  if (seconds >= 60) {
    return Math.floor(seconds / 60) + "m " + (seconds % 60) + "s";
  }
  return seconds + "s";
}

// "just now" / "12s ago" / "4m ago" / "3h ago" / "14d ago" for an age in
// seconds (same wording as eneru.utils.format_age).
function formatAge(seconds) {
  const s = Number(seconds);
  if (seconds === null || seconds === undefined || !Number.isFinite(s)) return "unknown";
  if (s < 2) return "just now";
  if (s < 60) return Math.floor(s) + "s ago";
  if (s < 3600) return Math.floor(s / 60) + "m ago";
  if (s < 86400) return Math.floor(s / 3600) + "h ago";
  return Math.floor(s / 86400) + "d ago";
}

// ----- v6.2: role, "what happens next", freshness (H1/H3/H4/M3/M4) ---------
// All of these read the daemon's additive /api/v1/ups fields (role,
// triggerOutlook, nextTrigger, freshness, *Text) and degrade to the older
// fields when talking to a pre-6.2 daemon.

// Human durations everywhere (M3): the daemon's text when sent, else ours.
function durationText(text, seconds) {
  if (typeof text === "string" && text) return text;
  return formatRuntimeSeconds(seconds);
}
function timeOnBatteryText(u) {
  return durationText(u && u.timeOnBatteryText, u && u.timeOnBattery);
}
function runtimeText(u) { return durationText(u && u.runtimeText, u && u.runtime); }
function isOnBattery(u) { return nutStatusTokens(u && u.status).has("OB"); }

// What this UPS does to the world when a trigger fires (M4/H1). `role` from the
// daemon is built from the real shutdown plan; the fallback only knows isLocal
// and the configured remote servers.
function upsRole(u) {
  if (!u) return null;
  if (u.role && u.role.kind) return u.role;
  const cfgUps = ((typeof cfgSnapshot !== "undefined" && cfgSnapshot && cfgSnapshot.ups) || [])
    .find((c) => c.name === u.name);
  const remotes = cfgUps ? (cfgUps.remoteServers || []).filter(
    (s) => s.enabled !== false && !s.isHostLoopback).length : 0;
  const groups = ((typeof lastGroups !== "undefined" && lastGroups) || [])
    .filter((g) => (g.upsSources || []).includes(u.name)).map((g) => g.name);
  if (groups.length) {
    return { kind: "redundancy-member", hasShutdownActions: false,
      label: "Redundancy member (" + groups.join(", ") + ")",
      redundancyGroups: groups, remoteServers: remotes };
  }
  if (u.isLocal !== false) {
    return { kind: "local", label: "Powers this host", hasShutdownActions: true,
      shutsDownLocalHost: true, remoteServers: remotes, redundancyGroups: [] };
  }
  if (remotes) {
    return { kind: "remote-only", label: "Remote shutdowns only",
      hasShutdownActions: true, remoteServers: remotes, redundancyGroups: [] };
  }
  return { kind: "monitor-only", label: "Monitoring only", hasShutdownActions: false,
    remoteServers: 0, redundancyGroups: [] };
}

function roleBadge(u) {
  const role = upsRole(u);
  if (!role) return null;
  const cls = { "monitor-only": "muted", "remote-only": "info",
    "redundancy-member": "info", local: "role-local" }[role.kind] || "muted";
  return el("span", { class: "badge role-badge " + cls, text: role.label });
}

// The one-line consequence of a trigger firing ("Shuts down this host and 1
// remote server"), from triggerOutlook.action or derived from the role.
function actionLabel(u) {
  const o = u && u.triggerOutlook;
  if (o && o.action && o.action.label) return o.action.label;
  const role = upsRole(u);
  if (!role) return "";
  if (role.kind === "redundancy-member") {
    return "Marks this UPS critical for redundancy group "
      + (role.redundancyGroups || []).join(", ") + " (group decides)";
  }
  if (!role.hasShutdownActions) return "Notification only — nothing is shut down here";
  return role.kind === "remote-only" ? "Shuts down remote servers" : "Shuts down this host";
}

// A status badge from statusInfo(): short label, severity color, and the
// blink/pulse ONLY for the two "the host is going down" states (M1).
function statusBadge(info, extraCls) {
  return el("span", { class: "badge " + info.severity + (info.blink ? " pulse" : "")
    + (extraCls ? " " + extraCls : ""), text: info.label, title: info.detail });
}

// Enabled triggers that can still fire, soonest first; a fired one leads.
function upcomingTriggers(u) {
  const o = u && u.triggerOutlook;
  if (!o || !Array.isArray(o.triggers)) return [];
  const rank = (t) => (t.state === "fired" ? -1
    : (typeof t.etaSeconds === "number" ? t.etaSeconds : Infinity));
  return o.triggers
    .filter((t) => t && t.enabled !== false
      && ["fired", "held", "arming", "ok"].includes(t.state))
    .sort((a, b) => rank(a) - rank(b));
}

function triggerEta(t) {
  if (!t) return "";
  if (t.state === "fired") return "now";
  if (typeof t.etaSeconds === "number") return "in ≈" + formatRuntimeSeconds(t.etaSeconds);
  return "";
}

// "Shutdown in ≈3m 20s (runtime < 10m 0s) · or charge < 20% in ≈21m" — the
// single "what happens next, and when" line for the hero, fleet rows and the
// banner (H3). Null when nothing is armed (on mains) or nothing runs here.
function outlookLine(u) {
  const role = upsRole(u);
  const list = upcomingTriggers(u);
  if (!list.length || !role) return null;
  if (!role.hasShutdownActions && role.kind !== "redundancy-member") return null;
  const verb = role.kind === "redundancy-member" ? "Counts as failed for its group" : "Shutdown";
  const first = list[0];
  let head;
  if (first.state === "fired") head = verb + " now: " + first.condition;
  else if (first.state === "held") {
    head = verb + " after stabilization, " + triggerEta(first) + " (" + first.condition + ")";
  } else if (first.state === "arming") {
    // FAILSAFE countdown (failed NUT polls on battery): say how far along it is.
    head = verb + " " + triggerEta(first) + " unless NUT answers ("
      + (first.text || first.condition) + ")";
  } else if (typeof first.etaSeconds === "number") {
    head = verb + " " + triggerEta(first) + " (" + first.condition + ")";
  } else head = verb + " when " + first.condition;
  // Once one has fired, the rest are moot; otherwise name the next two.
  const rest = (first.state === "fired" ? [] : list.slice(1, 3)).map((t) => "or " + t.condition
    + (typeof t.etaSeconds === "number" ? " " + triggerEta(t) : ""));
  return [head].concat(rest).join(" · ");
}

// Data freshness (H4). ageSeconds is the daemon's age at build time; the time
// since our last successful fetch is added so the age keeps counting when the
// daemon stops answering.
let lastGoodFetchAt = 0;      // client ms of the last successful /api/v1/ups
let lastGeneratedAt = null;   // server epoch of that payload
function dataAgeSeconds(u) {
  const extra = lastGoodFetchAt ? Math.max(0, (Date.now() - lastGoodFetchAt) / 1000) : 0;
  const f = u && u.freshness;
  if (f && typeof f.ageSeconds === "number") return f.ageSeconds + extra;
  if (u && u.lastUpdateTime && lastGeneratedAt) {
    return Math.max(0, lastGeneratedAt - u.lastUpdateTime) + extra;
  }
  return null;
}
function dataIsStale(u) {
  const f = (u && u.freshness) || {};
  if (f.stale && f.lastPollAt != null) return true;
  const age = dataAgeSeconds(u);
  return age != null && age > (f.staleAfterSeconds || 30);
}

const CHART_UPS_SELECTS = ["power-ups", "battery-ups", "energy-ups"];
const SCOPE_ALL = "__all__";
const SCOPE_UPS = "ups:";
const SCOPE_GROUP = "redundancy:";

// The global UPS scope (header selector). "" / missing → All UPS.
function currentScope() {
  const s = document.getElementById("global-ups");
  return (s && s.value) || SCOPE_ALL;
}
function scopeIsAll() { return currentScope() === SCOPE_ALL; }
function scopeUpsName() {
  const scope = currentScope();
  if (scope.startsWith(SCOPE_UPS)) return scope.slice(SCOPE_UPS.length);
  return "";
}
function scopedGroup() {
  const scope = currentScope();
  if (!scope.startsWith(SCOPE_GROUP)) return null;
  const name = scope.slice(SCOPE_GROUP.length);
  return lastGroups.find((g) => g.name === name) || null;
}

// Concrete UPS name for views that cannot show a fleet (for example the
// single-plan shutdown fallback). Historical charts use their explicit source
// selectors instead.
function scopedName() {
  const upsName = scopeUpsName();
  if (upsName) return upsName;
  const group = scopedGroup();
  if (group) {
    const member = (group.upsSources || []).find(
      (name) => lastUpsRows.some((u) => u.name === name));
    if (member) return member;
  }
  return lastUpsRows.length ? lastUpsRows[0].name : "";
}

function rowsForScope(rows, scope) {
  if (scope === SCOPE_ALL) return rows;
  if (scope.startsWith(SCOPE_UPS)) {
    const upsName = scope.slice(SCOPE_UPS.length);
    const one = rows.filter((u) => u.name === upsName);
    return one.length ? one : rows;
  }
  if (scope.startsWith(SCOPE_GROUP)) {
    const groupName = scope.slice(SCOPE_GROUP.length);
    const group = lastGroups.find((g) => g.name === groupName);
    if (group) return rows.filter((u) => (group.upsSources || []).includes(u.name));
  }
  return rows;
}

// UPS rows honoring the scope: every row under Fleet, else just the scoped one.
// Used by the per-UPS card grids and the authenticated Control tab.
function scopedRows() {
  return rowsForScope(lastUpsRows, currentScope());
}

// Resolve the UPS used by a single-series chart. A specific dashboard view wins;
// fleet view preserves the operator's explicit chart pick across the 10s poll.
function chartSourceName(scope, rows, previous) {
  if (!rows.length) return "";
  const scoped = rowsForScope(rows, scope);
  if (scope !== SCOPE_ALL && scoped.some((u) => u.name === previous)) return previous;
  if (scope !== SCOPE_ALL && scoped.length) return scoped[0].name;
  if (rows.some((u) => u.name === previous)) return previous;
  return rows[0].name;
}

function updateChartSourceVisibility(rows) {
  const visible = scopedRows().length > 1;
  CHART_UPS_SELECTS.forEach((id) => {
    const sel = document.getElementById(id);
    const label = sel && sel.closest("label");
    if (label) label.hidden = !visible;
  });
}

// Populate the dashboard-view selector and the chart-local source selectors.
// Fleet charts are intentionally single-series in this patch, so their source
// must be visible and stable instead of silently meaning "the first UPS".
function populateChartUpsSelects(rows) {
  const g = document.getElementById("global-ups");
  const wrap = document.getElementById("global-ups-wrap");
  const totalScopes = rows.length + lastGroups.length;
  const multi = totalScopes > 1;
  // Preserve a valid prior scope; default to All. Single-UPS → that UPS, no control.
  let scope = g && g.value ? g.value : SCOPE_ALL;
  const valid = scope === SCOPE_ALL
    || (scope.startsWith(SCOPE_UPS)
      && rows.some((u) => u.name === scope.slice(SCOPE_UPS.length)))
    || (scope.startsWith(SCOPE_GROUP)
      && lastGroups.some((group) => group.name === scope.slice(SCOPE_GROUP.length)));
  if (!valid) scope = SCOPE_ALL;
  if (!multi) scope = rows.length ? SCOPE_UPS + rows[0].name : SCOPE_ALL;
  if (wrap) wrap.hidden = !multi;
  if (g) {
    g.replaceChildren();
    if (multi) g.appendChild(el("option", { value: SCOPE_ALL, text: "Fleet overview" }));
    rows.forEach((u) => g.appendChild(el("option", {
      value: SCOPE_UPS + u.name, text: u.label || u.name })));
    lastGroups.forEach((group) => g.appendChild(el("option", {
      value: SCOPE_GROUP + group.name, text: "Redundancy · " + group.name })));
    g.value = scope;
  }
  CHART_UPS_SELECTS.forEach((id) => {
    const sel = document.getElementById(id);
    if (!sel) return;
    const chartRows = scope.startsWith(SCOPE_GROUP) ? rowsForScope(rows, scope) : rows;
    const chosen = chartSourceName(scope, rows, sel.value);
    sel.replaceChildren();
    chartRows.forEach((u) =>
      sel.appendChild(el("option", { value: u.name, text: u.label || u.name })));
    if (chosen) sel.value = chosen;
  });
  updateChartSourceVisibility(rows);
}

// A concrete view also scopes its chart. Fleet view leaves the explicit chart
// source alone, then exposes that selector so the operator controls the series.
function onScopeChanged() {
  if (!scopeIsAll()) {
    const chosen = scopedName();
    CHART_UPS_SELECTS.forEach((id) => {
      const s = document.getElementById(id);
      if (s && chosen) s.value = chosen;
    });
  }
  populateChartUpsSelects(lastUpsRows);
  applyScopeChrome();
  onTabActivated(activeTab);
}

// The global selector drives the scoped tabs; on Events it also seeds the Source
// filter (so it's still doing something), and only on Config is it truly inert —
// dim + explain it only there. aria-label carries the reason for AT users.
function applyScopeChrome() {
  const wrap = document.getElementById("global-ups-wrap");
  if (wrap) {
    const inert = activeTab === "config";
    wrap.classList.toggle("inactive", inert);
    const msg = inert ? "Config is fleet-wide; the UPS selector doesn't apply here"
      : (activeTab === "events" ? "Filters the events by UPS" : "");
    wrap.title = msg;
    if (msg) wrap.setAttribute("aria-label", "UPS to show — " + msg);
    else wrap.removeAttribute("aria-label");
  }
  if (activeTab === "events") seedEventSourceFromScope();
}

// The header UPS selector is the Events source control now (the separate Source
// dropdown is retired), so mirror the scope into the events source filter —
// "All UPS" → all sources, a pick → that UPS.
function seedEventSourceFromScope() {
  const src = document.getElementById("event-source-filter");
  if (!src) return;
  const scope = currentScope();
  const target = scope.startsWith(SCOPE_UPS) ? scope.slice(SCOPE_UPS.length) : "";
  if (src.value === target) return;
  if (target === "" || [...src.options].some((o) => o.value === target)) {
    src.value = target;
    if (typeof applyEventFilters === "function") applyEventFilters();
  }
}

// ----- Overview hero + KPI summary (rc9) -----------------------------------

// SVG battery ring gauge: a track circle + a value arc (dasharray), centered
// label. Colored by status class. The signature visual of the Overview.
function batteryRing(pct, statusCls, caption) {
  const R = 52, C = 2 * Math.PI * R;
  const p = Math.max(0, Math.min(100, isNaN(pct) ? 0 : pct));
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", "0 0 120 120");
  svg.setAttribute("class", "ring s-" + (statusCls || "ok"));
  const circle = (cls, extra) => {
    const c = document.createElementNS(SVG_NS, "circle");
    c.setAttribute("cx", "60"); c.setAttribute("cy", "60"); c.setAttribute("r", String(R));
    c.setAttribute("class", cls);
    if (extra) for (const k in extra) c.setAttribute(k, extra[k]);
    svg.appendChild(c);
  };
  circle("ring-track");
  circle("ring-arc", {
    transform: "rotate(-90 60 60)", "stroke-linecap": "round",
    "stroke-dasharray": `${(p / 100 * C).toFixed(1)} ${C.toFixed(1)}`,
  });
  const txt = (cls, y, s) => {
    const t = document.createElementNS(SVG_NS, "text");
    t.setAttribute("x", "60"); t.setAttribute("y", String(y));
    t.setAttribute("text-anchor", "middle"); t.setAttribute("class", cls);
    t.textContent = s; svg.appendChild(t);
  };
  txt("ring-big", 60, isNaN(pct) ? "—" : Math.round(p) + "%");
  // Caption is a CHARGE band, not a power word ("ON LINE" read as a power state
  // even mid-outage). heroCard overrides it to "ON BATTERY" during an outage.
  txt("ring-cap", 78, caption || (p >= 95 ? "CHARGED" : p >= 20 ? "READY" : "LOW"));
  return svg;
}

function heroCard(u) {
  const charge = parseFloat(u.batteryCharge);
  const info = statusInfo(u);
  const sCls = info.severity;
  const pq = u.powerQuality || {};
  const onBattery = isOnBattery(u);
  // Ring turns amber the moment we're on battery (red once low / triggered /
  // shutting down), and the caption says ON BATTERY — so an outage doesn't read
  // as a calm green ring.
  const ringCls = sCls === "ok" ? (batteryClass(charge) || "ok") : sCls;
  const wrap = el("div", { class: "hero card-click s-" + sCls
    + (onBattery ? " hero-alarm" : ""), tabindex: "0",
    role: "button", title: "View details" });
  wrap.appendChild(batteryRing(charge, ringCls, onBattery ? "ON BATTERY" : null));
  const vital = (label, value, cls) => el("div", null, [
    el("div", { class: "v-label", text: label }),
    el("div", { class: "v-value" + (cls ? " " + cls : ""), text: value }),
  ]);
  // Plain "on battery": one badge carrying the time ("On battery · 7m 0s")
  // instead of two badges saying the same thing (L7).
  const merged = onBattery && info.state === "on_battery";
  const badge = statusBadge(info);
  if (merged) badge.textContent = info.label + " · " + timeOnBatteryText(u);
  const title = el("div", { class: "hero-title" }, [
    icon("battery"), el("h3", { text: u.label || u.name }), badge,
  ]);
  // Promote time-on-battery to a prominent alarm chip during an outage — it's
  // the number the operator needs first, and it was the last, easily-missed vital.
  if (onBattery && !merged) {
    title.appendChild(el("span", { class: "badge " + sCls + " hero-ob",
      text: "On battery · " + timeOnBatteryText(u) }));
  }
  const rb = roleBadge(u);
  if (rb) title.appendChild(rb);
  // The full NUT wording (all flags) + how fresh the reading is (H4).
  const age = dataAgeSeconds(u);
  const stale = dataIsStale(u);
  const sub = el("p", { class: "hero-detail" }, [
    el("span", { text: info.detail }),
    age != null ? el("span", { class: "fresh" + (stale ? " stale" : ""),
      text: (stale ? "STALE · " : "") + "updated " + formatAge(age) }) : null,
  ].filter(Boolean));
  const vitals = [
    vital("Runtime", runtimeText(u)),
    vital("Load", u.load != null && u.load !== "" ? u.load + "%" : "—"),
    vital("Input", fmtUnit(pq.inputVoltage, "V") || "—"),
  ];
  // Time-on-battery only when actually on battery — a permanent "0s" is noise,
  // and during an outage it's already the prominent chip in the title.
  if (onBattery) vitals.push(vital("On battery", timeOnBatteryText(u), sCls));
  // Surface line quality on the Overview only when it's NOT good — otherwise it's
  // buried on the Power tab where the operator rarely looks. (operator #14)
  const lq = lineQuality(pq);
  if (lq.cls === "warn" || lq.cls === "crit") {
    vitals.push(vital("Line quality", lq.label, lq.cls));
  }
  wrap.appendChild(el("div", { class: "hero-main" }, [
    title, sub, el("div", { class: "hero-vitals" }, vitals), heroOutlook(u),
  ].filter(Boolean)));
  const open = () => openDetail(u.name);
  wrap.addEventListener("click", open);
  wrap.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); open(); }
  });
  return wrap;
}

// "What happens next" block on the single-UPS hero (H3): the closest trigger,
// what firing it does, and every other armed trigger with its live value and
// ETA. Shown only while something is armed (on battery, or a trigger fired).
function heroOutlook(u) {
  const list = upcomingTriggers(u);
  const role = upsRole(u);
  if (!list.length || !role) return null;
  const member = role.kind === "redundancy-member";
  const acts = role.hasShutdownActions || member;
  const first = list[0];
  // A member's fired trigger is a vote, not the verdict: amber (F-184).
  const sev = first.state === "fired" && !member ? "crit" : "warn";
  const box = el("div", { class: "hero-outlook s-" + (acts ? sev : "muted") });
  if (!acts) {
    box.appendChild(el("p", { class: "ho-head", text: "Nothing is shut down here" }));
    box.appendChild(el("p", { class: "ho-action",
      text: (u.label || u.name) + " is monitored only; Eneru just records and notifies." }));
    return box;
  }
  box.appendChild(el("p", { class: "ho-head", text: outlookLine(u).split(" · ")[0] }));
  box.appendChild(el("p", { class: "ho-action", text: "→ " + actionLabel(u) }));
  const ul = el("ul", { class: "ho-list", "aria-label": "Shutdown triggers" });
  list.forEach((t) => {
    ul.appendChild(el("li", { class: "ho-" + t.state }, [
      el("span", { class: "ho-label", text: t.label }),
      el("span", { class: "ho-text", text: t.text || t.condition }),
      el("span", { class: "ho-eta", text: triggerEta(t) || "—" }),
    ]));
  });
  box.appendChild(ul);
  return box;
}

function fleetSnapshot(rows) {
  // This is an operator-facing count, not the redundancy quorum count.
  // BOOST/TRIM/BYPASS remain electrically available for quorum purposes, but
  // they are warning states the dashboard must name rather than hide.
  const healthy = rows.filter((u) => fleetUpsClass(u) === "ok").length;
  const onBattery = rows.filter(
    (u) => nutStatusTokens(u.status).has("OB")).length;
  const states = rows.map((u) => statusInfo(u).state);
  return {
    total: rows.length,
    healthy,
    attention: rows.length - healthy,
    onBattery,
    shuttingDown: states.filter((s) => s === "shutting_down").length,
    triggered: states.filter((s) => s === "trigger_active").length,
  };
}

function fleetUpsClass(u) {
  // The shared severity (M1); a connection hiccup (e.g. GRACE_PERIOD) on an
  // otherwise-fine UPS still reads amber.
  const cls = statusInfo(u).severity;
  if (cls !== "ok") return cls;
  const state = (u.connectionState || "").toUpperCase();
  if (state && state !== "OK" && state !== "CONNECTED") return "warn";
  return "ok";
}

function fleetOverallClass(rows) {
  const classes = rows.map(fleetUpsClass);
  if (classes.includes("crit")) return "crit";
  if (classes.includes("warn")) return "warn";
  return "ok";
}

// Fleet mode is a comparison surface, not a disguised single-UPS hero. Each
// source appears once with the five readings an operator needs to decide where
// to drill in; the existing detail modal remains the deeper view.
function fleetOverview(rows) {
  const state = fleetSnapshot(rows);
  const overall = fleetOverallClass(rows);
  // Headline names the most urgent fleet state (M2): shutting down beats a
  // fired trigger beats on-battery beats "needs attention".
  const headline = state.shuttingDown ? "Shutting down"
    : state.triggered ? "Shutdown triggered"
      : state.onBattery
        ? state.onBattery + " UPS on battery"
        : state.attention
          ? state.attention + " UPS " + (state.attention === 1 ? "needs" : "need") + " attention"
          : "Fleet healthy";
  const counts = state.healthy + " healthy · " + state.total + " monitored";

  const wrap = el("section", { class: "fleet-overview s-" + overall,
    "aria-labelledby": "fleet-overview-title" });
  // No status badge in the head: the headline + counts already say it (L7).
  wrap.appendChild(el("div", { class: "fleet-overview-head" }, [
    el("div", { class: "fleet-overview-heading" }, [
      el("span", { class: "card-ico s-" + overall }, [icon("battery")]),
      el("div", null, [
        el("h3", { id: "fleet-overview-title", text: headline }),
        el("p", { text: counts }),
      ]),
    ]),
  ]));

  const list = el("div", { class: "fleet-overview-list" });
  list.appendChild(el("div", { class: "fleet-overview-columns", "aria-hidden": "true" }, [
    el("span", { text: "UPS" }), el("span", { text: "Status" }),
    el("span", { text: "Charge" }), el("span", { text: "Runtime" }),
    el("span", { text: "Load" }), el("span", { text: "Input" }),
  ]));
  rows.forEach((u) => {
    const cls = fleetUpsClass(u);
    const info = statusInfo(u);
    const pq = u.powerQuality || {};
    const label = u.label || u.name;
    const values = {
      charge: formatFleetMetric(u.batteryCharge, "%"),
      runtime: runtimeText(u),
      load: formatFleetMetric(u.load, "%"),
      input: formatFleetMetric(pq.inputVoltage, " V"),
    };
    // Second line, only when there is something to say: time on battery and
    // the next trigger (H3), or how old the reading is when stale (H4).
    const subParts = [];
    if (isOnBattery(u)) subParts.push("On battery " + timeOnBatteryText(u));
    const next = outlookLine(u);
    if (next) subParts.push(next);
    if (dataIsStale(u)) subParts.push("STALE · updated " + formatAge(dataAgeSeconds(u)));
    const role = upsRole(u);
    const aria = label + ": " + info.label + " (" + info.detail + "), "
      + values.charge + " charge, " + values.runtime + " runtime, "
      + values.load + " load, " + values.input + " input"
      + (role ? ", " + role.label.toLowerCase() : "")
      + (subParts.length ? ". " + subParts.join(". ") : "") + " — view details";
    const row = el("button", { class: "fleet-overview-row s-" + cls,
      type: "button", "aria-label": aria, title: "View " + label + " details" }, [
      el("span", { class: "fleet-overview-name" }, [
        el("strong", { text: label }),
        roleBadge(u),
      ].filter(Boolean)),
      statusBadge(info, "fleet-overview-status"),
      el("span", { class: "fleet-overview-value", "data-label": "Charge",
        text: values.charge }),
      el("span", { class: "fleet-overview-value", "data-label": "Runtime",
        text: values.runtime }),
      el("span", { class: "fleet-overview-value", "data-label": "Load",
        text: values.load }),
      el("span", { class: "fleet-overview-value", "data-label": "Input",
        text: values.input }),
      subParts.length ? el("span", { class: "fleet-overview-sub s-" + cls,
        "aria-hidden": "true", text: subParts.join(" · ") }) : null,
    ].filter(Boolean));
    row.addEventListener("click", () => openDetail(u.name));
    list.appendChild(row);
  });
  wrap.appendChild(list);
  return wrap;
}

// A compact KPI summary card that drills through to its tab on click.
function kpiCard({ iconName, label, value, unit, cap, valueStatus, tab }) {
  const card = el("div", { class: "card kpi card-click", tabindex: "0", role: "button" });
  card.appendChild(el("div", { class: "k-label" }, [icon(iconName), el("span", { text: label })]));
  const val = el("div", { class: "k-value" + (valueStatus ? " s-" + valueStatus : "") });
  val.appendChild(document.createTextNode(value));
  if (unit) val.appendChild(el("span", { class: "unit", text: unit }));
  card.appendChild(val);
  card.appendChild(el("div", { class: "k-cap", text: cap || "" }));
  const go = () => selectTab(tab, { updateHash: true });
  card.addEventListener("click", go);
  card.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); go(); }
  });
  return card;
}

function renderOverviewSummary(rows) {
  const hero = document.getElementById("overview-hero");
  const summary = document.getElementById("overview-summary");
  if (!hero || !summary) return;
  hero.replaceChildren();
  summary.replaceChildren();
  // The global UPS selector scopes the Overview too: a single pick drives the
  // hero + KPIs to that UPS; "All UPS" shows the whole fleet (worst status,
  // lowest health, total energy). The fleet strip above always lists every UPS.
  const view = rowsForScope(rows, currentScope());
  if (!view.length) {
    hero.appendChild(el("p", { class: "chart-note", text: "No UPS data yet." }));
    return;
  }

  if (view.length > 1) {
    hero.appendChild(fleetOverview(view));
  } else {
    hero.appendChild(heroCard(view[0]));
  }

  // Three drill-through KPI cards surfacing the v6.1 data otherwise buried on
  // other tabs. Under "All UPS" they summarize ACROSS the fleet (worst battery
  // health, total energy, worst self-test); scoped to one UPS they show its
  // values. (operator #11, plan #4)
  const multi = view.length > 1;
  const named = (u) => u.label || u.name;

  // Battery health: the lowest score in the fleet (the one that needs attention).
  const bhRows = view.filter((u) => u.batteryHealth && u.batteryHealth.score != null);
  if (bhRows.length) {
    const worst = bhRows.slice().sort(
      (a, b) => a.batteryHealth.score - b.batteryHealth.score)[0];
    const bh = worst.batteryHealth;
    summary.appendChild(kpiCard({
      iconName: "shield", label: multi ? "Battery health · lowest" : "Battery health",
      value: Math.round(bh.score), unit: "/100",
      cap: (multi ? named(worst) + " · " : "")
        + (bh.confidence != null ? "confidence " + Math.round(bh.confidence * 100) + "%" : ""),
      valueStatus: (bh.confidence != null && bh.confidence < 0.75)
        ? "muted" : scoreClass(bh.score), tab: "battery" }));
  } else {
    summary.appendChild(kpiCard({ iconName: "shield", label: "Battery health",
      value: "—", unit: "", cap: "no data yet", tab: "battery" }));
  }

  // Energy today: the fleet total (a single UPS keeps its cost caption).
  const enRows = view.filter((u) => u.energy && u.energy.todayKwh != null);
  if (enRows.length) {
    const totalKwh = enRows.reduce((s, u) => s + u.energy.todayKwh, 0);
    let cap;
    if (multi) {
      cap = enRows.length + " of " + view.length + " UPS · today";
    } else {
      const en = enRows[0].energy;
      cap = en.todayCostFormatted ? en.todayCostFormatted + " today"
        : (en.monthKwh != null ? en.monthKwh.toFixed(1) + " kWh this month" : "today");
    }
    summary.appendChild(kpiCard({
      iconName: "chart", label: multi ? "Energy today · fleet" : "Energy today",
      value: totalKwh.toFixed(2), unit: " kWh", cap, tab: "energy" }));
  } else {
    summary.appendChild(kpiCard({ iconName: "chart", label: "Energy today",
      value: "—", unit: "", cap: "—", tab: "energy" }));
  }

  // Last self-test: the worst result across the fleet (failed > running > passed),
  // so a single failed test isn't masked by another UPS's pass. Only shown once
  // a test has actually run somewhere.
  const stRows = view.filter(
    (u) => u.selfTest && ["passed", "failed", "running"].includes(u.selfTest.result));
  if (stRows.length) {
    const rankSt = { failed: 0, running: 1, passed: 2 };
    const worstSt = stRows.slice().sort(
      (a, b) => rankSt[a.selfTest.result] - rankSt[b.selfTest.result])[0];
    const st = worstSt.selfTest;
    const stStatus = { passed: "ok", failed: "crit", running: "warn" }[st.result] || null;
    summary.appendChild(kpiCard({
      iconName: "check", label: multi ? "Self-test (worst of fleet)" : "Last self-test",
      value: titleCase(st.result),
      cap: multi ? named(worstSt) + (selfTestDate(st) ? " · " + selfTestDate(st) : "")
        : selfTestDate(st),
      valueStatus: stStatus, tab: "battery" }));
  }
}

// When a self-test ran: the device date, else the day Eneru saw it start (L7:
// a passively observed test has startedTs but no date).
function selfTestDate(st) {
  if (!st) return "";
  if (st.date) return st.date;
  if (!st.startedTs) return "";
  const d = new Date(st.startedTs * 1000);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0")
    + "-" + String(d.getDate()).padStart(2, "0");
}

// The role tag ("Powers this host" / "Remote shutdowns only" / "Monitoring
// only" / "Redundancy member (…)") for titles. v6.2 (M4): driven by the
// daemon's role (the real shutdown plan), not by isLocal alone, so a non-local
// UPS that still shuts down remote servers is no longer called "monitoring only".
function monitoringBadge(u) {
  return u ? roleBadge(u) : null;
}

// Persistent fleet-status strip (above the tabs, every tab). A healthy fleet is
// one calm summary; only sources needing attention get their own safety chip.
// Hidden for a single-UPS deployment. (operator #1)
function renderFleetStrip(rows) {
  const strip = document.getElementById("fleet-strip");
  if (!strip) return;
  strip.replaceChildren();
  if (rows.length <= 1) { strip.hidden = true; return; }
  strip.hidden = false;
  const state = fleetSnapshot(rows);
  const overall = fleetOverallClass(rows);
  const summaryText = state.shuttingDown ? "Shutting down"
    : state.attention
      ? state.healthy + " healthy · " + state.attention + " "
        + (state.attention === 1 ? "needs" : "need") + " attention"
      : state.total + " UPS healthy";
  const summary = el("button", { class: "fleet-chip fleet-summary-chip s-" + overall,
    type: "button", title: "Open fleet overview",
    "aria-label": summaryText + " — open fleet overview" }, [
    el("span", { class: "fleet-dot", "aria-hidden": "true" }),
    el("span", { class: "fleet-name", text: summaryText }),
    el("span", { class: "fleet-go", "aria-hidden": "true", text: "›" }),
  ]);
  summary.addEventListener("click", () => {
    const view = document.getElementById("global-ups");
    if (view) view.value = SCOPE_ALL;
    onScopeChanged();
    selectTab("overview", { updateHash: true });
  });
  strip.appendChild(summary);

  rows.filter((u) => fleetUpsClass(u) !== "ok").forEach((u) => {
    const cls = fleetUpsClass(u);
    const info = statusInfo(u);
    const role = upsRole(u);
    const charge = parseFloat(u.batteryCharge);
    const ob = isOnBattery(u);
    const tag = role && role.kind === "monitor-only" ? "monitoring"
      : role && role.kind === "remote-only" ? "remote only" : null;
    // Full accessible name — the status/charge/runtime/role live in separate
    // spans that a screen reader would run together ambiguously.
    const aria = (u.label || u.name) + ": " + info.label + " (" + info.detail + "), "
      + (isNaN(charge) ? "charge unknown" : charge + "% charge") + ", "
      + runtimeText(u) + " runtime"
      + (ob ? ", on battery for " + timeOnBatteryText(u) : "")
      + (role ? ", " + role.label.toLowerCase() : "") + " — view details";
    const chip = el("button", { class: "fleet-chip s-" + cls, type: "button",
      title: "View " + (u.label || u.name) + " details", "aria-label": aria }, [
      el("span", { class: "fleet-name", text: u.label || u.name }),
      statusBadge(info),
      el("span", { class: "fleet-metric", text: (isNaN(charge) ? "—" : charge + "%")
        + (ob ? " · " + timeOnBatteryText(u) : "") }),
      tag ? el("span", { class: "fleet-tag", text: tag }) : null,
      el("span", { class: "fleet-go", "aria-hidden": "true", text: "›" }),
    ].filter(Boolean));
    chip.addEventListener("click", () => openDetail(u.name));
    strip.appendChild(chip);
  });
}

function renderUps(payload) {
  const rows = (payload && payload.ups) || [];
  lastUpsRows = rows;
  lastGroups = (payload && payload.redundancyGroups) || [];
  populateChartUpsSelects(rows);
  renderFleetStrip(rows);
  // The per-UPS "UPS status" grid is retired — it duplicated the always-on fleet
  // strip (every UPS at a glance, chips drill into the detail modal) and the
  // scoped hero. Keep the section element hidden. (v6.1.4 review)
  const upsSec = document.getElementById("ups-section");
  if (upsSec) upsSec.hidden = true;
  renderOverviewSummary(rows);

  renderRedundancy();
  renderRemoteHealth();
  updateEventSourceFilter(rows, lastGroups);
}

// Redundancy-groups section, scoped by the global selector (groups are per-UPS
// via upsSources). Re-rendered on scope change from onTabActivated("overview").
function renderRedundancy() {
  const gsec = document.getElementById("groups-section");
  const gwrap = document.getElementById("group-cards");
  if (!gsec || !gwrap) return;
  const rows = lastUpsRows;
  let groups = lastGroups || [];
  const group = scopedGroup();
  const upsName = scopeUpsName();
  if (group) groups = groups.filter((g) => g.name === group.name);
  else if (upsName) groups = groups.filter((g) => (g.upsSources || []).includes(upsName));
  gwrap.replaceChildren();
  // Only surface the Redundancy section when groups are actually configured.
  // The vast majority run independent UPSes, for whom an empty "configure
  // redundancy groups" hint is permanent noise on the Overview — hide it
  // entirely rather than advertising a feature they haven't opted into.
  gsec.hidden = groups.length === 0;
  if (groups.length === 0) return;
  groups.forEach((g) => {
    const sources = g.upsSources || [];
    const healthy = groupHealthyCount(g, rows);
    const min = g.minHealthy;
    const out = groupOutlook(g, rows);
    const cls = out.severity;
    const cardRows = [
      el("div", { class: "card-head" }, [
        el("span", { class: "card-ico s-" + cls }, [icon("shield")]),
        el("h3", { text: g.name }),
        el("span", { class: "badge " + cls + (out.state === "shutting-down" ? " pulse" : ""),
          text: healthy + " of " + sources.length + " healthy · need " + min }),
      ]),
      // M9: the consequence, in words — "1 more failure → group shutdown".
      el("p", { class: "group-outlook s-" + cls, text: out.label }),
    ];
    if (out.action) {
      cardRows.push(el("p", { class: "group-action", text: "When it fires: " + out.action }));
    }
    // Every member with its own state chip, failing ones first.
    const failing = new Set(groupFailingMembers(g, rows));
    const members = el("ul", { class: "group-members", "aria-label": "Members of " + g.name });
    sources.slice().sort((a, b) => (failing.has(b) ? 1 : 0) - (failing.has(a) ? 1 : 0))
      .forEach((name) => {
        const u = rows.find((r) => r.name === name);
        const info = (g.members && g.members[name]) || {};
        const bad = failing.has(name);
        const reason = info.healthReason
          || (u ? statusInfo(u).label : "no data");
        const next = info.nextTrigger;
        members.appendChild(el("li", { class: bad ? "failing" : "healthy" }, [
          el("span", { class: "gm-name", text: (u && (u.label || u.name)) || name }),
          el("span", { class: "badge " + (bad ? cls === "ok" ? "warn" : cls : "ok"),
            text: bad ? reason : "healthy" }),
          next && next.state !== "idle" && next.state !== "disabled"
            ? el("span", { class: "gm-next",
              text: next.label + ": " + (next.text || next.condition)
                + (triggerEta(next) ? " · " + triggerEta(next) : "") }) : null,
        ].filter(Boolean)));
      });
    cardRows.push(members);
    const telemetry = g.telemetry || {};
    const load = telemetry.redundancyLoad || {};
    if (load.percent != null) {
      cardRows.push(hintedRow("Failover load", load.percent.toFixed(1) + "%",
        load.draw + " " + load.unit + " across " + load.capacity + " "
          + load.unit + " of " + load.basis));
    } else if (load.unavailableReason) {
      cardRows.push(hintedRow("Failover load", "—", load.unavailableReason));
    }
    gwrap.appendChild(el("div", { class: "card group-card s-" + cls }, cardRows));
  });
}

// The group's "what happens next" (M9): the daemon's outlook when sent, else
// the same rule computed from healthy vs required.
function groupOutlook(g, rows) {
  if (g.outlook && g.outlook.label) {
    return { state: g.outlook.state, label: g.outlook.label,
      severity: SEVERITY_RANK[g.outlook.severity] !== undefined ? g.outlook.severity : "warn",
      action: g.outlook.action || "" };
  }
  const healthy = groupHealthyCount(g, rows);
  const tolerated = healthy - (g.minHealthy || 0);
  const failing = groupFailingMembers(g, rows).length;
  if (groupQuorumLost(g, rows)) {
    return { state: "quorum-lost", severity: "crit",
      label: "Quorum lost → group shutdown runs", action: "" };
  }
  if (tolerated === 0) {
    return { state: "at-risk", severity: "warn",
      label: "1 more failure → group shutdown", action: "" };
  }
  return { state: "healthy", severity: failing ? "warn" : "ok", action: "",
    label: "Can lose " + tolerated + " more member" + (tolerated === 1 ? "" : "s") };
}

function groupFailingMembers(g, rows) {
  if (Array.isArray(g.failingMembers)) return g.failingMembers;
  return (g.upsSources || []).filter((name) => {
    const u = rows.find((r) => r.name === name);
    return !u || !upsHealthy(u);
  });
}

// ----- UPS detail drill-down (Slice D) -----

let openDetailName = null;
// Where focus was before the modal opened, so closing returns it there instead
// of dropping keyboard / screen-reader users back at the top of the page.
let detailReturnFocus = null;

function detailRow(label, value) {
  return el("div", { class: "row" }, [
    el("span", { text: label }),
    el("b", { text: (value === undefined || value === null || value === "")
      ? "—" : String(value) }),
  ]);
}

function detailSection(title, rows) {
  return el("div", { class: "detail-section" },
    [el("h4", { text: title })].concat(rows));
}

function remoteHealthReachable(row) {
  const status = String((row && row.status) || "").toUpperCase();
  return row && (
    row.healthy === true || row.reachable === true ||
    status === "HEALTHY" || status === "OK"
  );
}

// L4: a "reachable" verdict is only as good as its age. Past the configured
// remote_health.interval (plus a minute of slack) it's overdue; during an
// outage, anything older than 5 minutes no longer describes "now".
const SLOW_SSH_MS = 2000;   // remote_health.py SLOW_REMOTE_SSH_LOG_THRESHOLD_MS
function remoteCheckAge(row) {
  if (!row || !row.last_checked_at) return null;
  return Math.max(0, Date.now() / 1000 - row.last_checked_at);
}
function remoteCheckIsOld(row) {
  const age = remoteCheckAge(row);
  if (age == null) return false;
  const rh = (typeof cfgSnapshot !== "undefined" && cfgSnapshot && cfgSnapshot.remoteHealth) || {};
  const interval = Number(rh.interval) || 3600;
  if (age > interval + 60) return true;
  const outage = ((typeof lastUpsRows !== "undefined" && lastUpsRows) || []).some(isOnBattery);
  return outage && age > 300;
}

function remoteStatusClass(row) {
  // Check the explicit status FIRST: a DEGRADED row may also carry
  // reachable:true, and it should read amber, not green.
  const s = String((row && row.status) || "").toUpperCase();
  if (s.includes("DEGRADED") || s.includes("WARN")) return "warn";
  if (remoteHealthReachable(row)) return "ok";
  return "crit";
}

// Overview widget: SSH shutdown targets / remote NUT servers and whether the
// daemon can currently reach them (from /api/v1/remote-health). Hidden when none
// are configured.
function renderRemoteHealth() {
  const sec = document.getElementById("remote-section");
  const wrap = document.getElementById("remote-cards");
  if (!sec || !wrap) return;
  // Remote servers belong either to a UPS label or to "redundancy:<name>".
  let servers = remoteHealthSnapshot || [];
  const group = scopedGroup();
  const upsName = scopeUpsName();
  if (group) {
    servers = servers.filter((s) => s.group === SCOPE_GROUP + group.name);
  } else if (upsName) {
    const u = lastUpsRows.find((r) => r.name === upsName);
    const lbl = u && (u.label || u.name);
    servers = servers.filter((s) => s.group === upsName || s.group === lbl);
  }
  sec.hidden = servers.length === 0;
  if (!servers.length) { wrap.replaceChildren(); return; }
  wrap.replaceChildren(...servers.map((r) => {
    const cls = remoteStatusClass(r);
    const reachable = remoteHealthReachable(r);
    const name = r.server || r.host || "server";
    // An old "reachable" is neutral, not green: it says what WAS true. The
    // strip, the icon and the badge all use the same neutral class.
    const old = cls === "ok" && remoteCheckIsOld(r);
    // Health is carried by the colored status strip + icon + the Status row; the
    // badge stays out of the head so a long server name isn't clipped.
    const rows = [el("div", { class: "card-head" }, [
      el("span", { class: "card-ico s-" + (old ? "muted" : cls) }, [icon("shield")]),
      el("h3", { text: name }),
    ])];
    // Label matches the color: ok→reachable, warn→degraded, crit→unreachable
    // (a DEGRADED server is amber, not a contradictory "unreachable").
    const statusText = cls === "ok" ? (old ? "reachable " + relTime(r.last_checked_at) : "reachable")
      : cls === "warn" ? "degraded" : "unreachable";
    rows.push(el("div", { class: "row" }, [el("span", { text: "Status" }),
      el("span", { class: "badge " + (old ? "muted" : cls), text: statusText })]));
    if (r.host && r.host !== name) rows.push(configKv("Host", r.host));
    if (r.latency_ms != null && reachable) {
      const slow = r.latency_ms >= SLOW_SSH_MS;
      rows.push(slow
        ? el("div", { class: "row" }, [
          el("span", { class: "label-tip" }, [el("span", { text: "Latency" }),
            helpHint("Slower than the " + (SLOW_SSH_MS / 1000) + " s slow-SSH threshold; "
              + "a shutdown to this server may take longer than planned.")]),
          el("b", { class: "warn", text: Math.round(r.latency_ms) + " ms" })])
        : configKv("Latency", Math.round(r.latency_ms) + " ms"));
    }
    rows.push(hintedRow("Last checked", relTime(r.last_checked_at),
      r.last_checked_at ? new Date(r.last_checked_at * 1000).toLocaleString()
        + (old ? " — an old result, not a live check" : "") : null));
    if (r.consecutive_failures) {
      rows.push(el("div", { class: "row" }, [el("span", { text: "Failures" }),
        el("b", { class: "crit", text: String(r.consecutive_failures) })]));
    }
    if (!reachable && r.last_error) {
      rows.push(el("div", { class: "row" },
        [el("span", { class: "energy-note", text: r.last_error })]));
    }
    return el("div", { class: "card s-" + (old ? "muted" : cls) }, rows);
  }));
}

function openDetail(name) {
  detailReturnFocus = document.activeElement;
  openDetailName = name;
  renderDetail(name);
  const modal = document.getElementById("detail-modal");
  modal.hidden = false;
  // Pull focus into the dialog so Tab stays among its controls and assistive
  // tech announces it; the close button is the first focusable element.
  document.getElementById("detail-close").focus();
  trapModalFocus(modal, closeDetail);
}

// Trap Tab within a dialog and close on Esc so keyboard/AT users can't tab out
// to the page behind it and can always dismiss it. (a11y #10)
function trapModalFocus(modal, close) {
  const onKey = (ev) => {
    if (ev.key === "Escape") { ev.preventDefault(); close(); return; }
    if (ev.key !== "Tab") return;
    const f = Array.from(modal.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'))
      .filter((e) => !e.disabled && e.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
    else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
  };
  modal.addEventListener("keydown", onKey);
  modal._trap = onKey;
}

function closeDetail() {
  const modal = document.getElementById("detail-modal");
  if (modal._trap) { modal.removeEventListener("keydown", modal._trap); modal._trap = null; }
  openDetailName = null;
  modal.hidden = true;
  if (detailReturnFocus && typeof detailReturnFocus.focus === "function") {
    detailReturnFocus.focus();
  }
  detailReturnFocus = null;
}

const BH_TERM_LABELS = {
  capacity: "Capacity trend", runtime: "Runtime vs nominal",
  anomaly: "Anomalies", age: "Battery age",
};
const BH_TERM_HELP = {
  capacity: "Runtime trend over time vs the nominal full runtime. Needs about "
    + "two weeks of history before it's trusted — until then it reads n/a rather "
    + "than guessing (a few days of jitter would otherwise look like total loss).",
  runtime: "Current runtime under load vs the expected full runtime. n/a until "
    + "the nominal runtime is configured or learned at a full charge.",
  anomaly: "Confirmed battery anomalies; each one lowers the score.",
  age: "Battery age vs its expected service life. Higher is younger; a low "
    + "score means the battery is near or past its expected life. Set this "
    + "UPS's own battery_install_date + expected_life_years (they're per-UPS).",
};

// "Replace in" as a sane, bounded estimate (H6). The daemon's
// batteryHealth.replacement (6.2) is used as-is; otherwise the old raw
// replacementDaysRemaining is capped at the age-based remaining life and
// formatted like eneru.health.prediction.format_replacement_eta — never
// "~204288 days".
const MAX_REPLACEMENT_DAYS = 3652.5;
function formatReplacementEta(days) {
  const d = Number(days);
  if (days === null || days === undefined || !Number.isFinite(d)) return "unknown";
  if (d <= 0) return "now";
  if (d < 1) return "<1 day";
  if (d < 60) return "~" + Math.round(d) + " days";
  if (d < 730) return "~" + Math.round(d / 30.4375) + " mo";
  if (d >= MAX_REPLACEMENT_DAYS) return "> 10 yr";
  return "~" + Math.round(d / 365.25) + " yr";
}
function replacementEstimate(bh) {
  if (!bh) return null;
  const r = bh.replacement;
  if (r && typeof r.text === "string") {
    if (r.days == null && r.text === "unknown") return null;
    return { days: r.days, text: r.text, source: r.source, capped: !!r.capped };
  }
  let days = numOrNull(bh.replacementDaysRemaining);
  let source = days == null ? null : "trend";
  let capped = false;
  if (bh.ageYears != null && bh.expectedLifeYears) {
    const ageDays = Math.max(0, bh.expectedLifeYears - bh.ageYears) * 365.25;
    if (days == null || days > ageDays) {
      capped = days != null;
      days = ageDays; source = "age";
    }
  }
  if (days == null) return null;
  days = Math.min(days, MAX_REPLACEMENT_DAYS);
  return { days, text: formatReplacementEta(days), source, capped };
}

// Build the v6.1 battery-health rows shared by the detail modal and the Battery
// tab. "unknown" is shown honestly rather than a fake high score, and the
// per-term breakdown explains WHY the score is what it is. ``includeScore`` is
// false on the Battery tab, where the card's header badge already shows it.
function batteryHealthRows(bh, opts) {
  const includeScore = !(opts && opts.includeScore === false);
  const rows = [];
  if (includeScore) {
    rows.push(hintedRow("Score",
      bh.score != null ? Math.round(bh.score) + "/100" : "unknown",
      "A weighted average of the available terms below. Terms without enough "
      + "data are left out (never counted as full marks)."));
  }
  if (bh.confidence != null) {
    rows.push(hintedRow("Confidence", Math.round(bh.confidence * 100) + "%",
      "How much of the scoring weight had data behind it. Lower means the score "
      + "rests on fewer terms."));
  }
  const repl = replacementEstimate(bh);
  if (repl) {
    const tip = repl.source === "age"
      ? "Estimated from the battery's age and its expected service life"
        + (repl.capped ? " (the score trend alone pointed further out)." : ".")
      : "Projected from the health-score trend toward the replacement threshold.";
    rows.push(el("div", { class: "row" }, [
      el("span", { class: "label-tip" }, [el("span", { text: "Replace in" }), helpHint(tip)]),
      el("b", { class: repl.days != null && repl.days <= 90 ? "crit"
        : repl.days != null && repl.days <= 365 ? "warn" : "", text: repl.text }),
    ]));
  }
  // Per-term breakdown: each sub-score (0-100) or n/a when that term has no data.
  // NOTE: self_test is deliberately NOT a meter here — it's shown once as its
  // actual "Passed/Failed · date" result (Battery tab row + detail modal
  // section). A 0-100 self-test bar duplicated that under the same label.
  const terms = bh.terms || {};
  ["capacity", "runtime", "anomaly", "age"].forEach((k) => {
    if (!(k in terms)) return;
    const v = terms[k];
    // Each factor gets a small 0-100 meter next to its number, so "why is the
    // score what it is" reads at a glance instead of as a column of digits.
    const value = el("span", { class: "term-value" });
    if (v == null) {
      value.appendChild(el("b", { class: "na", text: "n/a" }));
    } else {
      const cls = scoreClass(v);
      const pct = Math.max(0, Math.min(100, v));
      // Width is set via a CSSOM custom property, NOT an inline style attribute:
      // the dashboard's strict CSP (no style-src 'unsafe-inline') blocks the
      // style="" attribute, which previously left every bar at its default full
      // width — so the meters silently lied. CSSOM .style.setProperty is exempt.
      const fill = el("span", { class: "term-meter-fill " + cls });
      fill.style.setProperty("--w", pct + "%");
      value.appendChild(el("span", { class: "term-meter" }, [fill]));
      value.appendChild(el("b", { class: cls, text: String(Math.round(v)) }));
    }
    // Age is the one sub-score that inverts intuition: "0" means OLD (past its
    // expected life), not new. Show the actual age next to it so a low number
    // reads as "worn out", not "brand new / not reported".
    if (k === "age" && bh.ageYears != null) {
      value.appendChild(el("span", { class: "term-age",
        text: "~" + bh.ageYears.toFixed(1) + " yr"
          + (bh.expectedLifeYears ? " / " + bh.expectedLifeYears + " yr" : "") }));
    }
    rows.push(el("div", { class: "row term-row" }, [
      el("span", { class: "label-tip" },
        [el("span", { text: BH_TERM_LABELS[k] }), helpHint(BH_TERM_HELP[k])]),
      value,
    ]));
  });
  return rows;
}

// Build the v6.1 energy rows shared by the detail modal and the Energy tab.
function energyCostConfigured(en) {
  // The server includes the cost fields whenever energy.cost_per_kwh is set —
  // even if the computed value is unknown — so their PRESENCE (not truthiness)
  // tells us cost tracking is on.
  return en && ("todayCost" in en || "monthCost" in en);
}

// The window/estimated/partial context that used to be verbose footnotes is now
// carried by a "?" hint on the relevant value, so the block stays compact.
const ENERGY_HELP = {
  estimated: "Estimated from load × rated power — the UPS doesn't report real "
    + "watts. Set energy.nominal_power for a closer figure.",
  partial: "Some intervals had data gaps, so this is based on the samples "
    + "available so far.",
};

// A key/value row whose label carries a "?" hint (replaces the old footnotes).
function hintedRow(label, value, tipText) {
  const labelNode = tipText
    ? el("span", { class: "label-tip" }, [el("span", { text: label }), helpHint(tipText)])
    : el("span", { text: label });
  const text = (value === undefined || value === null || value === "")
    ? "—" : String(value);
  return el("div", { class: "row" }, [labelNode, el("b", { text })]);
}

function energyRows(en) {
  const rows = [];
  let todayTip = "Window: " + (en.todayLabel || "since midnight") + ".";
  if (en.estimated) todayTip += " " + ENERGY_HELP.estimated;
  if (en.partial) todayTip += " " + ENERGY_HELP.partial;
  rows.push(hintedRow("Today",
    en.todayKwh != null ? en.todayKwh.toFixed(3) + " kWh" : "—", todayTip));
  // Only show the month line once it has data (no value early in the month or on
  // a fresh UPS reads cleaner than a row full of "unknown").
  if (en.monthKwh != null) {
    rows.push(hintedRow("This month", en.monthKwh.toFixed(3) + " kWh",
      "Window: " + (en.monthLabel || "since the 1st") + "."));
  }
  if (en.yearKwh != null) {
    rows.push(hintedRow("This year", en.yearKwh.toFixed(3) + " kWh",
      "Window: " + (en.yearLabel || "since Jan 1") + "."));
  }
  if (energyCostConfigured(en)) {
    // Configured but no kWh yet -> "calculating…", not a blunt "unknown".
    const todayCost = en.todayCostFormatted || "calculating…";
    rows.push(en.costPartial
      ? hintedRow("Today cost", todayCost,
        "Only members with cost_per_kwh configured are included.")
      : detailRow("Today cost", todayCost));
    if (en.monthKwh != null) {
      rows.push(detailRow("Month cost", en.monthCostFormatted || "calculating…"));
    }
    if (en.yearKwh != null) {
      rows.push(detailRow("Year cost", en.yearCostFormatted || "calculating…"));
    }
  }
  return rows;
}

function renderDetail(name) {
  const u = lastUpsRows.find((r) => r.name === name);
  const body = document.getElementById("detail-body");
  const titleEl = document.getElementById("detail-title");
  titleEl.textContent = (u && (u.label || u.name)) || name;
  const mb = monitoringBadge(u);
  if (mb) titleEl.appendChild(mb);
  if (!u) { body.replaceChildren(el("p", { text: "No data for this UPS." })); return; }
  const pq = u.powerQuality || {};
  const sections = [];

  const info = statusInfo(u);
  const live = [
    el("div", { class: "row" }, [el("span", { text: "Status" }), statusBadge(info)]),
    detailRow("NUT flags", info.detail),
    detailRow("Battery", u.batteryCharge != null && u.batteryCharge !== ""
      ? u.batteryCharge + "%" : null),
    detailRow("Runtime", runtimeText(u)),
    detailRow("Load", u.load != null && u.load !== "" ? u.load + "%" : null),
    detailRow("Connection", u.connectionState),
  ];
  // M3: only while on battery, and in words ("7m 0s"), never "0s"/"1205s".
  if (isOnBattery(u)) live.push(detailRow("Time on battery", timeOnBatteryText(u)));
  const age = dataAgeSeconds(u);
  if (age != null) {
    live.push(detailRow("Last reading", (dataIsStale(u) ? "STALE · " : "") + formatAge(age)));
  }
  sections.push(detailSection("Live status", live));

  // H3: what happens next — every enabled trigger with its live value, how
  // close it is, and what firing does for this UPS.
  const outlook = u.triggerOutlook;
  if (outlook && Array.isArray(outlook.triggers)) {
    const tRows = [detailRow("When it fires", actionLabel(u))];
    if (outlook.summary) tRows.push(detailRow("Now", outlook.summary));
    outlook.triggers.filter((t) => t && t.enabled !== false).forEach((t) => {
      const eta = triggerEta(t);
      const cls = t.state === "fired" ? "crit"
        : (t.state === "held" || t.state === "arming") ? "warn" : "";
      tRows.push(el("div", { class: "row" }, [
        el("span", { text: t.label }),
        el("b", { class: cls, text: (t.state === "idle" ? t.condition : (t.text || t.condition))
          + (eta ? " · " + eta : "") }),
      ]));
    });
    sections.push(detailSection("Shutdown triggers", tRows));
  }

  sections.push(detailSection("Power quality", [
    hintedRow("Input voltage", fmtUnit(pq.inputVoltage, "V"),
      "Mains voltage entering the UPS. Eneru classifies brownout (sag) and surge "
      + "against the configured warning band — the shaded thresholds on the Power "
      + "tab — not arbitrary cutoffs."),
    hintedRow("Output voltage", fmtUnit(pq.outputVoltage, "V"),
      "Voltage delivered to the load. On line power the UPS regulates / AVR-"
      + "corrects it toward nominal; during an outage it's inverter output from "
      + "the battery."),
    hintedRow("Battery voltage", fmtUnit(pq.batteryVoltage, "V"),
      "Terminal voltage of the battery string. It sags under load and as charge "
      + "depletes; on line power it floats near the charger's nominal."),
    hintedRow("Input frequency", fmtUnit(pq.inputFrequency, "Hz"),
      "Mains frequency. Nominal is 50 Hz (EU) or 60 Hz (US); sustained excursions "
      + "point to unstable mains or generator power."),
    hintedRow("Output frequency", fmtUnit(pq.outputFrequency, "Hz"),
      "Frequency the UPS delivers. Line-interactive units track the mains on line "
      + "power and synthesize nominal on battery."),
    hintedRow("Temperature", fmtUnit(pq.temperature, "°C"),
      "As reported by the UPS. Many models (including some UniFi UPS firmware) "
      + "report a fixed placeholder such as a constant 25 °C rather than a live "
      + "sensor reading."),
  ]));

  // v6.1 Battery health (score/terms/replacement).
  if (u.batteryHealth) {
    sections.push(detailSection("Battery health", batteryHealthRows(u.batteryHealth)));
  }
  // v6.1 Energy (today/month kWh + optional cost; cost hidden when disabled).
  if (u.energy) {
    sections.push(detailSection(
      u.energy.estimated ? "Energy (estimated)" : "Energy",
      energyRows(u.energy)));
  }
  // v6.1 Self-test (latest normalized result).
  const st = u.selfTest;
  if (st) {
    sections.push(detailSection("Self-test", [
      detailRow("Result", st.result ? titleCase(st.result) : "unknown"),
      detailRow("When", selfTestDate(st) || null),
    ]));
  }

  // Configuration (from the shared /api/v1/config snapshot).
  const cfgUps = ((cfgSnapshot && cfgSnapshot.ups) || []).find((c) => c.name === name);
  if (cfgUps) {
    const role = upsRole(u);
    const rows = [
      detailRow("Role", role ? role.label : null),
      detailRow("Remote servers", (cfgUps.remoteServers || []).length),
    ];
    (cfgUps.remoteServers || []).forEach((s, i) =>
      rows.push(detailRow("• server " + (i + 1), s.host || s.name || "configured")));
    if (cfgSnapshot && cfgSnapshot.nutControl) {
      rows.push(detailRow("UPS control", cfgSnapshot.nutControl.enabled ? "enabled" : "disabled"));
    }
    sections.push(detailSection("Configuration", rows));
  }

  // Redundancy group membership.
  const member = lastGroups.filter((g) => (g.upsSources || []).includes(name));
  if (member.length) {
    sections.push(detailSection("Redundancy groups",
      member.map((g) => detailRow(g.name,
        groupHealthyCount(g, lastUpsRows) + " of " + (g.upsSources || []).length
          + " healthy, need " + g.minHealthy + " · " + groupOutlook(g, lastUpsRows).label))));
  }

  // Remote health rows for this source.
  const rh = remoteHealthSnapshot.filter((r) =>
    r.group === name || r.group === u.label || r.group === u.groupId);
  if (rh.length) {
    sections.push(detailSection("Remote health", rh.map((r) => {
      const host = r.server || r.host || "host";
      const healthy = remoteHealthReachable(r);
      const old = healthy && remoteCheckIsOld(r);
      return el("div", { class: "row" }, [
        el("span", { text: host }),
        el("span", { class: "badge " + (old ? "muted" : healthy ? "ok" : "crit"),
          text: healthy ? (old ? "reachable " + relTime(r.last_checked_at) : "reachable")
            : "unreachable" }),
      ]);
    })));
  }

  body.replaceChildren(...sections);
}

// Banner driven by LIVE status (not stale events). v6.2 (H1/M2/M10): the
// wording comes from what is actually happening AND what this UPS's role means.
// ELI5: a smoke alarm that knows which room it is in. Smoke in the shed you
// only watch (a monitoring-only UPS) gets a calm note; smoke in the kitchen
// that powers this host gets the siren.
// Pure: returns {severity, text, short, progress, more} or null.
function bannerModel(rows, groups) {
  const cands = [];
  const add = (prio, severity, text, short, progress) =>
    cands.push({ prio, severity, text, short, progress: !!progress });
  (groups || []).forEach((g) => {
    const out = groupOutlook(g, rows || []);
    const name = "redundancy group " + g.name;
    const act = out.action ? " (" + out.action + ")" : "";
    if (out.state === "shutting-down") {
      add(100, "crit", "Shutdown in progress — " + name + act, "Shutting down · " + g.name, true);
    } else if (out.state === "quorum-lost") {
      add(90, "crit", "Quorum lost — " + name + ": group shutdown runs" + act,
        "Quorum lost · " + g.name);
    } else if (out.state === "at-risk" && groupFailingMembers(g, rows || []).length) {
      add(40, "warn", "Redundancy at risk — " + name + ": " + out.label,
        "At risk · " + g.name);
    }
  });
  (rows || []).forEach((u) => {
    const info = statusInfo(u);
    const role = upsRole(u) || {};
    const name = u.label || u.name;
    // The group decides (F-184): a redundancy member never gets the "this
    // UPS shuts things down" wording, even when its own entry has local
    // resources (hasShutdownActions) — like a single vote, not the verdict.
    const member = role.kind === "redundancy-member";
    const acts = !!role.hasShutdownActions && !member;
    const watched = !acts && !member;
    const tag = watched ? name + " (monitoring only)" : name;
    const charge = numOrNull(u.batteryCharge);
    const pct = charge == null ? "" : " " + Math.round(charge) + "%";
    const next = outlookLine(u);
    const fired = upcomingTriggers(u).find((t) => t.state === "fired");
    const why = fired ? fired.label.toLowerCase() + " (" + (fired.text || fired.condition) + ")"
      : (u.triggerReason || "");
    const noAction = " — no action will be taken here.";
    switch (info.state) {
      case "shutting_down":
        if (acts) add(100, "crit", "Shutdown in progress — " + name, "Shutting down · " + name, true);
        else if (member) {
          add(45, "warn", name + " signals a forced shutdown (FSD) — redundancy group "
            + (role.redundancyGroups || []).join(", ") + " decides", "FSD · " + name);
        } else add(30, "warn", tag + " signals a forced shutdown (FSD)" + noAction, "FSD · " + name);
        break;
      case "trigger_active":
        if (acts) {
          add(80, "crit", "Shutdown triggered — " + name + (why ? ": " + why : "")
            + " → " + actionLabel(u), "Shutdown triggered · " + name, true);
        } else if (member) {
          add(45, "warn", name + " is critical for redundancy group "
            + (role.redundancyGroups || []).join(", ") + (why ? ": " + why : "")
            + " — the group decides", "Critical · " + name);
        } else add(30, "warn", tag + " reached a shutdown condition" + noAction, "Critical · " + name);
        break;
      case "low_battery":
      case "output_off":
        if (acts || member) {
          add(70, acts ? "crit" : "warn", info.label + " — " + name
            + (next ? ". " + next.split(" · ")[0] : ""),
            info.label + " · " + name + pct);
        } else add(30, "warn", tag + (info.state === "low_battery" ? " is on low battery"
          : " has its output off") + noAction,
          info.label + " · " + name + pct);
        break;
      case "connection_lost":
        add(info.severity === "crit" ? 75 : 15, info.severity,
          "Connection lost — " + tag + (info.severity === "crit"
            ? " was on battery" + (acts ? ": failsafe shutdown applies" : "") : ": no fresh readings"),
          "Connection lost · " + name);
        break;
      case "on_battery":
        if (watched) {
          add(20, "warn", "On battery — " + tag + " for " + timeOnBatteryText(u)
            + "; nothing is shut down here.", "On battery · " + name + pct);
        } else {
          // The banner names only the closest trigger; the hero/fleet row list the rest.
          // An arming FAILSAFE (NUT polls failing on battery) outranks a plain
          // on-battery notice: the countdown is seconds, not minutes.
          const arming = (upcomingTriggers(u)[0] || {}).state === "arming";
          add(member ? 35 : arming ? 60 : 50, "warn", "On battery — " + name + " for " + timeOnBatteryText(u)
            + (next ? ". " + next.split(" · ")[0] : ""), "On battery · " + name + pct);
        }
        break;
      case "stale":
        add(10, "warn", "Stale data — " + name + ": last reading "
          + formatAge(dataAgeSeconds(u)), "Stale · " + name);
        break;
      default:
        break;
    }
  });
  if (!cands.length) return null;
  cands.sort((a, b) => b.prio - a.prio);
  return Object.assign({}, cands[0], { more: cands.length - 1 });
}

// Browser tab title (M10): a background tab still shows an outage.
function pageTitle(model, clientStale) {
  let t = "Eneru";
  if (model) t = (model.severity === "crit" ? "⛔ " : "⚠ ") + model.short + " — Eneru";
  return (clientStale ? "(stale) " : "") + t;
}

let _bannerAnnounced = "";
function renderBanner() {
  const banner = document.getElementById("banner");
  const model = bannerModel(lastUpsRows, lastGroups);
  document.title = pageTitle(model, clientDataStale());
  if (!model) {
    banner.hidden = true;
    announceBanner(null);
    return;
  }
  banner.className = "banner " + model.severity;
  const kids = [icon(model.severity === "crit" ? "alert" : "battery"),
    el("span", { class: "banner-text", text: model.text
      + (model.more ? " (+" + model.more + " more)" : "") })];
  // M2: a shutdown in progress links straight to its live progress.
  if (model.progress && activeTab !== "shutdown") {
    const go = el("button", { type: "button", class: "banner-link",
      text: "View shutdown progress →" });
    go.addEventListener("click", () => selectTab("shutdown", { updateHash: true }));
    kids.push(go);
  }
  banner.replaceChildren(...kids);
  banner.hidden = false;
  announceBanner(model);
}

// Screen-reader announcement, separate from the visual banner so the ETA
// ticking down every poll isn't re-read: only the stable headline is spoken,
// assertively (role=alert) for red, politely (role=status) otherwise.
function announceBanner(model) {
  const alertEl = document.getElementById("banner-alert");
  const statusEl = document.getElementById("banner-status");
  if (!alertEl || !statusEl) return;
  const key = model ? model.severity + "|" + model.short : "";
  if (key === _bannerAnnounced) return;
  _bannerAnnounced = key;
  alertEl.textContent = model && model.severity === "crit" ? model.short : "";
  statusEl.textContent = model && model.severity !== "crit" ? model.short
    : (model ? "" : "All clear");
}

// Source-qualified identity: the per-DB `id` is only unique within one UPS, so
// it must be paired with `source`. Falls back to a content key for safety.
function eventKey(e) {
  const id = (e.id !== undefined && e.id !== null) ? e.id
    : (e.ts + "|" + (e.eventType || "") + "|" + (e.detail || ""));
  return (e.source || "") + "|" + id;
}

// F-029: the accumulated list is capped to the NEWEST `eventsCap` rows so a long
// polling session can't grow unbounded. But "Load older" fetches OLDER rows, and
// a fixed cap trimmed to the newest N immediately threw away the very rows the
// operator just paged in — the button looked dead. So the cap starts at a
// baseline and GROWS by one page each explicit "Load older" click (see
// loadOlderEvents); resetEvents() restores the baseline whenever the dataset
// changes (range/filter), keeping passive-poll growth bounded.
const EVENTS_BASE_CAP = 2000;
let eventsCap = EVENTS_BASE_CAP;

// Merge incoming events into the accumulated, de-duplicated list (so polling and
// "Load older" both grow it without repeats), sorted ascending by (ts, id) and
// capped so a long session can't grow unbounded.
function mergeEvents(incoming) {
  const map = new Map();
  for (const e of lastEvents) map.set(eventKey(e), e);
  for (const e of (incoming || [])) map.set(eventKey(e), e);
  lastEvents = Array.from(map.values())
    .sort((a, b) => {
      const as = String(a.source || "");
      const bs = String(b.source || "");
      return (a.ts - b.ts) ||
        (as < bs ? -1 : as > bs ? 1 : 0) ||
        ((a.id || 0) - (b.id || 0));
    });
  if (lastEvents.length > eventsCap) lastEvents = lastEvents.slice(-eventsCap);
  updateEventTypeFilter(lastEvents);
  // The 10s poll merges fresh rows and rebuilds the table; preserve the
  // operator's scroll so a passive refresh doesn't yank the Events tab up to
  // (or past) the filter bar. Intentional filter/range changes call scrollTop()
  // separately, so this does not fight them.
  preserveWindowScroll(applyEventFilters);
}

function eventRangeFrom() {
  const v = document.getElementById("event-range").value;
  if (v === "all") return null;
  return Math.floor(Date.now() / 1000) - parseInt(v, 10);
}

async function loadEvents(beforeEvent, clearSelection = false) {
  let q = "limit=200";
  const from = eventRangeFrom();
  if (from !== null) q += "&from=" + from;
  // Only intentional actions clear the selection; the passive 10s poll passes
  // clearSelection=false so an in-progress selection survives a refresh.
  if (clearSelection) selectedEvents = new Set();
  if (beforeEvent) {
    q += "&before=" + encodeURIComponent(beforeEvent.ts);
    if (beforeEvent.source && beforeEvent.id !== undefined && beforeEvent.id !== null) {
      q += "&beforeSource=" + encodeURIComponent(beforeEvent.source);
      q += "&beforeId=" + encodeURIComponent(beforeEvent.id);
    }
  }
  const res = await api("/api/v1/events?" + q);
  if (res.ok && res.data) mergeEvents(res.data.events);
}

async function loadOlderEvents() {
  const oldest = lastEvents[0];   // ascending sort -> [0] is the oldest shown
  if (!oldest) { await loadEvents(); return; }
  // F-029: grow the newest-rows cap by a page before paging older, so the older
  // rows we're about to fetch survive mergeEvents' slice(-eventsCap) instead of
  // being discarded the instant they arrive. Growth is bounded by operator
  // clicks (one page each) and reset by resetEvents() on a dataset change.
  eventsCap += EVENTS_BASE_CAP;
  await loadEvents(oldest);
}

function resetEvents() {
  lastEvents = [];
  eventsCap = EVENTS_BASE_CAP;   // F-029: new dataset -> back to the baseline cap
  // A range change is a new dataset, so the selection no longer applies.
  loadEvents(undefined, true);
}

function updateEventSourceFilter(upsRows, groups) {
  knownEventSources = [];
  (upsRows || []).forEach((u) => knownEventSources.push({
    value: u.name, label: u.label || u.name,
  }));
  // M8: do NOT offer "redundancy:<name>" as an event source. Redundancy-group
  // power events are written to the text log only -- they never land in any
  // per-UPS stats DB, so /api/v1/events can never return rows for them and the
  // filter would be permanently empty. (`groups` is accepted for signature
  // stability / future use once redundancy events are persisted.)
  void groups;
  const sel = document.getElementById("event-source-filter");
  const prev = sel.value;
  sel.replaceChildren(el("option", { value: "", text: "All sources" }));
  knownEventSources.forEach((source) => {
    sel.appendChild(el("option", { value: source.value, text: source.label }));
  });
  if (knownEventSources.some((s) => s.value === prev)) sel.value = prev;
}

function eventTypeFilterLabels(types) {
  const friendly = types.map((type) => humanEventType(type));
  const counts = new Map();
  friendly.forEach((label) => counts.set(label, (counts.get(label) || 0) + 1));
  return new Map(types.map((type, index) => [
    type,
    counts.get(friendly[index]) > 1
      ? friendly[index] + " (" + type + ")"
      : friendly[index],
  ]));
}

// Rebuild the per-type checkbox list from the loaded events (the Tier dropdown
// is the primary filter; these only narrow within the tier).
function updateEventTypeFilter(rows) {
  const box = document.getElementById("event-type-filter");
  // The Tier dropdown is the primary, window-independent filter; the per-type
  // checkboxes are an OPTIONAL narrowing within the tier and default to none
  // selected (= all types in the tier). Preserve whatever the operator ticked.
  const selected = selectedEventTypes();
  const types = Array.from(new Set((rows || [])
    .map((e) => e.eventType || e.event || "")
    .filter((v) => v))).sort();
  const labels = eventTypeFilterLabels(types);
  box.replaceChildren();
  const kept = new Set();
  types.forEach((type) => {
    const input = el("input", { type: "checkbox", value: type });
    if (selected.has(type)) {
      input.checked = true;
      kept.add(type);
    }
    box.appendChild(el("label", { class: "event-type-option" }, [
      input,
      el("span", { text: labels.get(type) }),
    ]));
  });
  updateEventTypeSummary(kept);
}

function selectedEventTypes() {
  const box = document.getElementById("event-type-filter");
  if (!box) return new Set();
  return new Set(Array.from(
    box.querySelectorAll('input[type="checkbox"]:checked'),
  ).map((input) => input.value));
}

function updateEventTypeSummary(types) {
  const summary = document.getElementById("event-type-summary");
  if (!summary) return;
  const selected = Array.from(types || selectedEventTypes());
  if (selected.length === 0) summary.textContent = "All types";
  else if (selected.length === 1) summary.textContent = humanEventType(selected[0]);
  else summary.textContent = selected.length + " types";
}

function eventMatchesSource(event, source) {
  if (!source) return true;
  return event.ups === source || event.source === source || event.group === source;
}

function eventMatchesDashboardScope(event) {
  const group = scopedGroup();
  if (!group) return true;
  return (group.upsSources || []).some((name) => eventMatchesSource(event, name));
}

// Selected event keys ((source,id)). Preserved across passive polling so an
// in-progress selection survives a 10s refresh; cleared only on intentional
// actions — range change, successful delete, sign-out, and server-side session
// invalidation — so a stale destructive selection cannot linger.
let selectedEvents = new Set();

function visibleEvents() {
  const source = document.getElementById("event-source-filter").value;
  const types = selectedEventTypes();
  const text = document.getElementById("event-text-filter").value.trim().toLowerCase();
  const from = eventRangeFrom();
  const rows = lastEvents.filter((e) => {
    const eventType = e.eventType || e.event || "";
    const detail = (e.detail || e.details || "").toLowerCase();
    const displayed = (humanEventType(eventType) + " "
      + humanEventDetail(e.detail || e.details || "")).toLowerCase();
    return (from === null || e.ts >= from)
      && eventMatchesSource(e, source)
      && eventMatchesDashboardScope(e)
      && eventPassesTier(eventType)              // window-independent tier gate
      && (types.size === 0 || types.has(eventType))  // optional advanced narrowing
      && (!text || detail.includes(text) || displayed.includes(text)
        || eventType.toLowerCase().includes(text));
  });
  if (eventSortDirection === "desc") rows.reverse();
  return rows;
}

function timeSortHeader() {
  const label = eventSortDirection === "asc" ? "Time ↑" : "Time ↓";
  const btn = el("button", {
    id: "event-sort-time",
    type: "button",
    class: "th-sort",
    text: label,
    "aria-label": "Sort events by time, currently "
      + (eventSortDirection === "asc" ? "ascending" : "descending"),
    "aria-pressed": eventSortDirection === "desc" ? "true" : "false",
  });
  btn.addEventListener("click", toggleEventSort);
  return el("th", null, [btn]);
}

function preserveWindowScroll(fn) {
  const scrollX = window.scrollX;
  const scrollY = window.scrollY;
  fn();
  window.scrollTo(scrollX, scrollY);
}

function toggleEventSort(ev) {
  if (ev) ev.preventDefault();
  eventSortDirection = eventSortDirection === "asc" ? "desc" : "asc";
  preserveWindowScroll(applyEventFilters);
}

// Reflect the live, actionable selection on the Delete button. The count is the
// number of currently-visible rows with a real id — exactly what deleteSelected
// will act on — so the label never promises a delete it won't perform. Disabled
// at zero so the button is never a silent no-op.
function updateDeleteButton() {
  const btn = document.getElementById("event-delete");
  if (!token()) { btn.hidden = true; return; }
  btn.hidden = false;
  const n = visibleEvents().filter(
    (e) => selectedEvents.has(eventKey(e)) && e.id !== undefined && e.id !== null).length;
  btn.disabled = n === 0;
  btn.textContent = n ? ("Delete selected (" + n + ")") : "Delete selected";
}

// Human label for the UPS that emitted an event (matches the same fields the
// source filter does). Used by the multi-UPS Source column.
function eventSourceLabel(e) {
  const u = lastUpsRows.find((r) =>
    r.name === e.ups || r.name === e.source || r.name === e.group
    || r.groupId === e.source || r.groupId === e.group);
  return u ? (u.label || u.name) : (e.ups || e.source || e.group || "—");
}

function applyEventFilters() {
  const body = document.querySelector("#events tbody");
  body.replaceChildren();
  const signedIn = !!token();
  // Show a Source column only in a fleet, so a multi-UPS "All sources" view
  // isn't ambiguous. (operator #8)
  const multi = lastUpsRows.length > 1;
  // The selection column + Delete action only exist when signed in; keep the
  // header and empty-state colspan in sync so widths never mismatch.
  document.getElementById("events-head").replaceChildren(...[
    ...(signedIn ? [el("th", { text: "" })] : []),
    timeSortHeader(),
    ...(multi ? [el("th", { text: "Source" })] : []),
    el("th", { text: "Type" }),
    el("th", { text: "Detail" }),
  ]);
  updateDeleteButton();
  const rows = visibleEvents();
  const colspan = String(3 + (signedIn ? 1 : 0) + (multi ? 1 : 0));
  if (rows.length === 0) {
    // Contextual empty state — distinguish "genuinely nothing" from "filtered
    // out" so the operator knows whether to widen the filters. (heuristic M6)
    const rangeSel = document.getElementById("event-range");
    const rangeTxt = rangeSel ? rangeSel.options[rangeSel.selectedIndex].text.toLowerCase() : "range";
    const filtered = document.getElementById("event-source-filter").value
      || document.getElementById("event-text-filter").value.trim()
      || document.getElementById("event-tier").value !== "power";
    const msg = filtered
      ? "No matching events — try a wider range or tier."
      : "No power events in the " + rangeTxt + ".";
    body.appendChild(el("tr", null, [el("td", { colspan, text: msg })]));
    return;
  }
  rows.forEach((e) => {
    const ts = e.ts ? new Date(e.ts * 1000).toLocaleString() : "—";
    const cells = [];
    if (signedIn) {
      const cb = el("input", { type: "checkbox" });
      cb.checked = selectedEvents.has(eventKey(e));
      cb.addEventListener("change", () => {
        if (cb.checked) selectedEvents.add(eventKey(e));
        else selectedEvents.delete(eventKey(e));
        updateDeleteButton();
      });
      const td = el("td"); td.appendChild(cb); cells.push(td);
    }
    cells.push(el("td", { text: ts }));
    if (multi) cells.push(el("td", { class: "ev-src", text: eventSourceLabel(e) }));
    cells.push(
      el("td", null, [eventTypeBadge(e)]),
      el("td", { text: humanEventDetail(e.detail || e.details) }),
    );
    body.appendChild(el("tr", null, cells));
  });
}

async function deleteSelected() {
  // Only visible + selected rows with a real id are deletable — a filtered-out
  // selection is never touched.
  const chosen = visibleEvents().filter(
    (e) => selectedEvents.has(eventKey(e)) && e.id !== undefined && e.id !== null);
  if (chosen.length === 0) return;
  // Deleting event history is irreversible — confirm first. (heuristic M7)
  if (!window.confirm("Delete " + chosen.length + " selected event"
      + (chosen.length === 1 ? "" : "s") + "? This can't be undone.")) return;
  // Group the chosen events by UPS name (the DELETE path is
  // /api/v1/ups/{name}/events). Every event carries BOTH a raw `ups`
  // (group.ups.name) and a sanitized `source` (the groupId that eventKey uses
  // for identity); see status.query_events. The server resolves the path name
  // via _resolve_ups_name -> find_status, which matches the raw name OR its
  // sanitized form, so grouping by the raw `ups` reaches the same UPS that the
  // source-keyed identity refers to. Two encodings of one UPS, not a mismatch.
  const byUps = new Map();
  for (const e of chosen) {
    if (!byUps.has(e.ups)) byUps.set(e.ups, []);
    byUps.get(e.ups).push(e);
  }
  // Prune ONLY rows the server actually deleted: a failed/forbidden request
  // must not make the row vanish from the UI.
  const gone = new Set();
  let failed = 0;
  for (const [ups, evs] of byUps) {
    const items = evs.map((e) => ({ id: e.id, ts: e.ts, eventType: e.eventType || e.event }));
    const res = await api("/api/v1/ups/" + encodeURIComponent(ups) + "/events",
      { method: "DELETE", body: JSON.stringify({ items }) });
    const deleted = res.ok && res.data ? Number(res.data.deleted) : 0;
    if (res.ok && deleted === items.length) {
      evs.forEach((e) => gone.add(eventKey(e)));
    } else {
      failed += evs.length;
    }
  }
  if (gone.size) lastEvents = lastEvents.filter((e) => !gone.has(eventKey(e)));
  selectedEvents = new Set();
  showError(failed ? ("Could not delete " + failed + " event(s).") : "");
  applyEventFilters();
}

// ----- charts (v6.1) -------------------------------------------------------
// A reusable SVG plotter. Each chart instance owns its DOM hosts + cached
// series, so the Power / Battery / Energy tabs draw independently. Optional
// voltage threshold bands and power-event overlays layer on top of the line.

// Marker color class by event type, for the chart overlays. Recovery events are
// green, outage/danger red, warnings amber, everything else a distinct violet
// (NOT the blue of the plot line, so a marker never blends into the curve).
function eventMarkerClass(type) {
  const t = (type || "").toUpperCase();
  // L3: a self-test on battery is an expected, operator-started test, not an
  // outage — neutral info (its outcome still turns the badge red on failure).
  if (t === "SELF_TEST_ON_BATTERY") return "ev-info";
  if (t.includes("RESTORED") || t.includes("NORMALIZED")
      || t.includes("RESOLVED") || t.includes("RECOVER")
      || t.includes("INACTIVE")) return "ev-ok";  // bypass/AVR left = good news
  if (t.includes("SHUTDOWN") || t.includes("FSD") || t.includes("ON_BATTERY")
      || t.includes("BROWNOUT") || t.includes("BATTERY_LOW")
      || t.includes("CONNECTION_LOST") || t.includes("CRITICAL")) return "ev-crit";
  if (t.includes("OVER_VOLTAGE") || t.includes("OVERLOAD") || t.includes("BYPASS")
      || t.includes("AVR") || t.includes("WARNING") || t.includes("ANOMALY")
      || t.includes("REPLACE")) return "ev-warn";
  return "ev-info";
}

// Events-table Type cell: a colored, icon-led badge whose severity matches the
// chart marker color, so a marker and its row read the same at a glance.
function eventTypeBadge(e) {
  const type = e.eventType || e.event || "";
  let cls = eventMarkerClass(type);
  // Fold a command / self-test OUTCOME into the tone so "… -> failed" isn't a
  // neutral bell identical to "… -> ok" (self-test is a KPI + battery-card row).
  const detail = (e.detail || e.details || "").toLowerCase();
  const m = detail.match(/(?:->|→)\s*([a-z]+)\b/);
  if (m && ["failed", "error", "timeout"].includes(m[1])) cls = "ev-crit";
  else if (/\bfailed\b/.test(detail)) cls = "ev-crit";
  else if (cls === "ev-info" && m && ["ok", "passed", "done", "success"].includes(m[1])) cls = "ev-ok";
  const tone = { "ev-ok": "ok", "ev-warn": "warn", "ev-crit": "crit" }[cls] || "info";
  const ico = { "ev-ok": "check", "ev-warn": "alert", "ev-crit": "alert" }[cls] || "bell";
  return el("span", { class: "ev-badge " + tone },
    [icon(ico), el("span", { text: humanEventType(type) })]);
}

// Event tiers (mirror the TUI's Power / Diagnostics / Lifecycle split):
//   power  = the events an operator actually cares about on a chart or in the
//            default events view (outages, voltage excursions, battery alerts).
//   lifecycle = routine daemon start/stop/upgrade/recover rows.
//   diag   = everything else (AVR cycling, suppressed flaps, slow-NUT, etc.).
// Substring patterns match the emitted event-type names. NOTE: the emitted name
// is BATTERY_LOW (not LOW_BATTERY) and battery-health alerts are BATTERY_HEALTH_*
// — both are power-tier and were previously missed.
const TIER1_EVENT_PATTERNS = [
  "ON_BATTERY", "POWER_RESTORED", "BATTERY_LOW", "SHUTDOWN", "FSD",
  "OVER_VOLTAGE", "VOLTAGE_HIGH", "VOLTAGE_LOW", "BROWNOUT",
  "OVERLOAD_ACTIVE", "OVERLOAD_DETECTED", "BYPASS_MODE_ACTIVE",
  "CONNECTION_LOST", "CONNECTION_RESTORED", "REPLACE_BATTERY",
  "BATTERY_REPLACEMENT", "BATTERY_HEALTH", "SELF_TEST", "ANOMALY",
];
const LIFECYCLE_EVENT_PATTERNS = ["DAEMON_"];
function isTier1Event(type) {
  const u = (type || "").toUpperCase();
  return TIER1_EVENT_PATTERNS.some((p) => u.includes(p));
}
function isLifecycleEvent(type) {
  const u = (type || "").toUpperCase();
  return LIFECYCLE_EVENT_PATTERNS.some((p) => u.includes(p));
}
// Which display tier an event belongs to.
function eventTierOf(type) {
  if (isTier1Event(type)) return "power";
  if (isLifecycleEvent(type)) return "lifecycle";
  return "diag";
}
// Current Events-tab tier mode (window-INDEPENDENT): power | diag | all.
function eventTierMode() {
  const sel = document.getElementById("event-tier");
  return (sel && sel.value) || "power";
}
// Does an event pass the selected tier? power -> power only; diag -> power+diag
// (not lifecycle); all -> everything. This is the fix for "widen the window and
// the outage still shows" — it keys off the type, not what's in the window.
function eventPassesTier(type) {
  const mode = eventTierMode();
  if (mode === "all") return true;
  const tier = eventTierOf(type);
  if (mode === "diag") return tier !== "lifecycle";
  return tier === "power";
}

// Human-readable tooltip for a chart event marker.
function eventDescription(e) {
  const type = e.eventType || e.event || "event";
  const when = e.ts ? new Date(e.ts * 1000).toLocaleString() : "";
  const detail = humanEventDetail(e.detail || e.details);
  return humanEventType(type) + (when ? (" @ " + when) : "")
    + (detail ? ("\n" + detail) : "");
}

// The same event as a structured tooltip body (type / time / detail) for the
// instant floating tip.
function eventTipNode(e) {
  const kids = [el("div", { class: "tip-head",
    text: humanEventType(e.eventType || e.event) })];
  if (e.ts) kids.push(el("div", { class: "tip-sub",
    text: new Date(e.ts * 1000).toLocaleString() }));
  const detail = humanEventDetail(e.detail || e.details);
  if (detail) kids.push(el("div", { class: "tip-body", text: detail }));
  return kids;
}

// Append one event marker (vertical guide + dot) wrapped in a focusable <g>,
// plus a wide transparent hit line, so hovering/focusing anywhere along the
// guide shows the tooltip (the bare 3px dot was nearly impossible to hit). The
// tooltip is the instant themed tip (the old native <title> only appeared after
// a ~1s delay and looked like a plain OS tooltip). `e` carries the event; cls is
// the color class.
function appendEventMarker(svg, e, ex, top, bottom) {
  const cls = eventMarkerClass(e.eventType || e.event);
  const x = parseFloat(ex), yTop = parseFloat(top), yBot = parseFloat(bottom);
  const g = document.createElementNS(SVG_NS, "g");
  g.setAttribute("class", "ev-marker");
  g.setAttribute("tabindex", "0");
  g.setAttribute("role", "img");
  g.setAttribute("aria-label", eventDescription(e));
  const mkline = (cssClass) => {
    const l = document.createElementNS(SVG_NS, "line");
    l.setAttribute("x1", x); l.setAttribute("y1", yTop);
    l.setAttribute("x2", x); l.setAttribute("y2", yBot);
    l.setAttribute("class", cssClass);
    l.setAttribute("vector-effect", "non-scaling-stroke");
    g.appendChild(l);
  };
  mkline("ev-hit");                 // wide transparent full-height hover target
  mkline("ev-line " + cls);         // faint guide (CSS brightens on hover)
  // The at-a-glance marker is a small colored triangle sitting ON the time axis,
  // not a bold full-height line — reads as an annotation pin, color-coded by type.
  const tri = document.createElementNS(SVG_NS, "polygon");
  tri.setAttribute("points",
    `${(x - 4).toFixed(1)},${yBot} ${(x + 4).toFixed(1)},${yBot} ${x.toFixed(1)},${(yBot - 7).toFixed(1)}`);
  tri.setAttribute("class", "ev-pin " + cls);
  g.appendChild(tri);
  bindTip(g, () => eventTipNode(e), cls);
  svg.appendChild(g);
}

function isVoltageMetric(metric) {
  return metric === "voltage" || metric === "output_voltage"
      || metric === "battery_voltage";
}

// Human metric name + unit so a bare number axis is identifiable (esp. when the
// metric dropdown changes input vs output voltage, frequency, etc.).
const METRIC_LABELS = {
  charge: "Battery charge (%)",
  runtime: "Runtime",
  load: "Load (%)",
  voltage: "Input voltage (V)",
  output_voltage: "Output voltage (V)",
  frequency: "Input frequency (Hz)",
  output_frequency: "Output frequency (Hz)",
  battery_voltage: "Battery voltage (V)",
  temperature: "Temperature (°C)",
  real_power: "Power (W)",
};
function metricLabel(metric) { return METRIC_LABELS[metric] || metric || ""; }

// Unit suffix for a metric's readout (matches the parenthetical in METRIC_LABELS).
function metricUnit(metric) {
  if (metric === "frequency" || metric === "output_frequency") return " Hz";
  if (/voltage/.test(metric)) return " V";
  if (metric === "load" || metric === "charge") return " %";
  if (metric === "temperature") return " °C";
  if (metric === "real_power") return " W";
  return "";
}

// Format a metric value for the hover readout (runtime is a duration; charge/load
// are whole percents; voltage/frequency keep one decimal).
function formatMetricValue(metric, v) {
  if (metric === "runtime") return formatRuntimeSeconds(v);
  const dp = (metric === "load" || metric === "charge") ? 0 : 1;
  return v.toFixed(dp) + metricUnit(metric);
}

// Minimum visible value-span (in metric units) so a near-constant series renders
// calmly instead of being stretched into noise by auto-scaling. 0 = no floor.
function metricMinSpan(metric) {
  if (metric === "frequency" || metric === "output_frequency") return 2.0;  // Hz
  return 0;
}

// Add a hover crosshair + value readout to a chart. The capture rect is appended
// HERE (early), so it sits BELOW the event markers + outage bands that are drawn
// afterwards — those keep their own tips and the readout only fires over empty
// plot area. The returned crosshair group is non-interactive and must be appended
// LAST by the caller so the highlight dot draws on top of the plotted line.
// `series`: [{ y(v)->py, valueAt(point)->number, fmt(number)->string, label }].
function addChartHover(svg, geom, series) {
  const { x, W, H, pad } = geom;
  const readout = geom.readout;   // persistent top-right value/min/max/time readout
  const base = (series.find((s) => s.pts && s.pts.length) || {}).pts || [];
  const cross = document.createElementNS(SVG_NS, "g");
  cross.setAttribute("class", "crosshair");
  cross.style.display = "none";
  const vline = document.createElementNS(SVG_NS, "line");
  vline.setAttribute("y1", 5); vline.setAttribute("y2", (H - pad).toFixed(1));
  vline.setAttribute("class", "crosshair-line");
  vline.setAttribute("vector-effect", "non-scaling-stroke");
  cross.appendChild(vline);
  const dots = series.map(() => {
    const c = document.createElementNS(SVG_NS, "circle");
    c.setAttribute("r", "3.5"); c.setAttribute("class", "crosshair-dot");
    cross.appendChild(c);
    return c;
  });
  const nearest = (svgX) => {
    let best = null, bestD = Infinity;
    for (const p of base) {
      const d = Math.abs(x(p.ts) - svgX);
      if (d < bestD) { bestD = d; best = p; }
    }
    return best;
  };
  const hit = document.createElementNS(SVG_NS, "rect");
  hit.setAttribute("x", pad); hit.setAttribute("y", 5);
  hit.setAttribute("width", Math.max(0, W - pad - 5).toFixed(1));
  hit.setAttribute("height", Math.max(0, H - pad - 5).toFixed(1));
  hit.setAttribute("class", "chart-hit");
  // Hide the crosshair + floating tip. Used on mouseleave AND on every early
  // exit from move(): a sample with no plottable value (a gap) must clear any
  // readout left pinned by a prior move, not leave it stuck until mouseleave.
  const hideHover = () => {
    cross.style.display = "none"; hideTip();
    if (readout) readout.textContent = readout.getAttribute("data-idle") || "";
  };
  const move = (ev) => {
    if (!base.length) return hideHover();
    const r = svg.getBoundingClientRect();
    if (!r.width) return hideHover();
    const p = nearest((ev.clientX - r.left) * (W / r.width));
    if (!p) return hideHover();
    const cx = x(p.ts);
    vline.setAttribute("x1", cx.toFixed(1)); vline.setAttribute("x2", cx.toFixed(1));
    const valueLines = [];
    series.forEach((s, i) => {
      const v = s.valueAt(p);
      if (typeof v === "number" && !isNaN(v)) {
        dots[i].setAttribute("cx", cx.toFixed(1));
        dots[i].setAttribute("cy", s.y(v).toFixed(1));
        dots[i].style.display = "";
        valueLines.push(el("div", { class: "tip-head",
          text: (series.length > 1 ? s.label + ": " : "") + s.fmt(v) }));
      } else {
        dots[i].style.display = "none";
      }
    });
    if (!valueLines.length) return hideHover();
    // Persistent readout: actual value at this time, plus the min–max of the
    // surrounding bucket for a stats-band chart (the "what was the range here").
    if (readout) {
      const prim = series[0];
      const av = prim.valueAt(p);
      if (typeof av === "number" && !isNaN(av)) {
        let txt = prim.fmt(av);
        if (geom.band && base.length > 2) {
          const spanS = base[base.length - 1].ts - base[0].ts;
          const halfW = Math.max(1, (spanS / Math.max(1, W - pad - 5)) * 3);
          let mn = Infinity, mx = -Infinity;
          for (const q of base) {
            if (Math.abs(q.ts - p.ts) > halfW) continue;
            const qv = prim.valueAt(q);
            if (typeof qv === "number" && !isNaN(qv)) { if (qv < mn) mn = qv; if (qv > mx) mx = qv; }
          }
          if (mn !== Infinity && mx > mn) txt += "  ·  ↓" + prim.fmt(mn) + " ↑" + prim.fmt(mx);
        }
        txt += "  ·  " + new Date(p.ts * 1000)
          .toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        readout.textContent = txt;
      }
    }
    cross.style.display = "";
    showTip(valueLines.concat([el("div", { class: "tip-sub",
      text: new Date(p.ts * 1000).toLocaleString() })]),
      ev.clientX, ev.clientY, "ev-info");
  };
  hit.addEventListener("mousemove", move);
  hit.addEventListener("mouseleave", hideHover);
  svg.appendChild(hit);
  return cross;
}

// Draw `series` (a /history payload) into the host element, with optional
// `bands` (voltage thresholds) and `events` (overlay markers).
// ---- shared chart helpers (v6.1.4) ----------------------------------------
// Pad a degenerate (flat) value domain so a constant series (a steady 100%
// charge, a fixed runtime) doesn't collapse onto the bottom axis and read as
// empty. Returns [min, max].
function padFlatDomain(min, max) {
  if (max > min) return [min, max];
  const p = Math.max(1, Math.abs(min) * 0.02);
  return [min - p, max + p];
}

// Gap threshold for breaking a line across missing data: ~3x the median sample
// spacing (so a routine poll hiccup doesn't fragment a dense series, but a real
// outage-length gap breaks the path). Returns Infinity when too few points.
function chartGapThresh(drawn) {
  if (drawn.length <= 2) return Infinity;
  const gaps = [];
  for (let i = 1; i < drawn.length; i++) gaps.push(drawn[i].ts - drawn[i - 1].ts);
  gaps.sort((a, b) => a - b);
  const med = gaps[Math.floor(gaps.length / 2)] || 0;
  return med > 0 ? med * 3 : Infinity;
}

// Min/max decimation: reduce a dense point run to ~2 points per bucket (the
// bucket's min AND max value, in time order) so a 24h/2s series (~19k points,
// an unreadable "barcode") thins to ~1-2 points/pixel while spikes survive.
function decimateMinMax(seg, valueOf, buckets) {
  if (seg.length <= buckets * 2) return seg;
  const out = [], per = seg.length / buckets;
  for (let b = 0; b < buckets; b++) {
    const start = Math.floor(b * per), end = Math.min(seg.length, Math.floor((b + 1) * per));
    if (end <= start) continue;
    let mn = seg[start], mx = seg[start];
    for (let i = start + 1; i < end; i++) {
      if (valueOf(seg[i]) < valueOf(mn)) mn = seg[i];
      if (valueOf(seg[i]) > valueOf(mx)) mx = seg[i];
    }
    const a = mn.ts <= mx.ts ? mn : mx, z = mn.ts <= mx.ts ? mx : mn;
    out.push(a); if (z !== a) out.push(z);
  }
  return out;
}

// Build an SVG path that BREAKS across real gaps and decimates dense segments.
// Splits `drawn` (numeric, ts-sorted) into gap-free segments, decimates each to
// its width share, and starts a new sub-path (M) per segment. Returns {d,hasGap}.
function gapDecimatedPath(drawn, valueOf, x, y, plotWidth) {
  if (!drawn.length) return { d: "", hasGap: false };
  const thresh = chartGapThresh(drawn);
  const segs = []; let seg = [], prev = null;
  drawn.forEach((p) => {
    if (prev !== null && (p.ts - prev) > thresh) { segs.push(seg); seg = []; }
    seg.push(p); prev = p.ts;
  });
  if (seg.length) segs.push(seg);
  const budgetTotal = Math.max(2, Math.floor(plotWidth));
  let d = "";
  segs.forEach((s) => {
    const budget = Math.max(2, Math.round(budgetTotal * s.length / drawn.length));
    const ps = decimateMinMax(s, valueOf, budget);
    ps.forEach((p, i) => {
      d += (d ? " " : "") + (i === 0 ? "M" : "L")
        + x(p.ts).toFixed(1) + " " + y(valueOf(p)).toFixed(1);
    });
  });
  return { d, hasGap: segs.length > 1 };
}

// Home-Assistant-style statistics rendering for a DENSE series: bucket the
// points per-pixel and return a min–max envelope band (bandD) + a mean line
// (meanD), gap-aware (a new sub-path per gap-free segment). For a sparse series
// bandD is empty and meanD is just the raw line. This turns a 24h/2s "barcode"
// into a readable trend with high/low context.
function statsBandPaths(drawn, valueOf, x, y, plotWidth) {
  if (!drawn.length) return { meanD: "", bandD: "", hasGap: false };
  const thresh = chartGapThresh(drawn);
  const segs = []; let seg = [], prev = null;
  drawn.forEach((p) => {
    if (prev !== null && (p.ts - prev) > thresh) { segs.push(seg); seg = []; }
    seg.push(p); prev = p.ts;
  });
  if (seg.length) segs.push(seg);
  const budgetTotal = Math.max(2, Math.floor(plotWidth));
  const dense = drawn.length > budgetTotal * 3;   // ≥3 points/pixel → worth banding
  let meanD = "", bandD = "";
  segs.forEach((s) => {
    const budget = Math.max(2, Math.round(budgetTotal * s.length / drawn.length));
    if (dense && s.length > budget * 2) {
      const buckets = [], per = s.length / budget;
      for (let b = 0; b < budget; b++) {
        const st = Math.floor(b * per), en = Math.min(s.length, Math.floor((b + 1) * per));
        if (en <= st) continue;
        let mn = Infinity, mx = -Infinity, sum = 0;
        for (let i = st; i < en; i++) {
          const v = valueOf(s[i]); if (v < mn) mn = v; if (v > mx) mx = v; sum += v;
        }
        buckets.push({ ts: s[Math.floor((st + en) / 2)].ts, min: mn, max: mx, mean: sum / (en - st) });
      }
      buckets.forEach((bk, i) => {
        meanD += (meanD ? " " : "") + (i === 0 ? "M" : "L")
          + x(bk.ts).toFixed(1) + " " + y(bk.mean).toFixed(1);
      });
      let top = "", bot = "";
      buckets.forEach((bk, i) => {
        top += (i === 0 ? "M" : "L") + x(bk.ts).toFixed(1) + " " + y(bk.max).toFixed(1) + " ";
      });
      for (let i = buckets.length - 1; i >= 0; i--) {
        bot += "L" + x(buckets[i].ts).toFixed(1) + " " + y(buckets[i].min).toFixed(1) + " ";
      }
      if (buckets.length) bandD += top + bot + "Z ";
    } else {
      s.forEach((p, i) => {
        meanD += (meanD ? " " : "") + (i === 0 ? "M" : "L")
          + x(p.ts).toFixed(1) + " " + y(valueOf(p)).toFixed(1);
      });
    }
  });
  return { meanD, bandD: bandD.trim(), hasGap: segs.length > 1 };
}

// X-axis time ticks: count scales with width; times snap to round steps; the
// date is shown for day+ steps and at local-midnight boundaries within a
// sub-day window that crosses midnight. Appended to `svg`.
function drawTimeTicks(svg, t0, t1, x, W, H, bottomPad, leftPad) {
  const spanS = Math.max(1, t1 - t0);
  const target = Math.max(2, Math.min(8, Math.floor((W - leftPad - 5) / 90)));
  const STEPS = [60, 120, 300, 600, 900, 1800, 3600, 7200, 10800, 21600, 43200,
                 86400, 172800, 604800, 1209600, 2592000];
  let step = STEPS[STEPS.length - 1];
  for (const s of STEPS) { if (spanS / s <= target) { step = s; break; } }
  const crosses = new Date(t0 * 1000).toDateString() !== new Date(t1 * 1000).toDateString();
  const yy = (H - bottomPad + 15).toFixed(1);
  const fmt = (ts) => {
    const dt = new Date(ts * 1000);
    if (step >= 86400) return dt.toLocaleDateString([], { month: "short", day: "numeric" });
    if (crosses && dt.getHours() === 0 && dt.getMinutes() === 0) {
      return dt.toLocaleDateString([], { month: "short", day: "numeric" });
    }
    return dt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };
  for (let ts = Math.ceil(t0 / step) * step; ts <= t1; ts += step) {
    const tx = x(ts);
    if (tx < leftPad - 1 || tx > W - 4) continue;
    const label = fmt(ts);
    // L5: a centred label near the right edge was clipped ("11:00 I"). Estimate
    // its half-width (11px text ≈ 6.2px/char) and right-align it instead.
    const half = label.length * 3.1;
    const t = document.createElementNS(SVG_NS, "text");
    const anchor = tx + half > W - 2 ? "end" : "middle";
    t.setAttribute("x", (anchor === "end" ? Math.min(tx + half, W - 2) : tx).toFixed(1));
    t.setAttribute("y", yy);
    t.setAttribute("text-anchor", anchor); t.setAttribute("class", "lbl xtick");
    t.textContent = label; svg.appendChild(t);
  }
}

function drawChart(hostId, series, options) {
  options = options || {};
  const host = document.getElementById(hostId);
  if (!host) return;
  hideTip();  // a redraw detaches any hovered marker without firing mouseleave
  // Size the viewBox to the host's real pixel width so the coordinate system
  // maps 1:1 to screen pixels. When hidden/zero-width the ResizeObserver redraws
  // once it has width.
  const W = host.clientWidth;
  if (!W) return;
  host.replaceChildren();
  const pts = (series && series.data) || [];
  const H = 220, pad = 34, padT = options.metric ? 20 : 8;
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  // Expose the chart to assistive tech as a labelled image (the per-point data
  // is also reachable via the metric selectors + the API). (a11y #8)
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label",
    (options.metric ? metricLabel(options.metric) : "Metric") + " over the selected range");
  const line = (x1, y1, x2, y2, cls) => {
    const l = document.createElementNS(SVG_NS, "line");
    l.setAttribute("x1", x1); l.setAttribute("y1", y1);
    l.setAttribute("x2", x2); l.setAttribute("y2", y2);
    l.setAttribute("class", cls);
    l.setAttribute("vector-effect", "non-scaling-stroke");
    svg.appendChild(l);
  };
  line(pad, H - pad, W - 5, H - pad, "axis");
  line(pad, padT, pad, H - pad, "axis");

  // Metric name + unit, top-centered, so the numbers on the axis are identifiable.
  if (options.metric) {
    const t = document.createElementNS(SVG_NS, "text");
    t.setAttribute("x", (W / 2).toFixed(0)); t.setAttribute("y", "12");
    t.setAttribute("text-anchor", "middle"); t.setAttribute("class", "chart-title");
    // Name the UPS the single-series chart is showing. Fleet mode exposes this
    // same source as an explicit selector above the graph.
    let title = metricLabel(options.metric);
    if (options.upsLabel) {
      title += " · " + options.upsLabel;
    }
    t.textContent = title;
    svg.appendChild(t);
  }

  // Persistent top-right readout — live actual value (+ bucket min/max on a
  // stats-band chart) at the hovered time; idle shows the latest reading.
  const readout = document.createElementNS(SVG_NS, "text");
  readout.setAttribute("x", (W - 5).toFixed(0)); readout.setAttribute("y", "12");
  readout.setAttribute("text-anchor", "end");
  readout.setAttribute("class", "chart-readout");
  svg.appendChild(readout);

  const vals = pts.map((p) => p.value).filter((v) => typeof v === "number" && !isNaN(v));
  const bands = options.bands || null;
  const metric = options.metric;
  const wantBand = bands && isVoltageMetric(metric)
    && (bands.low != null || bands.high != null || bands.nominal != null);

  if (vals.length < 2) {
    const t = document.createElementNS(SVG_NS, "text");
    t.setAttribute("x", W / 2); t.setAttribute("y", H / 2);
    t.setAttribute("text-anchor", "middle"); t.setAttribute("class", "lbl");
    // Distinguish "this UPS never reports this metric" (a monitoring-only UPS
    // with no frequency/output-voltage/temperature) from "still warming up", so
    // a new user doesn't wait for data that will never come.
    t.textContent = options.unavailable
      ? (options.upsLabel || "This UPS") + " doesn't report "
        + metricLabel(options.metric || "").toLowerCase()
      : "Not enough data yet";
    svg.appendChild(t);
    host.appendChild(svg);
    return;
  }

  // Extend the value range to include the band so shaded thresholds are visible
  // even when readings sit inside them.
  let min = Math.min(...vals), max = Math.max(...vals);
  if (wantBand) {
    [bands.low, bands.high, bands.nominal].forEach((v) => {
      if (v != null) { min = Math.min(min, v); max = Math.max(max, v); }
    });
  }
  // Floor the visible value range per metric so a near-constant series isn't
  // amplified into noise. Mains frequency is quantized (e.g. 50.0/50.2 Hz steps),
  // so on a short window auto-scaling stretches a 0.2 Hz wobble across the whole
  // height and reads as junk; a 2 Hz floor renders it as a calm line near center.
  const floor = metricMinSpan(metric);
  if (floor && (max - min) < floor) {
    const mid = (min + max) / 2;
    min = mid - floor / 2;
    max = mid + floor / 2;
  }
  // Pad a still-flat domain so a constant series doesn't pin to the axis.
  [min, max] = padFlatDomain(min, max);
  const span = (max - min) || 1;
  // Domain is the REQUESTED window when known (so leading/trailing silence shows
  // as empty space), else the data extent.
  const t0 = (options.from != null) ? options.from : pts[0].ts;
  const t1 = (options.to != null) ? options.to : pts[pts.length - 1].ts;
  const tspan = (t1 - t0) || 1;
  const x = (t) => pad + ((t - t0) / tspan) * (W - pad - 5);
  const y = (v) => (H - pad) - ((v - min) / span) * (H - pad - padT);

  // Horizontal gridlines (quarter divisions) — the single biggest "this is a
  // real chart" cue. Drawn first, behind everything.
  for (let i = 1; i <= 3; i++) {
    const gy = (padT + i * (H - pad - padT) / 4).toFixed(1);
    line(pad, gy, W - 5, gy, "grid");
  }

  // X-axis time ticks (shared helper: width-scaled count, round-time snapping).
  drawTimeTicks(svg, t0, t1, x, W, H, pad, pad);

  // Voltage threshold band: a faint zone bounded by dashed edge lines (reads as
  // thresholds, not a slab of page-tint), plus the nominal center line.
  if (wantBand && bands.low != null && bands.high != null) {
    const yHigh = y(bands.high), yLow = y(bands.low);
    const rect = document.createElementNS(SVG_NS, "rect");
    rect.setAttribute("x", pad); rect.setAttribute("y", yHigh.toFixed(1));
    rect.setAttribute("width", (W - pad - 5).toFixed(1));
    rect.setAttribute("height", Math.max(0, yLow - yHigh).toFixed(1));
    rect.setAttribute("class", "band");
    svg.appendChild(rect);
    line(pad, yHigh.toFixed(1), W - 5, yHigh.toFixed(1), "band-edge");
    line(pad, yLow.toFixed(1), W - 5, yLow.toFixed(1), "band-edge");
  }
  if (wantBand && bands.nominal != null) {
    line(pad, y(bands.nominal).toFixed(1), W - 5, y(bands.nominal).toFixed(1), "band-nominal");
  }

  // Dense series → HA-style min–max band + mean line; sparse → plain line.
  // Computed BEFORE the hover so the crosshair readout can report bucket min/max.
  const drawn = pts.filter((p) => typeof p.value === "number" && !isNaN(p.value));
  const stats = statsBandPaths(drawn, (p) => p.value, x, y, W - pad - 5);
  const d = stats.meanD, hasGap = stats.hasGap;

  // Hover crosshair + value readout. The capture rect is added now, BELOW the
  // outage bands + event markers added next, so those keep their own tooltips
  // and the readout only fires over empty plot area. The crosshair group itself
  // is appended last (on top of the plotted line).
  const crosshair = addChartHover(svg, { x, W, H, pad, readout, band: !!stats.bandD },
    [{ label: metricLabel(metric), pts,
       valueAt: (p) => p.value, y, fmt: (v) => formatMetricValue(metric, v) }]);

  // Outage spans: shade ON_BATTERY -> POWER_RESTORED intervals behind the
  // markers + data line so brief outages stay visible (see appendOutageBands).
  appendOutageBands(svg, options.events || [], x, t0, t1, 5, H - pad);

  // Event overlays: vertical guides at each event timestamp inside the range,
  // colored by type. Cap markers so a dense window doesn't drown the SVG.
  // Markers are tier-1 only — the feed also carries boundary (DAEMON_*) rows
  // for the outage-band math above, which must not render as dots (F-094).
  const events = options.events || [];
  if (events.length) {
    const inRange = events.filter(
      (e) => e.ts >= t0 && e.ts <= t1 && isTier1Event(e.eventType || e.event));
    const MAX = 100;
    const shown = inRange.length > MAX
      ? inRange.filter((_e, i) => i % Math.ceil(inRange.length / MAX) === 0)
      : inRange;
    shown.forEach((e) => {
      appendEventMarker(svg, e, x(e.ts).toFixed(1), 5, (H - pad).toFixed(1));
    });
    if (inRange.length > shown.length) {
      const note = document.createElementNS(SVG_NS, "text");
      note.setAttribute("x", W - 8); note.setAttribute("y", H - pad - 4);
      note.setAttribute("text-anchor", "end"); note.setAttribute("class", "lbl");
      note.textContent = inRange.length + " events (showing " + shown.length + ")";
      svg.appendChild(note);
    }
  }

  // The data line. Break the path across gaps (a run of missing samples longer
  // than ~2.5x the typical spacing) so we don't draw a confident straight line
  // over data we don't have — and a rejected reading reads as a gap, not an
  // invented trend or a plunge to zero.
  if (stats.bandD) {
    const band = document.createElementNS(SVG_NS, "path");
    band.setAttribute("d", stats.bandD); band.setAttribute("class", "plot-band");
    svg.appendChild(band);
  }
  // Subtle gradient area fill under the line (single-series charts without a
  // threshold band) — skipped when the path has gaps, since a single closed fill
  // would span the missing region.
  // Area fill only when the domain baseline is zero — a fill rising from a
  // non-zero minimum (voltage 207, a zoomed 98% charge) implies quantity-from-
  // zero that isn't there. Zero-based metrics keep the fill. (data-viz #11)
  if (!wantBand && d && !hasGap && !stats.bandD && min <= 0.001) {
    const gid = hostId + "-areagrad";
    const defs = document.createElementNS(SVG_NS, "defs");
    const grad = document.createElementNS(SVG_NS, "linearGradient");
    grad.setAttribute("id", gid);
    grad.setAttribute("x1", "0"); grad.setAttribute("y1", "0");
    grad.setAttribute("x2", "0"); grad.setAttribute("y2", "1");
    [["0", "0.22"], ["1", "0"]].forEach(([off, op]) => {
      const s = document.createElementNS(SVG_NS, "stop");
      s.setAttribute("offset", off); s.setAttribute("stop-color", "var(--accent)");
      s.setAttribute("stop-opacity", op); grad.appendChild(s);
    });
    defs.appendChild(grad); svg.appendChild(defs);
    const area = document.createElementNS(SVG_NS, "path");
    const xL = x(drawn[drawn.length - 1].ts).toFixed(1), xF = x(drawn[0].ts).toFixed(1);
    area.setAttribute("d", `${d} L${xL} ${(H - pad).toFixed(1)} L${xF} ${(H - pad).toFixed(1)} Z`);
    area.setAttribute("class", "area"); area.setAttribute("fill", `url(#${gid})`);
    svg.appendChild(area);
  }
  const path = document.createElementNS(SVG_NS, "path");
  path.setAttribute("d", d); path.setAttribute("class", "plot");
  path.setAttribute("vector-effect", "non-scaling-stroke");
  svg.appendChild(path);

  // "Now" marker at the latest reading + min/max axis labels.
  const fmt = (metric === "runtime") ? formatRuntimeSeconds : (v) => v.toFixed(0);
  const lastPt = [...pts].reverse().find(
    (p) => typeof p.value === "number" && !isNaN(p.value));
  if (lastPt) {
    const dot = document.createElementNS(SVG_NS, "circle");
    dot.setAttribute("cx", x(lastPt.ts).toFixed(1));
    dot.setAttribute("cy", y(lastPt.value).toFixed(1));
    dot.setAttribute("r", "3.5"); dot.setAttribute("class", "now-dot");
    svg.appendChild(dot);
    const idle = "now " + formatMetricValue(metric, lastPt.value);
    readout.setAttribute("data-idle", idle); readout.textContent = idle;
  }
  const lab = (txt, yy) => {
    const t = document.createElementNS(SVG_NS, "text");
    t.setAttribute("x", 2); t.setAttribute("y", yy);
    t.setAttribute("class", "lbl"); t.textContent = txt; svg.appendChild(t);
  };
  lab(fmt(max), 12); lab(fmt(min), H - pad);
  svg.appendChild(crosshair);   // drawn last so the highlight dot sits on top
  host.appendChild(svg);
}

const CHART_EVENT_HORIZON = 2592000;   // 30d — widest selectable chart range

// Tier-1 power events for `ups` within [from,to], filtered to this UPS + tier-1
// client-side. NOTE: /api/v1/events applies `limit` BEFORE we filter by source,
// so a wide window on a busy multi-UPS fleet can still let other UPSes' events
// crowd out this one's — full per-UPS server-side filtering is the tracked
// follow-up. To keep that pressure as low as it was before the out-of-window
// hint existed, the markers fetch (below) stays scoped to the SELECTED window.
async function fetchTierEvents(ups, from, to) {
  let eq = "limit=10000";
  if (from !== null) eq += "&from=" + from;
  if (to !== null) eq += "&to=" + to;
  const ev = await api("/api/v1/events?" + eq);
  const rows = (ev.ok && ev.data && ev.data.events) || [];
  return rows.filter(
    (e) => eventMatchesSource(e, ups) && isChartFeedEvent(e.eventType || e.event));
}

// Markers + outage bands come from the SELECTED window only (low cap pressure).
// The "N earlier power events" nudge does a SEPARATE best-effort scan of
// [horizon, from); a saturated cap there only under-reports the hint count, it
// can never drop a marker the operator is actually looking at.
async function loadChartEvents(ups, from, to, range) {
  const events = await fetchTierEvents(ups, from, to);
  if (from === null) return { events, hidden: 0 };
  let hidden = 0;
  if (range !== null && range < CHART_EVENT_HORIZON) {
    const older = await fetchTierEvents(ups, to - CHART_EVENT_HORIZON, from - 1);
    // The nudge says "earlier POWER events" — count tier-1 rows only, not the
    // boundary (DAEMON_*) rows the feed also carries for the band math.
    hidden = older.filter((e) => isTier1Event(e.eventType || e.event)).length;
  }
  return { events, hidden };
}

// Show/clear the "earlier power events outside this range" nudge for a chart.
// `hidden` is already 0 when the widest range is selected (nothing to widen to).
function setEventsHint(noteId, hidden) {
  if (!noteId) return;
  const note = document.getElementById(noteId);
  if (!note) return;
  const n = hidden || 0;
  note.hidden = !n;
  note.textContent = n
    ? ("↞ " + n + " earlier power event" + (n === 1 ? "" : "s")
       + " outside this range — widen to view.")
    : "";
}

function fmtOutageDur(secs) {
  secs = Math.max(0, Math.round(secs));
  if (secs < 60) return secs + "s";
  const m = Math.floor(secs / 60), s = secs % 60;
  if (m < 60) return s ? (m + "m " + s + "s") : (m + "m");
  const h = Math.floor(m / 60), mm = m % 60;
  return mm ? (h + "h " + mm + "m") : (h + "h");
}

// Flat aria-label for an outage band (screen readers / focus).
function outageLabel(head, s) {
  let label = head;
  if (s.cut) label += " · on battery " + new Date(s.cut.ts * 1000).toLocaleString();
  label += s.restore
    ? " · restored " + new Date(s.restore.ts * 1000).toLocaleString()
    : s.endedAtBoundary
      ? " · ended at shutdown " + new Date(s.end * 1000).toLocaleString()
      : " · ongoing or restore outside range";
  return label;
}

// Structured instant-tip body for an outage band (mirrors eventTipNode; the
// dashboard deliberately uses the themed floating tip, not native <title>).
function outageTipNode(head, s) {
  const kids = [el("div", { class: "tip-head", text: head })];
  if (s.cut) {
    kids.push(el("div", { class: "tip-sub",
      text: "On battery: " + new Date(s.cut.ts * 1000).toLocaleString() }));
  }
  kids.push(el("div", { class: s.restore ? "tip-body" : "tip-sub",
    text: s.restore
      ? "Restored: " + new Date(s.restore.ts * 1000).toLocaleString()
      : s.endedAtBoundary
        ? "Ended at shutdown: " + new Date(s.end * 1000).toLocaleString()
        : "Ongoing / restore outside range" }));
  return kids;
}

// Shade each ON_BATTERY -> POWER_RESTORED interval as an "outage" band behind
// the markers + data line. Brief outages are often only a second or two, so the
// cut and restore markers collapse onto the same x-pixel and the later restore
// marker paints over the cut — the outage then looks like it never happened. A
// minimum pixel width keeps instantaneous outages visible. Unpaired ends (a cut
// still open at the right edge, or a restore whose cut predates the window)
// extend to the chart edge so partial outages still read correctly.
const MIN_OUTAGE_PX = 3;

// Boundary events (besides POWER_RESTORED) that also CLOSE an open outage
// band. ELI5: an outage is a red bar we draw from "power died" to "power
// back". Normally the daemon draws the end itself when it sees OB→OL
// (POWER_RESTORED). But a bad outage kills the host: the daemon fires a
// shutdown (EMERGENCY/DELEGATED_SHUTDOWN_INITIATED), the box powers off, and
// on the next boot it starts FRESH (DAEMON_START) already on line — it never
// witnesses OB→OL, so no POWER_RESTORED is ever emitted. Without a fallback
// the red bar would run to "now" forever (perma-red dashboard). The truth is:
// once the daemon shut down or restarted it could no longer observe the
// outage, so the VISIBLE band must end at that boundary, not at "now".
// (v6.1.7 also makes the server stamp a real POWER_RESTORED on power-loss
// recovery; this client guard covers pre-fix history and the general case.)
const OUTAGE_CLOSE_BOUNDARIES = [
  "POWER_RESTORED",
  "DAEMON_RECOVERED",
  "EMERGENCY_SHUTDOWN_INITIATED",
  "DELEGATED_SHUTDOWN_INITIATED",
  "DAEMON_START",
];
function isOutageBoundaryEvent(type) {
  const u = (type || "").toUpperCase();
  return OUTAGE_CLOSE_BOUNDARIES.some((b) => u.includes(b));
}
// What the chart event feed keeps: power (tier-1) events PLUS outage close
// boundaries. The boundaries MUST survive the feed filter or the band math
// below never sees them: an ON_BATTERY whose only closing event is a daemon
// restart (power died → host shut down → fresh boot, the real 2026-07-09
// history) would run the red band to "now" forever (F-094). DAEMON_* rows are
// lifecycle-tier, so a tier-1-only feed strips exactly those boundaries —
// the door that closes the red curtain was installed behind a bouncer that
// turned away the very events meant to close it. Markers re-filter to tier-1
// at draw time, so daemon-start rows never clutter the charts as dots.
function isChartFeedEvent(type) {
  return isTier1Event(type) || isOutageBoundaryEvent(type);
}

// Pure span math (no DOM) so it's unit-testable in a node shim. Turns the raw
// event stream into outage spans: each ON_BATTERY opens a span that closes on
// the first following boundary event. A clean POWER_RESTORED marks the span
// restored; a shutdown/restart boundary closes it as "ended at shutdown"
// (cut set, restore null, but bounded — NOT run to t1). Only a genuinely
// ongoing outage (ON_BATTERY with NO boundary after it) extends to t1.
function computeOutageSpans(events, t0, t1) {
  const evs = (events || [])
    .filter((e) => {
      const t = (e.eventType || e.event || "").toUpperCase();
      return t.includes("ON_BATTERY") || isOutageBoundaryEvent(t);
    })
    .slice()
    .sort((a, b) => a.ts - b.ts);
  const spans = [];
  let openCut = null;
  for (const e of evs) {
    const t = (e.eventType || e.event || "").toUpperCase();
    if (t.includes("ON_BATTERY")) {
      if (openCut === null) openCut = e;          // ignore repeats while open
    } else if (openCut !== null) {                 // a boundary closes the span
      const restored = t.includes("POWER_RESTORED");
      spans.push({ start: openCut.ts, end: e.ts,
                   cut: openCut, restore: restored ? e : null,
                   endedAtBoundary: !restored });
      openCut = null;
    } else if (t.includes("POWER_RESTORED")) {
      // A restore whose opening ON_BATTERY predates the window: draw the
      // band from the chart's left edge so the partial outage still reads.
      // (Only a real restore does this — a bare shutdown/restart boundary
      // with no open cut is not an outage and draws nothing.)
      spans.push({ start: t0, end: e.ts, cut: null, restore: e,
                   endedAtBoundary: false });
    }
    // a shutdown/restart boundary with no open cut is not an outage span
  }
  if (openCut !== null) {
    // No boundary followed — the daemon is still alive and the outage is
    // genuinely ongoing, so run the band to "now".
    spans.push({ start: openCut.ts, end: t1, cut: openCut, restore: null,
                 endedAtBoundary: false });
  }
  return spans;
}

function appendOutageBands(svg, events, x, t0, t1, yTop, yBot) {
  const spans = computeOutageSpans(events, t0, t1);
  if (!spans.length) return;
  const top = parseFloat(yTop), bot = parseFloat(yBot);
  for (const s of spans) {
    if (s.end < t0 || s.start > t1) continue;     // outage entirely off-chart
    const sx = x(Math.max(s.start, t0));
    const ex = x(Math.min(s.end, t1));
    const left = Math.min(sx, ex);
    const width = Math.max(Math.abs(ex - sx), MIN_OUTAGE_PX);
    const rect = document.createElementNS(SVG_NS, "rect");
    rect.setAttribute("x", left.toFixed(1));
    rect.setAttribute("y", top.toFixed(1));
    rect.setAttribute("width", width.toFixed(1));
    rect.setAttribute("height", Math.max(0, bot - top).toFixed(1));
    rect.setAttribute("class", "outage-band");
    rect.setAttribute("tabindex", "0");
    rect.setAttribute("role", "img");
    const head = (s.cut && s.restore)
      ? "Outage · " + fmtOutageDur(s.end - s.start)
      : s.endedAtBoundary
        ? "Outage · ended at shutdown · " + fmtOutageDur(s.end - s.start)
        : "Outage (ongoing or partial)";
    rect.setAttribute("aria-label", outageLabel(head, s));
    bindTip(rect, () => outageTipNode(head, s), "ev-crit");
    svg.appendChild(rect);
  }
}

// Per-instance chart over the /history series. Owns its DOM hosts + caches and
// is driven by the tab controller (load on activate, redraw on resize).
function makeChart(opts) {
  const state = { series: null, events: [], thresholds: null, hiddenEvents: 0,
    eventsKey: null };
  // Generation guard: overlapping load()s (tab switch + 10s poll + control
  // change) must not let a slow earlier response overwrite fresher data — only
  // the most recent load() is allowed to commit its results.
  let gen = 0;

  function metric() {
    if (opts.metricSelId) {
      const sel = document.getElementById(opts.metricSelId);
      if (sel) return sel.value;
    }
    return opts.fixedMetric;
  }
  function upsName() {
    const sel = document.getElementById(opts.upsSelId);
    return sel ? sel.value : "";
  }
  function rangeSeconds() {
    const sel = document.getElementById(opts.rangeSelId);
    const v = sel ? sel.value : "86400";
    return (v === "all") ? null : parseInt(v, 10);
  }

  async function load(loadOpts) {
    // F-022: the history series is (cheaply, range-bounded) refetched every
    // call, but the event markers come from a full-table /api/v1/events scan
    // (limit=10000, up to twice via loadChartEvents). Re-running that on every
    // 10s poll made the dashboard DoS its own daemon during an incident. So
    // refetch events only when asked (genuine tab activation / range / UPS /
    // metric change) or when the (ups,range) cache key changed; the passive
    // poll passes { refetchEvents: false } and reuses the cached markers.
    const refetchEvents = !loadOpts || loadOpts.refetchEvents !== false;
    const host = document.getElementById(opts.hostId);
    if (!host) return;
    const myGen = ++gen;
    const ups = upsName();
    if (!ups) {
      state.series = null; state.events = []; state.hiddenEvents = 0;
      state.eventsKey = null; draw(); return;
    }
    const m = metric();
    let q = "metric=" + encodeURIComponent(m);
    const range = rangeSeconds();
    let from = null, to = null;
    if (range !== null) {
      to = Math.floor(Date.now() / 1000);
      from = to - range;
      q += "&to=" + to + "&from=" + from;
    }
    const res = await api("/api/v1/ups/" + encodeURIComponent(ups) + "/history?" + q);
    if (myGen !== gen) return;   // a newer load() superseded this one
    const series = res.ok ? res.data : null;
    let events = state.events, hidden = state.hiddenEvents;
    if (opts.events) {
      const eventsKey = ups + "|" + (range === null ? "all" : range);
      if (refetchEvents || state.eventsKey !== eventsKey) {
        const r = await loadChartEvents(ups, from, to, range);
        if (myGen !== gen) return;   // a newer load() superseded this one
        events = r.events;
        hidden = r.hidden;
        state.eventsKey = eventsKey;
      }
    }
    state.series = series;
    state.events = events;
    state.hiddenEvents = hidden;
    state.from = from;   // requested window → chart domain (trailing gaps show)
    state.to = to;
    if (opts.bands) {
      const u = lastUpsRows.find((r) => r.name === ups);
      const pq = (u && u.powerQuality) || {};
      state.thresholds = {
        nominal: numOrNull(pq.nominalVoltage),
        low: numOrNull(pq.warningLow),
        high: numOrNull(pq.warningHigh),
      };
    }
    draw();
  }

  function upsLabel() {
    const u = lastUpsRows.find((r) => r.name === upsName());
    return (u && (u.label || u.name)) || "";
  }
  // True when the selected UPS never reports this metric (its live value is
  // empty) — so the empty chart can say "not reported" vs "warming up".
  function metricUnavailable() {
    const field = { voltage: "inputVoltage", output_voltage: "outputVoltage",
      frequency: "inputFrequency", temperature: "temperature" }[metric()];
    if (!field) return false;
    const u = lastUpsRows.find((r) => r.name === upsName());
    return numOrNull(((u && u.powerQuality) || {})[field]) == null;
  }
  function draw() {
    drawChart(opts.hostId, state.series, {
      metric: metric(),
      // Only label the UPS in a fleet; a lone UPS needs no disambiguation.
      upsLabel: lastUpsRows.length > 1 ? upsLabel() : "",
      unavailable: metricUnavailable(),
      from: state.from, to: state.to,
      bands: opts.bands ? state.thresholds : null,
      events: opts.events ? state.events : null,
    });
    if (opts.noteId) {
      const note = document.getElementById(opts.noteId);
      if (note) {
        const th = state.thresholds;
        const showBand = !!opts.bands && isVoltageMetric(metric()) && th
          && (th.low != null || th.high != null);
        note.hidden = !showBand;
        if (showBand) {
          note.textContent =
            "Shaded band = currently configured voltage warning thresholds "
            + "(reference overlay, not per-sample history).";
        }
      }
    }
    setEventsHint(opts.eventsNoteId, state.hiddenEvents);
  }

  function observe() {
    const host = document.getElementById(opts.hostId);
    if (!host) return;
    let pending = false;
    const redraw = () => {
      if (pending) return;
      pending = true;
      requestAnimationFrame(() => { pending = false; draw(); });
    };
    if (typeof ResizeObserver !== "undefined") new ResizeObserver(redraw).observe(host);
    else window.addEventListener("resize", redraw);
  }

  return { load, draw, observe };
}

// Energy chart: a dual-line plot of load% and power (W) over /power, each line
// independently scaled (different units) with a legend, so "what is 17..31?" is
// unambiguous. Watts is realpower when the UPS reports it, else load*nominal.
function drawEnergyChart(hostId, rows, options) {
  options = options || {};
  const host = document.getElementById(hostId);
  if (!host) return;
  hideTip();  // a redraw detaches any hovered marker without firing mouseleave
  const W = host.clientWidth;
  if (!W) return;
  host.replaceChildren();
  const H = 220, pad = 38;
  // Right padding grows to hold a second (Load %) axis when both lines draw.
  let padR = 5;
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  const mkline = (x1, y1, x2, y2, cls) => {
    const l = document.createElementNS(SVG_NS, "line");
    l.setAttribute("x1", x1); l.setAttribute("y1", y1);
    l.setAttribute("x2", x2); l.setAttribute("y2", y2);
    l.setAttribute("class", cls);
    l.setAttribute("vector-effect", "non-scaling-stroke");
    svg.appendChild(l);
  };
  // Title names the UPS the single-series chart shows, matching the explicit
  // chart source selector exposed in fleet mode.
  if (options.upsLabel) {
    const tt = document.createElementNS(SVG_NS, "text");
    tt.setAttribute("x", (W / 2).toFixed(0)); tt.setAttribute("y", "12");
    tt.setAttribute("text-anchor", "middle"); tt.setAttribute("class", "chart-title");
    tt.textContent = "Load & power · " + options.upsLabel;
    svg.appendChild(tt);
  }

  const pts = rows || [];
  const loads = pts.map((p) => p.loadPct).filter((v) => typeof v === "number" && !isNaN(v));
  const watts = pts.map((p) => p.watts).filter((v) => typeof v === "number" && !isNaN(v));
  if (pts.length < 2 || (loads.length < 2 && watts.length < 2)) {
    const t = document.createElementNS(SVG_NS, "text");
    t.setAttribute("x", W / 2); t.setAttribute("y", H / 2);
    t.setAttribute("text-anchor", "middle"); t.setAttribute("class", "lbl");
    t.textContent = "Not enough data yet"; svg.appendChild(t);
    host.appendChild(svg);
    return;
  }
  const t0 = (options.from != null) ? options.from : pts[0].ts;
  const t1 = (options.to != null) ? options.to : pts[pts.length - 1].ts;
  const tspan = (t1 - t0) || 1;
  const x = (t) => pad + ((t - t0) / tspan) * (W - pad - padR);

  function scale(vals, floorZero) {
    if (vals.length < 2) return null;
    let mn = Math.min(...vals), mx = Math.max(...vals);
    if (floorZero) mn = Math.min(mn, 0);
    [mn, mx] = padFlatDomain(mn, mx);
    const span = (mx - mn) || 1;
    return { mn, mx, y: (v) => (H - pad) - ((v - mn) / span) * (H - pad - 5) };
  }
  const loadS = scale(loads, true);
  const wattS = scale(watts, true);
  // When watts is ESTIMATED from load (no real-power sensor) the two lines share
  // an identical shape, so we plot only Power (W); show Load% alongside ONLY when
  // watts is a real measurement (then they genuinely differ).
  const realWatts = pts.some((p) => typeof p.watts === "number" && p.estimated === false);
  const showLoad = !wattS || realWatts;
  // L5: Load % drawn next to Power (W) gets its own right-hand % axis instead
  // of silently borrowing the W scale.
  const dualAxis = !!(wattS && showLoad && loadS);
  if (dualAxis) padR = 40;
  mkline(pad, H - pad, W - padR, H - pad, "axis");
  mkline(pad, 5, pad, H - pad, "axis");
  if (dualAxis) mkline(W - padR, 5, W - padR, H - pad, "axis");
  // Explain the single line when watts are estimated (the Load% line is hidden
  // because it's an identical shape), so it doesn't look like a series vanished.
  const enote = document.getElementById("energy-note");
  if (enote) {
    if (wattS && !realWatts) {
      enote.textContent = "Power is estimated from load × rated power; the Load% "
        + "line (an identical shape) is hidden. Set energy.nominal_power for "
        + "measured watts.";
      enote.hidden = false;
    } else { enote.hidden = true; enote.textContent = ""; }
  }

  // Hover crosshair + readout for whichever line(s) are shown. The capture rect
  // is added now, BELOW the outage bands + event markers added next, so those
  // keep their own tooltips; the crosshair group is appended last (on top).
  const hoverSeries = [];
  if (wattS) hoverSeries.push({ label: "Power", pts, y: wattS.y,
    valueAt: (p) => p.watts, fmt: (v) => v.toFixed(0) + " W" });
  if (showLoad && loadS) hoverSeries.push({ label: "Load", pts, y: loadS.y,
    valueAt: (p) => p.loadPct, fmt: (v) => v.toFixed(0) + " %" });
  // Persistent top-right readout (actual + bucket min/max on the primary series).
  const readout = document.createElementNS(SVG_NS, "text");
  readout.setAttribute("x", (W - 5).toFixed(0)); readout.setAttribute("y", "12");
  readout.setAttribute("text-anchor", "end");
  readout.setAttribute("class", "chart-readout");
  svg.appendChild(readout);
  const dense = pts.length > Math.max(2, W - pad - 5) * 3;
  const lastVal = hoverSeries.length
    ? [...pts].reverse().map((p) => hoverSeries[0].valueAt(p))
        .find((v) => typeof v === "number" && !isNaN(v)) : null;
  if (lastVal != null) {
    const idle = "now " + hoverSeries[0].fmt(lastVal);
    readout.setAttribute("data-idle", idle); readout.textContent = idle;
  }
  const crosshair = addChartHover(svg, { x, W, H, pad, readout, band: dense }, hoverSeries);

  // Outage spans behind the markers (see appendOutageBands).
  appendOutageBands(svg, options.events || [], x, t0, t1, 5, H - pad);
  // tier-1 event markers only — the feed also carries boundary (DAEMON_*)
  // rows for the outage bands above; they must not render as dots (F-094).
  (options.events || [])
    .filter((e) => e.ts >= t0 && e.ts <= t1
                   && isTier1Event(e.eventType || e.event))
    .slice(0, 100)
    .forEach((e) => {
      appendEventMarker(svg, e, x(e.ts).toFixed(1), 5, (H - pad).toFixed(1));
    });

  function plot(key, sc, cls, bandCls) {
    if (!sc) return;
    const drawn = pts.filter((p) => typeof p[key] === "number" && !isNaN(p[key]));
    // Same HA-style stats rendering as the metric charts: a dense series draws a
    // min–max band + mean line (was an unreadable dense spike mass); sparse → line.
    const stats = statsBandPaths(drawn, (p) => p[key], x, sc.y, W - pad - padR);
    if (stats.bandD) {
      const band = document.createElementNS(SVG_NS, "path");
      band.setAttribute("d", stats.bandD); band.setAttribute("class", bandCls);
      svg.appendChild(band);
    }
    if (!stats.meanD) return;
    const path = document.createElementNS(SVG_NS, "path");
    path.setAttribute("d", stats.meanD); path.setAttribute("class", cls);
    path.setAttribute("vector-effect", "non-scaling-stroke");
    svg.appendChild(path);
  }
  drawTimeTicks(svg, t0, t1, x, W, H, pad, pad);   // anchor the window in time
  if (wattS) plot("watts", wattS, "plot plot-watts", "plot-band-watts");
  if (showLoad) plot("loadPct", loadS, "plot plot-load", "plot-band-load");

  // Legend + per-line max labels (each line has its own unit/scale).
  let lx = pad + 4;
  const legend = (label, cls, max, unit) => {
    const sw = document.createElementNS(SVG_NS, "rect");
    sw.setAttribute("x", lx); sw.setAttribute("y", 6);
    sw.setAttribute("width", 10); sw.setAttribute("height", 3);
    sw.setAttribute("class", cls); svg.appendChild(sw);
    const t = document.createElementNS(SVG_NS, "text");
    t.setAttribute("x", lx + 14); t.setAttribute("y", 11);
    t.setAttribute("class", "lbl");
    t.textContent = label;   // the max is on the y-axis; no need to repeat it here
    svg.appendChild(t);
    lx += 70;
  };
  if (wattS) legend("Power", "plot-watts");
  if (showLoad && loadS) legend("Load", "plot-load");
  // Min/max axis numbers for the primary series (watts if present, else load).
  const prim = wattS || loadS;
  if (prim) {
    const unit = wattS ? " W" : " %";
    const lab = (txt, yy) => {
      const t = document.createElementNS(SVG_NS, "text");
      t.setAttribute("x", "2"); t.setAttribute("y", yy);
      t.setAttribute("class", "lbl"); t.textContent = txt; svg.appendChild(t);
    };
    lab(prim.mx.toFixed(0) + unit, 12); lab(prim.mn.toFixed(0) + unit, H - pad);
  }
  if (dualAxis) {
    const rlab = (txt, yy) => {
      const t = document.createElementNS(SVG_NS, "text");
      t.setAttribute("x", (W - 2).toFixed(0)); t.setAttribute("y", yy);
      t.setAttribute("text-anchor", "end");
      t.setAttribute("class", "lbl lbl-load"); t.textContent = txt; svg.appendChild(t);
    };
    rlab(loadS.mx.toFixed(0) + " %", 24); rlab(loadS.mn.toFixed(0) + " %", H - pad);
  }
  svg.appendChild(crosshair);   // drawn last so the highlight dot sits on top
  host.appendChild(svg);
}

// A compact single-series line plot (`[{ts, value}]`) with fixed y-bounds.
// Lighter than drawChart (no metric dropdown / events / threshold bands) — used
// for the battery-health score trend. Host must carry class "graph" so the
// shared chart chrome (grid / plot / area / now-dot / labels) applies.
function drawSimpleSeries(host, pts, opts) {
  opts = opts || {};
  hideTip();
  host.replaceChildren();
  const W = host.clientWidth || 600, H = 220, pad = 30, padR = 12, padT = 18;
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  const t0 = pts[0].ts;
  const tLast = pts[pts.length - 1].ts;
  // Extend the x-axis toward opts.tEnd (e.g. a future replacement date) so a
  // marker beyond the data is visible — but CAP the extension at 2x the data
  // span so a far-off ETA (years out) doesn't crush the real history into a few
  // pixels. A capped-off ETA is shown as an edge annotation by the caller.
  const dataSpan = Math.max(1, tLast - t0);
  const t1 = (opts.tEnd != null && opts.tEnd > tLast)
    ? Math.min(opts.tEnd, tLast + 2 * dataSpan) : tLast;
  const span = Math.max(1, t1 - t0);
  let lo = opts.min != null ? opts.min : Math.min(...pts.map((p) => p.value));
  let hi = opts.max != null ? opts.max : Math.max(...pts.map((p) => p.value));
  if (opts.min == null && opts.max == null) [lo, hi] = padFlatDomain(lo, hi);
  const rng = Math.max(1e-9, hi - lo);
  const x = (ts) => pad + (ts - t0) / span * (W - pad - padR);
  const y = (v) => padT + (1 - (v - lo) / rng) * (H - padT - pad);
  for (let i = 0; i <= 4; i++) {
    const yy = (padT + i / 4 * (H - padT - pad)).toFixed(1);
    const ln = document.createElementNS(SVG_NS, "line");
    ln.setAttribute("x1", pad); ln.setAttribute("x2", W - padR);
    ln.setAttribute("y1", yy); ln.setAttribute("y2", yy);
    ln.setAttribute("class", "grid"); svg.appendChild(ln);
  }
  drawTimeTicks(svg, t0, t1, x, W, H, pad, pad);   // shared time axis
  const txt = (s, xx, yy, cls, anchor) => {
    const t = document.createElementNS(SVG_NS, "text");
    t.setAttribute("x", xx); t.setAttribute("y", yy); t.setAttribute("class", cls);
    if (anchor) t.setAttribute("text-anchor", anchor);
    t.textContent = s; svg.appendChild(t);
  };
  if (opts.title) txt(opts.title, (W / 2).toFixed(0), 11, "chart-title", "middle");
  txt(Math.round(hi) + (opts.unit || ""), 2, padT + 4, "lbl");
  txt(Math.round(lo) + (opts.unit || ""), 2, H - pad, "lbl");
  let d = "";
  pts.forEach((p, i) => {
    d += (i ? " L" : "M") + x(p.ts).toFixed(1) + " " + y(p.value).toFixed(1);
  });
  const area = document.createElementNS(SVG_NS, "path");
  area.setAttribute("d", d + " L" + x(tLast).toFixed(1) + " " + (H - pad).toFixed(1)
    + " L" + x(t0).toFixed(1) + " " + (H - pad).toFixed(1) + " Z");
  area.setAttribute("class", "area bh"); svg.appendChild(area);
  const line = document.createElementNS(SVG_NS, "path");
  line.setAttribute("d", d); line.setAttribute("class", "plot");
  line.setAttribute("vector-effect", "non-scaling-stroke"); svg.appendChild(line);
  const last = pts[pts.length - 1];
  const dot = document.createElementNS(SVG_NS, "circle");
  dot.setAttribute("cx", x(last.ts).toFixed(1));
  dot.setAttribute("cy", y(last.value).toFixed(1));
  dot.setAttribute("r", "3"); dot.setAttribute("class", "now-dot");
  svg.appendChild(dot);
  // Projected trend (dotted) from the last reading toward a future point, e.g.
  // the replacement date at the threshold score. Clipped to the domain.
  if (opts.projection && opts.projection.ts != null) {
    const px = Math.min(t1, Math.max(t0, opts.projection.ts));
    const pl = document.createElementNS(SVG_NS, "line");
    pl.setAttribute("x1", x(last.ts).toFixed(1));
    pl.setAttribute("y1", y(last.value).toFixed(1));
    pl.setAttribute("x2", x(px).toFixed(1));
    pl.setAttribute("y2", y(opts.projection.value).toFixed(1));
    pl.setAttribute("class", opts.projection.cls || "grid");
    pl.setAttribute("vector-effect", "non-scaling-stroke");
    svg.appendChild(pl);
  }
  // Horizontal reference lines (e.g. the replacement threshold score).
  (opts.hlines || []).forEach((h) => {
    if (h.value == null || h.value < lo || h.value > hi) return;
    const yy = y(h.value).toFixed(1);
    const ln = document.createElementNS(SVG_NS, "line");
    ln.setAttribute("x1", pad); ln.setAttribute("x2", W - padR);
    ln.setAttribute("y1", yy); ln.setAttribute("y2", yy);
    ln.setAttribute("class", h.cls || "grid"); svg.appendChild(ln);
  });
  // An event past the axis (e.g. a replacement years out): a right-edge label
  // with an arrow, no projection line (H6).
  if (opts.offChart) {
    txt(opts.offChart.label, W - padR, padT + 4, opts.offChart.cls, "end");
  }
  // Vertical markers (e.g. the projected replacement date), with a label kept
  // inside the plot.
  (opts.vmarkers || []).forEach((m) => {
    if (m.ts == null || m.ts < t0) return;
    // A far-future ETA past the capped x-axis is PINNED to the right edge (its
    // real date is in the label) instead of dropped — otherwise "Replace ~YYYY-MM"
    // silently vanishes exactly when replacement is furthest out.
    const mts = Math.min(m.ts, t1);
    const mx = x(mts);
    const ln = document.createElementNS(SVG_NS, "line");
    ln.setAttribute("x1", mx.toFixed(1)); ln.setAttribute("x2", mx.toFixed(1));
    ln.setAttribute("y1", padT); ln.setAttribute("y2", H - pad);
    ln.setAttribute("class", m.cls || "grid"); svg.appendChild(ln);
    if (m.label) {
      const anchor = mx > W * 0.55 ? "end" : "start";
      txt(m.label, anchor === "end" ? mx - 4 : mx + 4, padT + 4,
          m.lblCls || "lbl", anchor);
    }
  });
  host.appendChild(svg);
}

function makeEnergyChart(opts) {
  const state = { rows: [], events: [], hiddenEvents: 0, eventsKey: null };
  let gen = 0;
  function upsName() {
    const sel = document.getElementById(opts.upsSelId);
    return sel ? sel.value : "";
  }
  function rangeSeconds() {
    const sel = document.getElementById(opts.rangeSelId);
    const v = sel ? sel.value : "86400";
    return (v === "all") ? null : parseInt(v, 10);
  }
  async function load(loadOpts) {
    // F-022: same rule as makeChart — the /power series is refetched every call
    // (range-bounded), but the event markers (full-table /api/v1/events scan)
    // are refetched only on a genuine activation/range/UPS change or a cache-key
    // change; the passive 10s poll passes { refetchEvents: false } and reuses
    // the cached markers so it stops re-scanning every UPS's events each tick.
    const refetchEvents = !loadOpts || loadOpts.refetchEvents !== false;
    const host = document.getElementById(opts.hostId);
    if (!host) return;
    const myGen = ++gen;
    const ups = upsName();
    if (!ups) {
      state.rows = []; state.events = []; state.hiddenEvents = 0;
      state.eventsKey = null; draw(); return;
    }
    let q = "";
    const range = rangeSeconds();
    let from = null, to = null;
    if (range !== null) {
      to = Math.floor(Date.now() / 1000);
      from = to - range;
      q = "?from=" + from + "&to=" + to;
    }
    const res = await api("/api/v1/ups/" + encodeURIComponent(ups) + "/power" + q);
    if (myGen !== gen) return;
    const rows = (res.ok && res.data && res.data.data) || [];
    if (opts.events !== false) {
      const eventsKey = ups + "|" + (range === null ? "all" : range);
      if (refetchEvents || state.eventsKey !== eventsKey) {
        const r = await loadChartEvents(ups, from, to, range);
        if (myGen !== gen) return;   // a newer load() superseded this one
        state.events = r.events;
        state.hiddenEvents = r.hidden;
        state.eventsKey = eventsKey;
      }
    }
    state.rows = rows;
    state.from = from; state.to = to;
    draw();
  }
  function upsLabel() {
    const u = lastUpsRows.find((r) => r.name === upsName());
    return (u && (u.label || u.name)) || "";
  }
  function draw() {
    drawEnergyChart(opts.hostId, state.rows, {
      events: state.events,
      upsLabel: lastUpsRows.length > 1 ? upsLabel() : "",
      from: state.from, to: state.to,
    });
    setEventsHint(opts.eventsNoteId, state.hiddenEvents);
  }
  function observe() {
    const host = document.getElementById(opts.hostId);
    if (!host) return;
    let pending = false;
    const redraw = () => {
      if (pending) return;
      pending = true;
      requestAnimationFrame(() => { pending = false; draw(); });
    };
    if (typeof ResizeObserver !== "undefined") new ResizeObserver(redraw).observe(host);
    else window.addEventListener("resize", redraw);
  }
  return { load, draw, observe };
}

// Chart instances, created in init(). Keyed by the tab they live on.
const charts = {};

// ----- battery-health + energy tab widgets (v6.1) --------------------------

function widgetCard(title, rows, opts) {
  opts = opts || {};
  const head = [];
  // Optional icon chip (same treatment as the Line-quality / Remote-server
  // cards), so every widget card shares one title style.
  if (opts.icon) {
    head.push(el("span", { class: "card-ico" + (opts.iconClass ? " s-" + opts.iconClass : "") },
      [icon(opts.icon)]));
  }
  head.push(el("h3", { text: title }));
  if (opts.badge) head.push(el("span", { class: "badge " + (opts.badgeClass || "ok"),
    text: opts.badge }));
  return el("div", { class: "card" }, [
    el("div", { class: "card-head" }, head),
    ...rows,
  ]);
}

function scoreClass(score) {
  if (score == null) return "warn";        // unknown -> caution, never "ok"
  if (score < 40) return "crit";
  if (score < 70) return "warn";
  return "ok";
}

function renderBatteryHealthTab() {
  const wrap = document.getElementById("battery-health");
  if (!wrap) return;
  wrap.replaceChildren();
  const rows = scopedRows();
  if (!rows.length) {
    wrap.appendChild(el("p", { class: "chart-note", text: "No UPS data yet." }));
    return;
  }
  rows.forEach((u) => {
    const bh = u.batteryHealth;
    const st = u.selfTest;
    if (bh) {
      // Temper the badge on confidence: a 100/100 built on 2 default terms at
      // 60% confidence shouldn't shout green like a fully-measured 100. Below
      // ~0.75 confidence the badge goes neutral and shows the % inline. (heuristic H1)
      const lowConf = bh.confidence != null && bh.confidence < 0.75;
      const scoreTxt = (bh.score != null ? Math.round(bh.score) + "/100" : "unknown")
        + (lowConf ? " · " + Math.round(bh.confidence * 100) + "%" : "");
      const badgeCls = lowConf ? "muted" : scoreClass(bh.score);
      // Header badge carries the score, so the rows omit it (no duplicate).
      const cardRows = batteryHealthRows(bh, { includeScore: false });
      // Only show a self-test row once a test has actually run.
      if (st && st.result) {
        cardRows.push(el("div", { class: "row" }, [
          el("span", { text: "Last self-test" }),
          el("b", { class: { passed: "ok", failed: "crit", running: "warn" }[st.result] || "",
            text: titleCase(st.result) + (selfTestDate(st) ? (" · " + selfTestDate(st)) : "") }),
        ]));
      }
      wrap.appendChild(widgetCard(u.label || u.name, cardRows,
        { badge: scoreTxt, badgeClass: badgeCls,
          icon: "shield", iconClass: badgeCls }));
    } else {
      wrap.appendChild(widgetCard(u.label || u.name,
        [el("p", { class: "chart-note", text: "Battery health not available." })],
        { icon: "shield", iconClass: "warn" }));
    }
  });
  renderBatteryHealthGraph();
}

// Battery-health score trend (v6.1). Sparse rows from the dedicated
// battery_health table (one per update_interval), so a wide default window.
let _bhGraphGen = 0;
async function renderBatteryHealthGraph() {
  const host = document.getElementById("bh-graph");
  if (!host) return;
  const sel = document.getElementById("battery-ups");
  const name = (sel && sel.value) || (lastUpsRows[0] && lastUpsRows[0].name);
  if (!name) { host.replaceChildren(); return; }
  const myGen = ++_bhGraphGen;
  const res = await api("/api/v1/ups/" + encodeURIComponent(name)
    + "/battery-health-history");
  if (myGen !== _bhGraphGen) return;  // a newer call superseded this one
  const data = (res.ok && res.data && res.data.data) || [];
  const repl = (res.ok && res.data && res.data.replacement) || {};
  const pts = data.filter((r) => r.score != null)
    .map((r) => ({ ts: r.ts, value: r.score }));
  const note = document.getElementById("bh-graph-note");
  if (pts.length < 2) {
    host.replaceChildren();
    if (note) {
      note.hidden = false;
      note.textContent = "Health-score trend appears once a couple of readings "
        + "have been recorded (one per battery_health.update_interval).";
    }
    return;
  }
  if (note) note.hidden = true;
  // Adaptive y-floor: a healthy battery's scores cluster near 100, so a fixed
  // 0-100 axis wastes the bottom half. Anchor the floor just below the lower of
  // the threshold and the observed scores (rounded down to a tidy step) so the
  // trend, the threshold, and the projection all use the vertical space.
  const scores = pts.map((p) => p.value);
  let floorRef = Math.min.apply(null, scores);
  if (repl.thresholdScore != null) floorRef = Math.min(floorRef, repl.thresholdScore);
  // Name the UPS in the title, matching the explicit chart source selector.
  const bhU = lastUpsRows.find((r) => r.name === name);
  const bhLabel = bhU ? (bhU.label || bhU.name) : name;
  const title = "Health score"
    + (lastUpsRows.length > 1 ? " · " + bhLabel : "");
  const opts = {
    title, unit: "",
    min: Math.max(0, Math.floor((floorRef - 8) / 5) * 5), max: 100,
  };
  // Mark the replacement threshold (horizontal) and the projected replacement
  // date (vertical, red), extending the x-axis into the future so the date is
  // visible. Battery aging is a years-long trend, hence the full-history window.
  if (repl.thresholdScore != null) {
    opts.hlines = [{ value: repl.thresholdScore, cls: "bh-thresh" }];
  }
  // A pre-6.2 daemon sends an uncapped trend date; bound it the same way the
  // "Replace in" row does so the two never disagree.
  if (repl.etaTs && typeof repl.days !== "number" && bhU) {
    const est = replacementEstimate(bhU.batteryHealth);
    if (est && typeof est.days === "number") {
      const capTs = Date.now() / 1000 + est.days * 86400;
      if (capTs < repl.etaTs) {
        repl.etaTs = capTs; repl.etaSource = est.source;
      }
      repl.days = est.days;
    }
  }
  if (repl.etaTs) {
    // H6: the marker, the label and the "Replace in" row must agree. The
    // x-axis only extends to 2x the data span, so a far-off date is NOT pinned
    // to the edge with a projection drawn to it (that slope read as "months");
    // it becomes an off-chart arrow with the year instead.
    const nowTs = pts[pts.length - 1].ts;
    const days = typeof repl.days === "number" ? repl.days
      : Math.max(0, (repl.etaTs - Date.now() / 1000) / 86400);
    const tone = days > 365 ? "neutral" : days > 90 ? "warn" : "crit";
    const src = repl.etaSource === "age" ? "est" : "proj";
    const d = new Date(repl.etaTs * 1000);
    const ym = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
    const dataSpan = Math.max(1, nowTs - pts[0].ts);
    const offChart = !!repl.beyond || repl.etaTs > nowTs + 2 * dataSpan;
    if (offChart) {
      opts.offChart = { cls: "bh-eta-lbl " + tone,
        label: "Replace → " + (repl.beyond ? "> " : "~") + d.getFullYear() + " (" + src + ")" };
    } else {
      opts.tEnd = repl.etaTs;
      // Dotted projection from the latest reading to the replacement point.
      if (repl.thresholdScore != null) {
        opts.projection = { ts: repl.etaTs, value: repl.thresholdScore, cls: "bh-proj" };
      }
      opts.vmarkers = [{
        ts: repl.etaTs, cls: "bh-eta " + tone, lblCls: "bh-eta-lbl " + tone,
        label: "Replace ~" + ym + " (" + src + ")",
      }];
    }
  }
  drawSimpleSeries(host, pts, opts);
}

function renderEnergyTab() {
  const wrap = document.getElementById("energy-cards");
  if (!wrap) return;
  wrap.replaceChildren();
  const rows = scopedRows();
  if (!rows.length) {
    wrap.appendChild(el("p", { class: "chart-note", text: "No UPS data yet." }));
    return;
  }
  let costConfigured = false;
  const group = scopedGroup();
  const groupEnergy = group && group.telemetry && group.telemetry.energy;
  if (groupEnergy) {
    if (energyCostConfigured(groupEnergy)) costConfigured = true;
    let badge = null;
    if (groupEnergy.partial) badge = "partial";
    else if (groupEnergy.estimated) badge = "estimated";
    wrap.appendChild(widgetCard(group.name + " · group total", energyRows(groupEnergy),
      badge ? { icon: "chart", badge, badgeClass: "muted" } : { icon: "chart" }));
  }
  rows.forEach((u) => {
    const en = u.energy;
    if (en) {
      if (energyCostConfigured(en)) costConfigured = true;
      wrap.appendChild(widgetCard(u.label || u.name, energyRows(en),
        en.estimated
          ? { icon: "chart", badge: "estimated", badgeClass: "muted" }
          : { icon: "chart" }));
    } else {
      wrap.appendChild(widgetCard(u.label || u.name,
        [el("p", { class: "chart-note",
          text: "Energy tracking not available (no samples yet)." })],
        { icon: "chart" }));
    }
  });
  // Only nudge about cost when it isn't already configured — once cost_per_kwh
  // is set the cost rows render (as a value or "unknown"), so the hint would be
  // wrong and confusing.
  if (!costConfigured) {
    wrap.appendChild(el("p", { class: "chart-note",
      text: "Tip: set energy.cost_per_kwh in the config to also track cost." }));
  }
}

// ----- line quality (Power tab) --------------------------------------------
// A glanceable read on incoming mains quality from the live power-quality block:
// is the voltage in tolerance, the frequency near nominal, and are the UPS
// regulation states (AVR / bypass / overload) quiet. Summarized as Good/Fair/Poor.

function nearNominalFreq(hz) {
  if (hz == null) return true;
  return Math.abs(hz - 50) <= 1.5 || Math.abs(hz - 60) <= 1.5;
}

function lineQuality(pq) {
  const inV = numOrNull(pq.inputVoltage);
  const lo = numOrNull(pq.warningLow), hi = numOrNull(pq.warningHigh);
  const banded = inV != null && lo != null && hi != null;
  const vState = String(pq.voltageState || "").toUpperCase();
  // A real fault wins regardless of how sparse the rest of the telemetry is.
  if ((banded && (inV < lo || inV > hi)) || isBinaryActive(pq.overloadState)
      || isBinaryActive(pq.bypassState) || (vState && vState !== "NORMAL")) {
    return { cls: "crit", label: "Poor" };
  }
  // Only "Unknown" when there's truly nothing to judge — no input voltage AND no
  // regulation state. A monitoring-only UPS that reports in-band input voltage
  // and normal regulation states is legitimately "Good", even without frequency
  // / output-voltage telemetry (those rows just don't render). (v6.1.4 review)
  const freq = numOrNull(pq.inputFrequency);
  const anyState = [pq.voltageState, pq.avrState, pq.bypassState, pq.overloadState]
    .some((s) => s != null && s !== "");
  if (inV == null && !anyState) {
    return { cls: "muted", label: "Unknown" };
  }
  const nearEdge = banded && (inV < lo + (hi - lo) * 0.1 || inV > hi - (hi - lo) * 0.1);
  if (isAvrActive(pq.avrState) || nearEdge || !nearNominalFreq(freq)) {
    return { cls: "warn", label: "Fair" };
  }
  return { cls: "ok", label: "Good" };
}

function isBinaryActive(value) {
  return String(value || "").toUpperCase() === "ACTIVE";
}

function isAvrActive(value) {
  return ["ACTIVE", "BOOST", "TRIM"].includes(String(value || "").toUpperCase());
}

// A regulation-state row whose badge is green when quiet (Normal/Inactive) and
// amber when active. AVR's active states are BOOST/TRIM; bypass/overload use
// the binary ACTIVE flag.
function stateRow(label, value) {
  const v = String(value || "").toUpperCase();
  const active = label === "AVR" ? isAvrActive(v) : isBinaryActive(v);
  // Idle/quiet states (Normal / Inactive) read NEUTRAL, not green — green means
  // "active & good", and a wall of green for features that are simply OFF flattens
  // the hierarchy so a real ACTIVE (amber) doesn't stand out. (heuristic M2/M5)
  const cls = active ? "warn" : (v === "NORMAL" || v === "INACTIVE" ? "muted" : "");
  return el("div", { class: "row" }, [el("span", { text: label }),
    el("span", { class: "badge " + cls, text: titleCase(value) })]);
}

// One line-quality card for a UPS. In a multi-UPS fleet the header carries the
// UPS name (so "All UPS" renders a card each); a lone UPS keeps "Line quality".
function lineQualityCard(u) {
  const pq = u && u.powerQuality;
  if (!pq) return null;
  const q = lineQuality(pq);
  const inV = numOrNull(pq.inputVoltage);
  const lo = numOrNull(pq.warningLow), hi = numOrNull(pq.warningHigh);
  const banded = inV != null && lo != null && hi != null;
  const title = lastUpsRows.length > 1 ? (u.label || u.name) : "Line quality";
  const rows = [el("div", { class: "card-head" }, [
    el("span", { class: "card-ico s-" + q.cls }, [icon("gauge")]),
    el("h3", { text: title }),
    el("span", { class: "badge " + q.cls, text: q.label }),
  ])];
  rows.push(el("div", { class: "row" }, [
    el("span", { class: "label-tip" }, [el("span", { text: "Input" }),
      helpHint(banded ? "Acceptable band " + lo + "–" + hi + " V (nominal "
        + (pq.nominalVoltage != null ? pq.nominalVoltage : "—") + " V)."
        : "Incoming mains voltage.")]),
    el("b", { class: banded && (inV < lo || inV > hi) ? "crit" : "ok",
      text: inV != null ? inV + " V" : "—" }),
  ]));
  const outV = fmtUnit(pq.outputVoltage, "V");
  if (outV) rows.push(configKv("Output", outV));
  const freqN = numOrNull(pq.inputFrequency);
  if (freqN != null) {
    rows.push(el("div", { class: "row" }, [el("span", { text: "Frequency" }),
      el("b", { class: nearNominalFreq(freqN) ? "ok" : "warn",
        text: pq.inputFrequency + " Hz" })]));
  }
  [["Voltage", pq.voltageState], ["AVR", pq.avrState], ["Bypass", pq.bypassState],
   ["Overload", pq.overloadState]].forEach(([lab, val]) => {
    if (val != null && val !== "") rows.push(stateRow(lab, val));
  });
  const temp = fmtUnit(pq.temperature, "°C");
  if (temp) rows.push(configKv("Temperature", temp));
  return el("div", { class: "card s-" + q.cls }, rows);
}

function renderLineQuality() {
  const wrap = document.getElementById("line-quality");
  if (!wrap) return;
  wrap.replaceChildren();
  scopedRows().forEach((u) => {
    const card = lineQualityCard(u);
    if (card) wrap.appendChild(card);
  });
}

// ----- config tab ----------------------------------------------------------

function configKv(label, value) {
  return el("div", { class: "row" }, [
    el("span", { text: label }),
    el("b", { text: (value === undefined || value === null || value === "")
      ? "—" : String(value) }),
  ]);
}

// Colored, collapsible JSON tree. Objects/arrays render as <details> so each
// section expands/collapses on its own; leaves are syntax-colored by type.
function jsonValueSpan(v) {
  let cls = "j-num", txt = String(v);
  if (typeof v === "string") { cls = "j-str"; txt = JSON.stringify(v); }
  else if (typeof v === "boolean") cls = "j-bool";
  else if (v === null) { cls = "j-null"; txt = "null"; }
  const s = el("span", { class: cls });
  s.textContent = txt;
  return s;
}

function jsonNode(key, value, topLevel) {
  if (value !== null && typeof value === "object") {
    const isArr = Array.isArray(value);
    const entries = isArr ? value.map((v, i) => [i, v]) : Object.entries(value);
    const det = el("details", { class: "json-node" });
    if (topLevel) det.setAttribute("open", "");   // top level open; sections start collapsed
    const sum = el("summary");
    if (key !== undefined) {
      const k = el("span", { class: "j-key" }); k.textContent = String(key);
      sum.appendChild(k); sum.appendChild(document.createTextNode(" "));
    }
    // Collapsed reads `key {…}`; expanded reads `key {` (the indented left
    // border conveys the grouping) — cleaner than a running item count.
    sum.appendChild(el("span", { class: "j-punct j-open", text: isArr ? "[" : "{" }));
    sum.appendChild(el("span", { class: "j-ellipsis", text: "…" }));
    sum.appendChild(el("span", { class: "j-punct j-close", text: isArr ? "]" : "}" }));
    det.appendChild(sum);
    const kids = el("div", { class: "json-kids" });
    entries.forEach(([k, v]) => kids.appendChild(jsonNode(k, v, false)));
    det.appendChild(kids);
    return det;
  }
  const row = el("div", { class: "json-leaf" });
  if (key !== undefined) {
    const k = el("span", { class: "j-key" }); k.textContent = String(key);
    row.appendChild(k); row.appendChild(document.createTextNode(": "));
  }
  row.appendChild(jsonValueSpan(value));
  return row;
}

let _lastConfigJson = null;
function renderConfigTab() {
  const body = document.getElementById("config-body");
  if (!body) return;
  const cfg = cfgSnapshot;
  if (!cfg) {
    _lastConfigJson = null;
    body.replaceChildren(el("p", { class: "chart-note", text: "Loading…" }));
    return;
  }
  // The 10s poll re-activates this tab; rebuilding the tree every time would
  // collapse every <details> the operator expanded. Rebuild only when the config
  // actually changed (rare — hot reload / sign-in), so expand state is preserved.
  const json = JSON.stringify(cfg);
  if (json === _lastConfigJson && body.childElementCount) return;
  _lastConfigJson = json;
  body.replaceChildren();
  const cards = [];
  (cfg.ups || []).forEach((c) => {
    cards.push(widgetCard(c.label || c.name, [
      configKv("Name", c.name),
      configKv("Triggers local shutdown", c.isLocal ? "yes" : "no — monitoring only"),
      configKv("Remote servers", (c.remoteServers || []).length),
    ], { icon: "battery" }));
  });
  // Only surface what's ON — a list of "disabled" rows is just noise.
  const enabled = [];
  if (cfg.nutControl && cfg.nutControl.enabled) enabled.push("UPS control");
  if (enabled.length) {
    cards.push(widgetCard("Enabled features",
      enabled.map((f) => el("div", { class: "row" },
        [el("span", { text: f }), el("b", { class: "ok", text: "on" })])),
      { icon: "check" }));
  }
  body.appendChild(el("div", { class: "cards" }, cards));

  if (cfg.detail === "sanitized") {
    body.appendChild(el("p", { class: "chart-note",
      text: "Sign in to see the full configuration (secrets are never shown)." }));
  }
  // The (sanitized) config as a colored, collapsible tree — each section
  // expands/collapses on its own.
  body.appendChild(el("h2", { text: "Raw config (JSON)" }));
  body.appendChild(el("div", { class: "json-tree" }, [jsonNode(undefined, cfg, true)]));
}

// ----- control panel (5c) -----

// L15: cache key for the built control panel. The command/variable lists are
// config-static, so rebuilding the panel every poll was pure waste -- 2 extra
// requests per UPS each cycle AND it wiped any half-typed variable value. We
// rebuild only when the auth token or the set of UPS names actually changes.
let _controlBuiltKey = null;
let _controlRenderGen = 0;

async function renderControl(payload) {
  // A View change can start a second render while the first is waiting on NUT
  // allowlist requests. Invalidate the earlier render before doing any work so
  // it can never put controls for the old UPS back into the live panel.
  const myGen = ++_controlRenderGen;
  const sec = document.getElementById("control-section");
  const empty = document.getElementById("control-empty");
  const panel = document.getElementById("control-panel");
  // Control is only meaningful when authenticated and nut_control is enabled.
  const nutEnabled = cfgSnapshot && cfgSnapshot.nutControl &&
    cfgSnapshot.nutControl.enabled;
  // The Control TAB visibility tracks availability too, so it isn't an empty
  // panel for anonymous / read-only users.
  const available = !!token() && !!nutEnabled;
  const tab = document.getElementById("tab-control");
  if (tab) tab.hidden = !available;
  if (!available) {
    // A live reload that disables nut_control (or a token expiry) can leave us
    // sitting on the now-hidden Control tab. Fall back to Overview, mirroring
    // clearAuthState(), so we never strand on a hidden panel.
    if (activeTab === "control") selectTab("overview", { updateHash: true });
    sec.hidden = true;
    if (empty) empty.hidden = false;
    panel.replaceChildren();
    _controlBuiltKey = null;  // rebuild when control becomes available again
    return;
  }
  sec.hidden = false;
  if (empty) empty.hidden = true;
  if (scopedGroup()) {
    panel.replaceChildren(el("p", { class: "chart-note",
      text: "UPS commands are unavailable for a redundancy-group view. Select a UPS to use controls." }));
    _controlBuiltKey = null;
    return;
  }
  const allRows = (payload && payload.ups) || [];
  const rows = rowsForScope(allRows, currentScope());
  // Key on token + UPS set AND the allowlists, so a live config reload that
  // changes allowed commands/variables (without changing token or UPS set)
  // still busts the cache and rebuilds (CodeRabbit). /api/v1/config exposes the
  // allowlists when authenticated.
  const nc = (cfgSnapshot && cfgSnapshot.nutControl) || {};
  const key = JSON.stringify({
    token: token(),
    ups: rows.map((u) => u.name),
    commands: nc.allowedCommands || [],
    variables: nc.allowedVariables || [],
  });
  if (key === _controlBuiltKey) return;  // already built for this token + UPS set + allowlists
  // Remove the old UPS's actionable buttons synchronously. The new panel is
  // assembled off-DOM and becomes interactive only after every request for the
  // currently selected View has completed.
  _controlBuiltKey = null;
  panel.replaceChildren(el("p", { class: "chart-note", text: "Loading controls…" }));
  // Build into a detached fragment and commit the cache key only once EVERY
  // fetch succeeded (cubic P2). Setting the key up-front meant a transient
  // commands/variables fetch failure built an empty panel that then never
  // rebuilt for the rest of the session.
  let builtOk = true;
  const frag = document.createDocumentFragment();
  for (const u of rows) {
    const box = el("div", { class: "control-ups" }, [el("h3", { text: u.label || u.name })]);
    box.appendChild(el("h4", { text: "Commands" }));
    const cmds = el("div", { class: "cmds" });
    const res = await api("/api/v1/ups/" + encodeURIComponent(u.name) + "/commands");
    if (myGen !== _controlRenderGen) return;
    if (!res.ok) builtOk = false;
    ((res.data && res.data.commands) || []).forEach((c) => {
      const btn = el("button", { type: "button", text: c });
      btn.addEventListener("click", () => runCommand(u.name, c));
      cmds.appendChild(btn);
    });
    if (!cmds.childNodes.length) cmds.appendChild(el("span", { class: "who", text: "No allowlisted commands." }));
    box.appendChild(cmds);
    box.appendChild(el("h4", { text: "Variables" }));
    const vres = await renderVariableForms(u.name);
    if (myGen !== _controlRenderGen) return;
    if (!vres.ok) builtOk = false;
    box.appendChild(vres.node);
    // v6.1: self-test trigger (auth-gated; goes through the control allowlist).
    box.appendChild(el("h4", { text: "Self-test" }));
    const stBox = el("div", { class: "cmds" });
    const stBtn = el("button", { type: "button", text: "Run self-test" });
    stBtn.addEventListener("click", () => runSelfTest(u.name, stBtn));
    stBox.appendChild(stBtn);
    box.appendChild(stBox);
    frag.appendChild(box);
  }
  if (myGen !== _controlRenderGen) return;
  panel.replaceChildren(frag);
  _controlBuiltKey = builtOk ? key : null;  // retry next poll if anything failed
}

async function renderVariableForms(ups) {
  const vars = el("div", { class: "vars" });
  const res = await api("/api/v1/ups/" + encodeURIComponent(ups) + "/variables");
  const rows = (res.data && res.data.variables) || [];
  rows.forEach((v) => {
    const name = v.name || v.variable || "";
    if (!name) return;
    const input = el("input", { name: "value", value: v.value || "" });
    const form = el("form", { class: "var-form" }, [
      el("label", null, [
        el("span", { text: name }),
        input,
      ]),
      el("button", { type: "submit", text: "Set" }),
    ]);
    form.addEventListener("submit", (ev) => {
      ev.preventDefault();
      setVariable(ups, name, input.value);
    });
    vars.appendChild(form);
  });
  if (!vars.childNodes.length) {
    vars.appendChild(el("span", { class: "who", text: "No allowlisted variables." }));
  }
  return { node: vars, ok: res.ok };  // ok feeds renderControl's cache-key commit
}

async function runCommand(ups, command) {
  showError("");
  const res = await api("/api/v1/ups/" + encodeURIComponent(ups) + "/command",
    { method: "POST", body: JSON.stringify({ command }) });
  if (!res.ok) showError("Command failed: " + ((res.data && res.data.error && res.data.error.message) || res.status));
  else setStatus("Ran " + command + " on " + ups);
}

async function runSelfTest(ups, btn) {
  // A self-test is a non-idempotent hardware action; disable the button while
  // the POST is in flight so a double-click can't enqueue several tests.
  if (btn && btn.disabled) return;
  if (btn) btn.disabled = true;
  showError("");
  try {
    const res = await api("/api/v1/ups/" + encodeURIComponent(ups) + "/self-test",
      { method: "POST", body: "{}" });
    if (!res.ok) {
      showError("Self-test failed: " +
        ((res.data && res.data.error && res.data.error.message) || res.status));
    } else {
      setStatus("Self-test issued on " + ups);
    }
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function setVariable(ups, variable, value) {
  showError("");
  const res = await api("/api/v1/ups/" + encodeURIComponent(ups) + "/variables/" +
    encodeURIComponent(variable), { method: "PUT", body: JSON.stringify({ value }) });
  if (!res.ok) {
    showError("Variable update failed: " +
      ((res.data && res.data.error && res.data.error.message) || res.status));
  } else {
    setStatus("Set " + variable + " on " + ups);
  }
}

// ----- auth UI -----

function refreshAuthUI() {
  const authed = !!token() && authEnabled;
  // Hide Sign-in when already signed in OR when the server has auth disabled
  // (login would just 404 with "Authentication is disabled").
  document.getElementById("loginBtn").hidden = authed || !authEnabled;
  document.getElementById("logoutBtn").hidden = !authed;
  const who = document.getElementById("who");
  who.hidden = !authed;
  if (authed) who.textContent = "Signed in";
  else who.textContent = "";
}

function clearAuthState() {
  setToken("");
  selectedEvents = new Set();
  _controlBuiltKey = null;
  const control = document.getElementById("control-section");
  if (control) control.hidden = true;
  const panel = document.getElementById("control-panel");
  if (panel) panel.replaceChildren();
  const tab = document.getElementById("tab-control");
  if (tab) tab.hidden = true;
  // If the operator was on the now-hidden Control tab, fall back to Overview
  // (and re-sync the hash so the URL doesn't keep pointing at #control).
  if (activeTab === "control") selectTab("overview", { updateHash: true });
  refreshAuthUI();
  applyEventFilters();
}

// Learn whether auth is enabled server-side. This route stays open even when
// read endpoints require credentials, so the login form remains reachable.
async function loadAuthState() {
  const res = await api("/api/v1/auth/state");
  authEnabled = !!(res.ok && res.data && res.data.enabled);
}

function openLogin() {
  document.getElementById("login-error").hidden = true;
  // F-041: never let a plaintext password linger in the DOM. Clear it on open
  // (in case a previous attempt left it) as well as after every submit.
  document.getElementById("login-pass").value = "";
  document.getElementById("login-modal").hidden = false;
  document.getElementById("login-user").focus();
}
function closeLogin() {
  document.getElementById("login-modal").hidden = true;
  document.getElementById("login-pass").value = "";  // F-041: scrub the field
}

async function doLogin(ev) {
  ev.preventDefault();
  const username = document.getElementById("login-user").value;
  const password = document.getElementById("login-pass").value;
  const res = await api("/api/v1/auth/login",
    { method: "POST", body: JSON.stringify({ username, password }) });
  // F-041: wipe the plaintext password from the DOM immediately after submit,
  // on BOTH success and failure — otherwise it persists in the input for the
  // whole session and is readable by any later script or via devtools.
  document.getElementById("login-pass").value = "";
  if (res.ok && res.data && res.data.token) {
    setToken(res.data.token); closeLogin(); refreshAuthUI(); refresh();
  } else {
    // Surface the server's actual reason (e.g. "Authentication is disabled",
    // "invalid credentials") so a misconfiguration is self-diagnosable.
    const e = document.getElementById("login-error");
    const detail = res.data && res.data.error && res.data.error.message;
    e.textContent = detail ? ("Sign in failed: " + detail) : "Sign in failed.";
    e.hidden = false;
  }
}

async function doLogout() {
  await api("/api/v1/auth/logout", { method: "POST" });
  clearAuthState(); refresh();
}

// ----- tabs (v6.1) ---------------------------------------------------------
// Real ARIA tabs: roving tabindex, arrow-key nav, and URL-hash routing so views
// are linkable. The 10s refresh redraws only the active tab's chart/widgets.

const TAB_IDS = ["overview", "power", "battery", "energy", "control", "shutdown", "events", "config"];
// Tabs whose content is scoped by the global UPS selector. Events (own Source
// filter) and Config (fleet-wide) are intentionally excluded.
const SCOPED_TABS = ["overview", "power", "battery", "energy", "shutdown"];
let activeTab = "overview";

function tabButtons() {
  return TAB_IDS.map((id) => document.getElementById("tab-" + id)).filter(Boolean);
}

function selectTab(name, opts) {
  opts = opts || {};
  const requested = name;
  if (!TAB_IDS.includes(name)) name = "overview";
  let btn = document.getElementById("tab-" + name);
  // A hidden tab (e.g. Control when signed out) is not selectable.
  if (!btn || btn.hidden) { name = "overview"; btn = document.getElementById("tab-overview"); }
  const fellBack = name !== requested;
  activeTab = name;
  TAB_IDS.forEach((id) => {
    const b = document.getElementById("tab-" + id);
    const panel = document.getElementById("panel-" + id);
    const selected = id === name;
    if (b) {
      b.setAttribute("aria-selected", selected ? "true" : "false");
      b.tabIndex = selected ? 0 : -1;
    }
    if (panel) panel.hidden = !selected;
  });
  if (opts.focus && btn) btn.focus();
  // Keep the hash in sync. Poll-driven calls don't pass updateHash, but a
  // FALLBACK (requested a hidden tab, landed on overview) must always re-sync
  // the hash + focus so the URL and focused tab match the visible panel.
  if ((opts.updateHash || fellBack) && ("#" + name) !== location.hash) {
    location.hash = name;
  }
  if (fellBack && btn && document.activeElement
      && document.activeElement.getAttribute
      && document.activeElement.getAttribute("role") === "tab") {
    btn.focus();
  }
  // An explicit (user) switch lands at the top of the freshly-shown panel
  // instead of inheriting the previous tab's scroll position.
  if (opts.updateHash) window.scrollTo(0, 0);
  // On a phone the tab bar scrolls sideways; keep the chosen tab in view.
  if (btn && typeof btn.scrollIntoView === "function") {
    try { btn.scrollIntoView({ block: "nearest", inline: "nearest" }); } catch (_e) { /* old UA */ }
  }
  onTabActivated(name);
  applyScopeChrome();
  // The banner's "View shutdown progress" link hides on the Shutdown tab.
  if (typeof renderBanner === "function" && lastUpsRows.length) renderBanner();
}

// L6: a horizontally scrolling tab bar gets a fade on the side that has more
// tabs, so Events/Config off-screen on a phone are discoverable.
function updateTabOverflow() {
  const list = document.getElementById("tabs");
  if (!list) return;
  const max = list.scrollWidth - list.clientWidth;
  list.classList.toggle("more-right", max > 2 && list.scrollLeft < max - 2);
  list.classList.toggle("more-left", max > 2 && list.scrollLeft > 2);
}

// Draw/refresh whatever the freshly-activated tab needs from the latest data.
// ----- shutdown plan (DAG view) --------------------------------------------
// Render the read-only structured shutdown plan as an ordered flow. Enabled
// phases are prominent; skipped phases are muted with their reason. Parallel
// phases lay their steps out side by side.
// Populate the Shutdown-tab UPS selector from the live UPS list (remote UPSes
// flagged), keeping the current pick. Hidden for a single-UPS deployment. Each
// UPS/group has its own plan, so this is how remote-only + multi-UPS plans
// become reachable. Returns the selected UPS name.
function populateShutdownUpsSelect() {
  const sel = document.getElementById("shutdown-ups");
  const ctl = document.getElementById("shutdown-controls");
  const rows = lastUpsRows;
  if (!sel) return rows[0] && rows[0].name;
  const prev = sel.value;
  const isLocal = {};
  ((cfgSnapshot && cfgSnapshot.ups) || []).forEach((c) => { isLocal[c.name] = c.isLocal; });
  sel.replaceChildren();
  rows.forEach((u) => sel.appendChild(el("option", { value: u.name,
    text: (u.label || u.name) + (isLocal[u.name] === false ? " (remote)" : "") })));
  if (prev && rows.some((u) => u.name === prev)) sel.value = prev;
  if (ctl) ctl.hidden = rows.length <= 1;
  return sel.value || (rows[0] && rows[0].name);
}

// "What triggers this sequence" — a redundancy-group quorum loss (coordinated),
// or a standalone UPS's own low-battery / forced shutdown. Built from the
// redundancy-group data the dashboard already holds (lastGroups).
function shutdownTriggerNodes(target, plan) {
  const groups = target.kind === "redundancy"
    ? lastGroups.filter((g) => g.name === target.name)
    : lastGroups.filter((g) => (g.upsSources || []).includes(target.name));
  const coord = plan && plan.coordinatorMode ? " — coordinator-run" : "";
  // v6.2 (H3c): the daemon lists every configured trigger with its real
  // threshold (charge, runtime, drain rate, time on battery, FSD, failsafe),
  // so the tab no longer claims "low battery or FSD" only.
  const trig = plan && plan.triggers;
  if (trig && Array.isArray(trig.conditions) && trig.conditions.length) {
    const nodes = [];
    const action = trig.action && trig.action.label ? " → " + trig.action.label : "";
    const line = el("div", { class: "sd-trigger" }, [icon("info"),
      el("div", { class: "sd-trigger-body" }, [
        el("span", { text: "Shutdown starts when any of these is true" + coord + ":" }),
        el("ul", { class: "sd-conditions" },
          trig.conditions.map((c) => el("li", { text: c }))),
        Array.isArray(trig.memberConditions) && trig.memberConditions.length
          ? el("span", { class: "sd-trigger-note", text: "A member counts as unhealthy when: "
            + trig.memberConditions.join(" · ") }) : null,
        action ? el("span", { class: "sd-trigger-action", text: action.slice(3) }) : null,
        trig.stabilizationDelay ? el("span", { class: "sd-trigger-note",
          text: "Battery triggers wait " + formatRuntimeSeconds(trig.stabilizationDelay)
            + " after the switch to battery before acting (stabilization)." }) : null,
      ].filter(Boolean)),
      target.kind === "redundancy"
        ? el("span", { class: "badge sd-trigger-live", "data-group": target.name })
        : el("span", { class: "badge sd-trigger-live", "data-ups": target.name }),
    ]);
    nodes.push(line);
    return nodes;
  }
  if (groups.length) {
    return groups.map((g) => el("div", { class: "sd-trigger" }, [
      icon("info"),
      el("span", { text: "Triggers when group “" + g.name + "” drops below "
        + g.minHealthy + " of " + (g.upsSources || []).length + " healthy" + coord }),
      el("span", { class: "badge sd-trigger-live", "data-group": g.name }),
    ]));
  }
  return [el("div", { class: "sd-trigger" }, [icon("info"),
    el("span", { text: "Triggers when this UPS reaches low battery or a forced "
      + "shutdown (FSD)" + coord })])];
}

let _sdGen = 0;
let _sdProgressRefreshing = false;

function shutdownRemoteHealth(target) {
  const groupLabel = target.kind === "redundancy" ? SCOPE_GROUP + target.name : null;
  const ups = target.kind === "ups"
    ? lastUpsRows.find((row) => row.name === target.name) : null;
  const labels = new Set([target.name]);
  if (ups) labels.add(ups.label || ups.name);
  return (remoteHealthSnapshot || []).filter((row) =>
    groupLabel ? row.group === groupLabel : labels.has(row.group));
}

function progressStateClass(state) {
  if (state === "succeeded") return "ok";
  if (state === "running") return "warn";
  if (state === "failed" || state === "timed-out") return "crit";
  return "muted";
}

function progressStateLabel(state) {
  return String(state || "pending").replace(/-/g, " ");
}

// Refresh each trigger line's "now H of N healthy" badge from the latest
// group status, so the operator sees how close the trigger is right now.
function updateTriggerLive(section) {
  section.querySelectorAll(".sd-trigger-live").forEach((badge) => {
    const upsName = badge.getAttribute("data-ups");
    if (upsName) {
      // Live "how close is it" for one UPS: the closest trigger + its ETA.
      const u = lastUpsRows.find((row) => row.name === upsName);
      const list = u ? upcomingTriggers(u) : [];
      if (!u || !list.length) {
        badge.className = "badge sd-trigger-live ok";
        badge.textContent = u && isOnBattery(u) ? "on battery · no trigger close"
          : "now on mains · armed";
        badge.hidden = !u;
        return;
      }
      const first = list[0];
      badge.className = "badge sd-trigger-live " + (first.state === "fired" ? "crit" : "warn");
      badge.textContent = first.state === "fired" ? "met now: " + first.condition
        : "next: " + first.condition + (triggerEta(first) ? " " + triggerEta(first) : "");
      badge.hidden = false;
      return;
    }
    const g = lastGroups.find((item) => item.name === badge.getAttribute("data-group"));
    if (!g) { badge.hidden = true; return; }
    const total = (g.upsSources || []).length;
    const healthy = groupHealthyCount(g, lastUpsRows);
    const cls = groupQuorumLost(g, lastUpsRows) ? "crit"
      : (healthy <= g.minHealthy ? "warn" : "ok");
    badge.className = "badge sd-trigger-live " + cls;
    badge.textContent = "now " + healthy + " of " + total + " healthy";
    badge.hidden = false;
  });
}

function fmtClock(epoch) {
  return epoch ? new Date(epoch * 1000).toLocaleTimeString() : "—";
}

// "started 12:03:04 · finished 12:03:09 · pre-commands 3 run, 1 failed"
function remoteProgressMeta(remote) {
  const parts = [];
  if (remote.startedAt) parts.push("started " + fmtClock(remote.startedAt));
  if (remote.finishedAt) parts.push("finished " + fmtClock(remote.finishedAt));
  const run = remote.preCommandsAttempted || 0;
  const failed = remote.preCommandsFailed || 0;
  if (run || failed) {
    parts.push("pre-commands " + run + " run"
      + (failed ? ", " + failed + " failed" : ", all ok"));
  }
  return parts.join(" · ");
}

function remoteOutputBlock(title, text) {
  return el("div", { class: "detail-section" }, [
    el("h4", { text: title }),
    el("pre", { class: "remote-output", text: text }),
  ]);
}

let remoteReturnFocus = null;
let remoteReturnKey = null;

// Pop-up with one remote's full result: timings, pre-commands, exit code and
// the server's (redacted) response. Raw output is only sent to signed-in users.
function openRemoteDetail(remote, detailAvailable) {
  const modal = document.getElementById("remote-modal");
  const body = document.getElementById("remote-body");
  document.getElementById("remote-title").textContent =
    "Remote shutdown · " + (remote.server || remote.host);
  const detail = remote.detail || null;
  const run = remote.preCommandsAttempted || 0;
  const failed = remote.preCommandsFailed || 0;
  const rows = [
    detailRow("Host", remote.host),
    detailRow("State", progressStateLabel(remote.state)),
    detailRow("Outcome", remote.outcome ? progressStateLabel(remote.outcome) : null),
    detailRow("Started", remote.startedAt ? fmtClock(remote.startedAt) : null),
    detailRow("Finished", remote.finishedAt ? fmtClock(remote.finishedAt) : null),
    detailRow("Pre-commands", (run || failed) ? run + " run, " + failed + " failed" : "none"),
  ];
  if (detail) {
    rows.push(detailRow("Exit code",
      detail.exitCode === null || detail.exitCode === undefined
        ? "not available" : String(detail.exitCode)));
  }
  const children = [detailSection("Result", rows)];
  if (detail) {
    children.push(remoteOutputBlock("Server response",
      detail.response || "(no output)"));
    if (detail.error && detail.error !== detail.response) {
      children.push(remoteOutputBlock("Error", detail.error));
    }
    if (detail.preCommandsError) {
      children.push(remoteOutputBlock("Pre-shutdown commands", detail.preCommandsError));
    }
  } else {
    let note = "No response recorded yet.";
    if (!detailAvailable) {
      note = authEnabled
        ? "Sign in to see the server's response and exit code."
        : "The server's response and exit code are shown only to signed-in "
          + "users. Enable API authentication to see them.";
    }
    if (remote.error) children.push(el("p", { class: "chart-note", text: remote.error }));
    children.push(el("p", { class: "chart-note", text: note }));
    if (!detailAvailable && authEnabled) {
      const signIn = el("button", { type: "button", text: "Sign in" });
      signIn.addEventListener("click", () => { closeRemoteDetail(); openLogin(); });
      children.push(el("div", { class: "modal-actions" }, [signIn]));
    }
  }
  body.replaceChildren(...children);
  remoteReturnKey = { server: remote.server, host: remote.host };
  remoteReturnFocus = document.activeElement;
  modal.hidden = false;
  // Errors usually land at the end of long output; open each block at its tail.
  body.querySelectorAll(".remote-output").forEach((pre) => { pre.scrollTop = pre.scrollHeight; });
  document.getElementById("remote-close").focus();
  trapModalFocus(modal, closeRemoteDetail);
}

function closeRemoteDetail() {
  const modal = document.getElementById("remote-modal");
  if (modal._trap) { modal.removeEventListener("keydown", modal._trap); modal._trap = null; }
  modal.hidden = true;
  // A full plan re-render can replace the badge while the dialog is open;
  // fall back to the current badge for the same remote.
  let target = remoteReturnFocus;
  if ((!target || !target.isConnected) && remoteReturnKey) {
    const step = Array.from(document.querySelectorAll(
      '.sd-step[data-remote-role="shutdown"]')).find((item) =>
      item.getAttribute("data-remote-host") === remoteReturnKey.host
      && item.getAttribute("data-remote-server") === remoteReturnKey.server);
    target = step && step.querySelector("button.sd-progress-badge");
  }
  if (target && typeof target.focus === "function") target.focus();
  remoteReturnFocus = null;
  remoteReturnKey = null;
}

function applyShutdownProgress(section, progress, detailAvailable) {
  if (!section) return;
  updateTriggerLive(section);
  const summary = section.querySelector(".sd-progress");
  section.querySelectorAll(".sd-node").forEach((node) => {
    node.classList.remove("sd-state-running", "sd-state-succeeded",
      "sd-state-failed", "sd-state-timed-out", "sd-state-skipped");
    const old = node.querySelector(".sd-head .sd-progress-badge");
    if (old) old.remove();
  });
  section.querySelectorAll(".sd-step").forEach((step) => {
    step.classList.remove("sd-state-running", "sd-state-succeeded",
      "sd-state-failed", "sd-state-timed-out");
    step.querySelectorAll(".sd-remote-meta").forEach((node) => node.remove());
  });
  // Remote result badges are focusable buttons, so they are updated in place
  // across the 1 s polls (rebuilding them would steal keyboard focus); any
  // badge not refreshed below is stale and removed at the end.
  const liveBadges = new Set();
  const dropStaleBadges = () => {
    section.querySelectorAll(".sd-step .sd-progress-badge").forEach((badge) => {
      if (!liveBadges.has(badge)) badge.remove();
    });
  };
  if (!progress || !summary || !progress.runId) {
    if (summary) summary.hidden = true;
    dropStaleBadges();
    return;
  }

  const overall = progressStateLabel(progress.state);
  const when = progress.state === "running" ? progress.startedAt : progress.finishedAt;
  const prefix = progress.state === "running" ? "Shutdown in progress"
    : "Last shutdown " + overall;
  summary.className = "sd-progress s-" + progressStateClass(progress.state);
  summary.textContent = prefix + (when ? " · " + relTime(when) : "")
    + (progress.reason ? " · " + progress.reason : "");
  summary.hidden = false;

  (progress.phases || []).forEach((phase) => {
    if (!phase || phase.state === "pending") return;
    const node = Array.from(section.querySelectorAll(".sd-node")).find(
      (item) => item.getAttribute("data-phase-id") === phase.id);
    if (!node) return;
    node.classList.add("sd-state-" + phase.state);
    const badge = el("span", { class: "badge sd-progress-badge "
      + progressStateClass(phase.state), text: progressStateLabel(phase.state) });
    if (phase.detail) badge.title = phase.detail;
    node.querySelector(".sd-head").appendChild(badge);
  });

  (progress.remotes || []).forEach((remote) => {
    const step = Array.from(section.querySelectorAll(".sd-step")).find((item) =>
      item.getAttribute("data-remote-host") === remote.host
      && item.getAttribute("data-remote-server") === remote.server
      && item.getAttribute("data-remote-role") === "shutdown");
    if (!step || remote.state === "pending") return;
    step.classList.add("sd-state-" + remote.state);
    const label = remote.outcome || progressStateLabel(remote.state);
    // A button: click opens the full result (response + exit code) pop-up.
    let badge = step.querySelector("button.sd-progress-badge");
    if (!badge) {
      badge = el("button", { type: "button",
        title: "Show the server's response and exit code" });
      badge.addEventListener("click", () =>
        openRemoteDetail(badge._remote, !!badge._detailAvailable));
      step.appendChild(badge);
    }
    badge._remote = remote;
    badge._detailAvailable = !!detailAvailable;
    badge.className = "badge sd-progress-badge " + progressStateClass(remote.state);
    badge.textContent = progressStateLabel(label);
    liveBadges.add(badge);
    const meta = remoteProgressMeta(remote);
    if (meta) step.appendChild(el("div", { class: "sd-remote-meta", text: meta }));
  });
  dropStaleBadges();
}

// Append one scope's shutdown-plan body (trigger + phase flow) into a container.
function appendShutdownPlanBody(host, target, plan) {
  // A monitoring-only UPS whose plan has NO enabled phase runs nothing on this
  // host — don't render a full (all-skipped) sequence + a "triggers…" banner
  // that reads as if it does. Say plainly that it takes no action.
  const anyEnabled = (plan.phases || []).some((p) => p.enabled);
  if (!anyEnabled) {
    host.appendChild(el("p", { class: "sd-noop" },
      [icon("info"), el("span", { text: "Monitoring only — Eneru runs no shutdown "
        + "actions for this scope. It doesn't power this host, so losing it triggers "
        + "nothing here (it's still monitored, with events and alerts)." })]));
    if (plan.note) host.appendChild(el("p", { class: "chart-note", text: plan.note }));
    return;
  }
  shutdownTriggerNodes(target, plan).forEach((nd) => host.appendChild(nd));
  const intro = el("p", { class: "chart-note" },
    [el("span", { text: "What runs when a power-loss shutdown is triggered, top "
      + "to bottom. " })]);
  if (plan.totalEstimateS) intro.appendChild(
    el("span", { class: "badge", text: "~" + Math.round(plan.totalEstimateS) + "s est." }));
  if (plan.dryRun) intro.appendChild(el("span", { class: "badge warn", text: "dry-run" }));
  if (plan.delegated) intro.appendChild(el("span", { class: "badge info", text: "delegated" }));
  if (plan.coordinatorMode) intro.appendChild(el("span", { class: "badge info", text: "coordinator" }));
  host.appendChild(intro);
  if (plan.note) host.appendChild(el("p", { class: "chart-note", text: plan.note }));
  host.appendChild(el("p", { class: "sd-progress", hidden: "", "aria-live": "polite" }));

  const flow = el("div", { class: "sd-flow" });
  const remoteHealth = shutdownRemoteHealth(target);
  let n = 0;
  (plan.phases || []).forEach((p) => {
    n += 1;
    const node = el("div", { class: "sd-node" + (p.enabled ? "" : " sd-skip"),
      "data-phase-id": p.id });
    const head = el("div", { class: "sd-head" }, [
      el("span", { class: "sd-num", text: String(n) }),
      el("span", { class: "sd-ico" + (p.enabled ? "" : " off") },
        [icon(SD_PHASE_ICONS[p.id] || "power")]),
      el("span", { class: "sd-title", text: p.title }),
    ]);
    if (p.enabled && p.mode === "parallel") {
      head.appendChild(el("span", { class: "sd-mode", text: "⇉ parallel" }));
    }
    if (p.enabled && p.estimateS != null) {
      head.appendChild(el("span", { class: "sd-est", text: "~" + Math.round(p.estimateS) + "s" }));
    }
    if (!p.enabled) {
      // "delegated to host" / "non-local group" read as an accent tag, not flat
      // gray — they're meaningful routing, not just "off".
      const routed = p.skipped === "delegated to host" || p.skipped === "non-local group";
      // Spell out the loopback delegation: "delegated to host" alone reads as a
      // failure, when it actually means the host OS (not the container) powers
      // off. A "?" hint carries the detail.
      const label = p.skipped === "delegated to host"
        ? "delegated to host OS" : (p.skipped || "skipped");
      const tag = el("span", { class: "label-tip" },
        [el("span", { class: "badge" + (routed ? " info" : ""), text: label })]);
      if (p.skipped === "delegated to host") {
        tag.appendChild(helpHint(
          "Eneru runs in a container and hands this phase to the host OS over the "
          + "loopback socket — the host performs the power-off so it doesn't kill "
          + "the container mid-sequence. See Troubleshooting → container loopback "
          + "delegation."));
      }
      head.appendChild(tag);
    }
    node.appendChild(head);
    if (p.enabled && (p.steps || []).length) {
      const steps = el("div", { class: "sd-steps" + (p.mode === "parallel" ? " sd-parallel" : "") });
      p.steps.forEach((s) => {
        const attrs = { class: "sd-step" };
        if (p.id === "remote" && s.host) {
          attrs["data-remote-server"] = s.label;
          attrs["data-remote-host"] = s.host;
          attrs["data-remote-role"] = s.role || "shutdown";
        }
        const st = el("div", attrs,
          [el("div", { class: "sd-step-label", text: s.label })]);
        if (s.detail) st.appendChild(el("div", { class: "sd-step-detail", text: s.detail }));
        if (p.id === "remote" && s.host) {
          const health = remoteHealth.find((row) =>
            row.host === s.host || row.server === s.label);
          if (health) {
            const old = remoteStatusClass(health) === "ok" && remoteCheckIsOld(health);
            const healthClass = old ? "muted" : remoteStatusClass(health);
            const healthLabel = old ? "reachable " + relTime(health.last_checked_at)
              : healthClass === "ok" ? "reachable"
                : healthClass === "warn" ? "degraded" : "unreachable";
            const badge = el("span", { class: "badge sd-health-badge " + healthClass,
              text: healthLabel });
            if (health.last_checked_at) {
              badge.title = "Last checked " + relTime(health.last_checked_at);
            }
            st.appendChild(badge);
          }
        }
        steps.appendChild(st);
      });
      node.appendChild(steps);
    }
    flow.appendChild(node);
  });
  host.appendChild(flow);
}

function shutdownPlanTargets() {
  const group = scopedGroup();
  if (group) {
    return [{ kind: "redundancy", name: group.name,
      label: "Redundancy · " + group.name }];
  }
  const upsName = scopeUpsName();
  if (upsName) {
    const row = lastUpsRows.find((u) => u.name === upsName);
    return row ? [{ kind: "ups", name: row.name, label: row.label || row.name,
      row }] : [];
  }
  return lastUpsRows.map((row) => ({ kind: "ups", name: row.name,
    label: row.label || row.name, row })).concat(lastGroups.map((item) => ({
    kind: "redundancy", name: item.name, label: "Redundancy · " + item.name,
  })));
}

function shutdownEndpoint(target, suffix) {
  const root = target.kind === "redundancy"
    ? "/api/v1/redundancy-groups/" : "/api/v1/ups/";
  return root + encodeURIComponent(target.name) + "/" + suffix;
}

async function refreshShutdownProgress() {
  if (document.hidden || activeTab !== "shutdown" || _sdProgressRefreshing) return;
  const sections = Array.from(document.querySelectorAll(".sd-plan[data-progress-url]"));
  if (!sections.length) return;
  _sdProgressRefreshing = true;
  try {
    await Promise.all(sections.map(async (section) => {
      const res = await api(section.getAttribute("data-progress-url"));
      if (res.ok && res.data) {
        applyShutdownProgress(section, res.data.progress, res.data.remoteDetailAvailable);
      }
    }));
  } finally {
    _sdProgressRefreshing = false;
  }
}

// Render shutdown plans driven by the global UPS scope. Under "All UPS" (fleet)
// every plan is stacked so a monitoring-only UPS's "only remote shutdown runs"
// explanation is visible without hunting a dropdown; a single scope shows just
// that UPS's plan under a clear "Viewing plan for" header. (operator #3)
async function renderShutdownPlan() {
  const host = document.getElementById("shutdown-plan");
  if (!host) return;
  const ctl = document.getElementById("shutdown-controls");
  if (ctl) ctl.hidden = true;   // the header UPS selector is the scope control now
  const targets = shutdownPlanTargets();
  if (!targets.length) {
    host.replaceChildren(el("p", { class: "chart-note", text: "No UPS data yet." }));
    return;
  }
  const stacked = targets.length > 1;
  const myGen = ++_sdGen;
  host.replaceChildren();
  for (const target of targets) {
    const planUrl = shutdownEndpoint(target, "shutdown-plan");
    const progressUrl = shutdownEndpoint(target, "shutdown-progress");
    const [res, progressRes] = await Promise.all([api(planUrl), api(progressUrl)]);
    if (myGen !== _sdGen) return;   // a newer render superseded us
    const plan = res.ok && res.data && res.data.plan;
    const section = el("div", { class: "sd-plan", "data-progress-url": progressUrl });
    section.appendChild(el("div", { class: "sd-plan-title card-title" },
      [el("h3", { text: (stacked ? "Plan · " : "Viewing plan for: ") + target.label }),
       monitoringBadge(target.row)].filter(Boolean)));
    if (!plan) {
      section.appendChild(el("p", { class: "chart-note", text: "Shutdown plan unavailable." }));
    } else {
      appendShutdownPlanBody(section, target, plan);
      applyShutdownProgress(section,
        progressRes.ok && progressRes.data && progressRes.data.progress,
        progressRes.ok && progressRes.data && progressRes.data.remoteDetailAvailable);
    }
    host.appendChild(section);
  }
}

function onTabActivated(name, opts) {
  // F-022: chart event markers refetch by default (a genuine tab activation /
  // range / UPS / metric change). The passive 10s poll passes
  // { refetchEvents: false } so charts redraw fresh history but serve their
  // event markers from cache instead of re-scanning every UPS's full event
  // history each tick.
  const chartOpts = { refetchEvents: !opts || opts.refetchEvents !== false };
  if (name === "overview") {
    renderOverviewSummary(lastUpsRows); renderRedundancy(); renderRemoteHealth();
  }
  else if (name === "power") { renderLineQuality(); if (charts.power) charts.power.load(chartOpts); }
  else if (name === "battery") { renderBatteryHealthTab(); if (charts.battery) charts.battery.load(chartOpts); }
  else if (name === "energy") { renderEnergyTab(); if (charts.energy) charts.energy.load(chartOpts); }
  else if (name === "control") renderControl({ ups: lastUpsRows });
  else if (name === "shutdown") renderShutdownPlan();
  else if (name === "config") renderConfigTab();
}

function initTabs() {
  const list = document.getElementById("tabs");
  if (!list) return;
  tabButtons().forEach((btn) => {
    // Prepend each tab's inline-SVG icon (single source of truth in TAB_ICONS).
    const name = TAB_ICONS[btn.dataset.tab];
    if (name) btn.insertBefore(icon(name), btn.firstChild);
    btn.addEventListener("click", () =>
      selectTab(btn.dataset.tab, { updateHash: true }));
  });
  // Arrow-key navigation across the visible tabs (WAI-ARIA tabs pattern).
  list.addEventListener("keydown", (ev) => {
    const visible = tabButtons().filter((b) => !b.hidden);
    const idx = visible.findIndex((b) => b.dataset.tab === activeTab);
    if (idx < 0) return;
    let next = null;
    if (ev.key === "ArrowRight" || ev.key === "ArrowDown") next = visible[(idx + 1) % visible.length];
    else if (ev.key === "ArrowLeft" || ev.key === "ArrowUp") next = visible[(idx - 1 + visible.length) % visible.length];
    else if (ev.key === "Home") next = visible[0];
    else if (ev.key === "End") next = visible[visible.length - 1];
    if (next) {
      ev.preventDefault();
      selectTab(next.dataset.tab, { updateHash: true, focus: true });
    }
  });
  // Hash routing: load the requested tab, and follow back/forward navigation.
  const fromHash = () => {
    const name = (location.hash || "").replace(/^#/, "");
    selectTab(TAB_IDS.includes(name) ? name : "overview");
  };
  window.addEventListener("hashchange", fromHash);
  fromHash();
  list.addEventListener("scroll", updateTabOverflow, { passive: true });
  window.addEventListener("resize", updateTabOverflow);
  updateTabOverflow();
}

// ----- polling -----

// Daemon build + runtime context, learned from the /api/v1/ups payload and shown
// in the footer ahead of the "Updated · <time>" so the running version and where
// it runs (baremetal / container / Kubernetes) are always visible.
let daemonVersion = null;
let daemonRuntime = null;

// H4: the footer only says "Updated" after a successful fetch, and then shows
// the DAEMON's build time (generatedAt), not the browser clock. A failed fetch
// says how old the data on screen is; past 3 polls the page is marked stale.
// ELI5: a newspaper prints its date on the front page. If the paperboy stops
// coming, yesterday's paper must not look like today's.
const POLL_SECONDS = 10;
const CLIENT_STALE_SECONDS = 3 * POLL_SECONDS;
function clientDataAge() {
  return lastGoodFetchAt ? Math.max(0, (Date.now() - lastGoodFetchAt) / 1000) : null;
}
function clientDataStale() {
  const age = clientDataAge();
  return age != null && age > CLIENT_STALE_SECONDS;
}

// `ok` is the poll result (boolean), or a confirmation message from a control
// action ("Set battery.charge.low on ups"), shown with the time it happened.
function setStatus(ok) {
  const bits = [];
  if (daemonVersion) bits.push("Eneru v" + daemonVersion);
  if (daemonRuntime) bits.push(daemonRuntime);
  const line = document.getElementById("status-line");
  const stale = clientDataStale();
  if (typeof ok === "string" && ok) {
    bits.push(ok);
    bits.push(new Date().toLocaleTimeString());
  } else if (ok) {
    const at = lastGeneratedAt ? new Date(lastGeneratedAt * 1000) : new Date();
    bits.push("Updated " + at.toLocaleTimeString());
  } else if (lastGoodFetchAt) {
    bits.push("No answer from the daemon · last good data "
      + formatAge(clientDataAge()) + " · retrying");
  } else {
    bits.push("Waiting for the daemon…");
  }
  line.textContent = bits.join(" · ");
  line.classList.toggle("stale", !ok);
  document.body.classList.toggle("data-stale", !ok && stale);
  const mark = document.getElementById("stale-mark");
  if (mark) {
    mark.hidden = ok || !stale;
    mark.textContent = "STALE · data from " + formatAge(clientDataAge());
  }
}

// F-043: refresh() is async and driven by a 10s setInterval. If one cycle runs
// longer than 10s (a slow daemon during an incident is exactly when this bites),
// the timer fires again and stacks a second refresh on top of the first,
// compounding load right when the daemon is already struggling. This in-flight
// flag makes a tick a no-op while the previous cycle is still running.
let refreshing = false;

async function refresh() {
  if (refreshing) return;
  refreshing = true;
  try {
    await refreshOnce();
  } finally {
    refreshing = false;
  }
}

async function refreshOnce() {
  // One shared config + remote-health snapshot per cycle so the drill-down reads
  // from memory instead of firing per-card requests.
  const [authState, cfg, rh] = await Promise.all([
    api("/api/v1/auth/state"), api("/api/v1/config"), api("/api/v1/remote-health"),
  ]);
  if (authState.ok && authState.data) {
    authEnabled = !!authState.data.enabled;
  }
  // Only sign out when the server explicitly reports auth is OFF. A transient
  // /api/v1/auth/state failure leaves authState.ok false and preserves the
  // last known authEnabled value. It must NOT be mistaken for "auth disabled
  // server-side" — that would log the operator out on every network blip.
  if (authStateRequiresClear(authState, cfg, !!token())) {
    clearAuthState();
  }
  if (cfg.ok && cfg.data) {
    cfgSnapshot = cfg.data;
    refreshAuthUI();
  }
  if (rh.ok) remoteHealthSnapshot = (rh.data && rh.data.servers) || [];

  const ups = await api("/api/v1/ups");
  const powerStateChanged = !!(
    ups.ok && ups.data
    && powerStateSignature(lastUpsRows)
      !== powerStateSignature(ups.data.ups || [])
  );
  if (ups.ok && ups.data) {
    if (ups.data.version) daemonVersion = ups.data.version;
    // Prefer the top-level runtimeContext; fall back to the nested runtime block.
    const rc = ups.data.runtimeContext
      || (ups.data.runtime && ups.data.runtime.context);
    if (rc) daemonRuntime = rc;
  }
  const upsOk = !!(ups.ok && ups.data);
  if (upsOk) {
    lastGoodFetchAt = Date.now();
    lastGeneratedAt = typeof ups.data.generatedAt === "number" ? ups.data.generatedAt : null;
    // Poll-driven redraws must not yank the operator back to the top of a tab
    // they have scrolled (battery health, energy cards, overview, …). Explicit
    // tab switches still reset to the top via selectTab(); this only wraps the
    // passive 10s refresh's in-place rebuilds.
    preserveWindowScroll(() => {
      renderUps(ups.data); renderControl(ups.data); renderBanner();
    });
    showError("");
  } else {
    // H4: keep the last data visible but say how old it is, and redraw so the
    // per-UPS "updated … ago" ages keep counting.
    const since = lastGoodFetchAt ? " — showing data from " + formatAge(clientDataAge()) : "";
    if (ups.status === 0) {
      showError("⚠️  Connection lost" + since + ". Retrying…",  // L14: network/daemon down
        "Connection lost. Retrying…");
    } else if (ups.status !== 401) {
      showError("Could not load UPS status (HTTP " + ups.status + ")" + since,
        "Could not load UPS status (HTTP " + ups.status + ")");
    }
    if (lastUpsRows.length) {
      preserveWindowScroll(() => { renderOverviewSummary(lastUpsRows); renderBanner(); });
    }
  }
  await loadEvents();        // merges fresh recent events into the accumulated list
  // Redraw only the active tab's chart/widgets (the others redraw on activate).
  // F-022: the passive poll must NOT re-scan chart event markers every tick —
  // Reuse cached markers during steady state, but refetch on an exact NUT power
  // transition so live outage bands/dots appear without a tab switch (F-088).
  preserveWindowScroll(() => onTabActivated(
    activeTab, { refetchEvents: powerStateChanged },
  ));
  // If a detail modal is open, keep it live with the fresh snapshot.
  if (!document.getElementById("detail-modal").hidden && openDetailName) {
    renderDetail(openDetailName);
  }
  setStatus(upsOk);
}

async function init() {
  initTheme();
  await loadAuthState();
  refreshAuthUI();
  document.getElementById("loginBtn").addEventListener("click", openLogin);
  document.getElementById("logoutBtn").addEventListener("click", doLogout);
  document.getElementById("login-cancel").addEventListener("click", closeLogin);
  document.getElementById("login-form").addEventListener("submit", doLogin);

  // Charts (one per data-bearing tab). Power carries voltage bands + event
  // overlays; Battery + Energy carry event overlays.
  charts.power = makeChart({ hostId: "power-graph", upsSelId: "power-ups",
    metricSelId: "power-metric", rangeSelId: "power-range", bands: true,
    events: true, noteId: "power-note", eventsNoteId: "power-events-note" });
  charts.battery = makeChart({ hostId: "battery-graph", upsSelId: "battery-ups",
    metricSelId: "battery-metric", rangeSelId: "battery-range", events: true,
    eventsNoteId: "battery-events-note" });
  charts.energy = makeEnergyChart({ hostId: "energy-graph", upsSelId: "energy-ups",
    rangeSelId: "energy-range", eventsNoteId: "energy-events-note" });
  Object.values(charts).forEach((c) => c.observe());

  // The dashboard view scopes cards and plans. Historical charts follow a
  // concrete view, or expose one shared chart-source selector in fleet mode.
  const gsel = document.getElementById("global-ups");
  if (gsel) gsel.addEventListener("change", onScopeChanged);

  // Shutdown-tab UPS selector: re-render the plan for the chosen UPS/group.
  const sdSel = document.getElementById("shutdown-ups");
  if (sdSel) sdSel.addEventListener("change", renderShutdownPlan);

  // Shared Range across Power/Battery/Energy: changing one applies to all three
  // (they carry identical options) and reloads the active chart, so switching
  // tabs keeps the chosen window instead of snapping back to the default.
  const RANGE_SELECTS = ["power-range", "battery-range", "energy-range"];
  RANGE_SELECTS.forEach((id) => {
    const node = document.getElementById(id);
    if (!node) return;
    node.addEventListener("change", () => {
      RANGE_SELECTS.forEach((other) => {
        const s = document.getElementById(other);
        if (s && s.value !== node.value) s.value = node.value;
      });
      onTabActivated(activeTab);  // redraw whichever chart is showing
    });
  });
  // Shared UPS selection across Power/Battery/Energy (mirrors the Range sync) so
  // switching tabs keeps the same UPS in view.
  CHART_UPS_SELECTS.forEach((id) => {
    const node = document.getElementById(id);
    if (!node) return;
    node.addEventListener("change", () => {
      CHART_UPS_SELECTS.forEach((other) => {
        const s = document.getElementById(other);
        if (s && s.value !== node.value) s.value = node.value;
      });
      onTabActivated(activeTab);   // redraw whichever chart is showing
    });
  });
  // Metric selects reload only their own chart.
  [["power-metric", "power"], ["battery-metric", "battery"]].forEach(([id, chart]) => {
    const node = document.getElementById(id);
    if (node) node.addEventListener("change", () => charts[chart] && charts[chart].load());
  });

  // Discrete filter changes can resize the table a lot; reset to the top of the
  // page so the operator isn't left stranded mid-table. (Text input + the 10s
  // poll deliberately do NOT scroll.)
  const scrollTop = () => window.scrollTo(0, 0);
  document.getElementById("event-source-filter").addEventListener("change", () => {
    applyEventFilters(); scrollTop();
  });
  // Tier is the primary, window-independent event filter.
  document.getElementById("event-tier").addEventListener("change", () => {
    applyEventFilters(); scrollTop();
  });
  document.getElementById("event-type-filter").addEventListener("change", () => {
    updateEventTypeSummary();
    applyEventFilters();
    scrollTop();
  });
  document.getElementById("event-text-filter").addEventListener("input", applyEventFilters);
  document.getElementById("event-range").addEventListener("change", () => {
    resetEvents(); scrollTop();
  });
  document.getElementById("event-load-older").addEventListener("click", loadOlderEvents);
  document.getElementById("event-delete").addEventListener("click", deleteSelected);
  document.getElementById("event-sort-time").addEventListener("click", toggleEventSort);
  document.getElementById("detail-close").addEventListener("click", closeDetail);
  document.getElementById("remote-close").addEventListener("click", closeRemoteDetail);
  document.getElementById("remote-modal").addEventListener("click", (ev) => {
    if (ev.target.id === "remote-modal") closeRemoteDetail();
  });
  // Click anywhere on the backdrop (outside the card) closes the detail modal,
  // not just the ✕.
  document.getElementById("detail-modal").addEventListener("click", (ev) => {
    if (ev.target.id === "detail-modal") closeDetail();
  });
  // Esc closes whichever modal is open.
  document.addEventListener("keydown", (ev) => {
    if (ev.key !== "Escape") return;
    if (!document.getElementById("detail-modal").hidden) closeDetail();
    if (!document.getElementById("remote-modal").hidden) closeRemoteDetail();
    if (!document.getElementById("login-modal").hidden) closeLogin();
  });
  // Close the event-type dropdown (<details>) when clicking anywhere outside it,
  // instead of forcing a second click on the summary.
  document.addEventListener("click", (ev) => {
    document.querySelectorAll("details.event-type-picker[open]").forEach((d) => {
      if (!d.contains(ev.target)) d.removeAttribute("open");
    });
  });
  initTabs();
  refresh();
  setInterval(refresh, 10000);
  setInterval(refreshShutdownProgress, 1000);
}

document.addEventListener("DOMContentLoaded", init);
