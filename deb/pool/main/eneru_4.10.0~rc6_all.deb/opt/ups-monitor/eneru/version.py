"""Version information for Eneru."""

# Version is set at build time via git describe --tags
# Format: "4.3.0" for tagged releases, "4.3.0-5-gabcdef1" for dev builds
__version__ = "4.10.0-rc6-30c537f"
