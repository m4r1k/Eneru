"""Version information for Eneru."""

# Version is set at build time via git describe --tags
# Format: "5.2.1" for tagged releases, "5.2.1-5-gabcdef1" for dev builds
__version__ = "5.4.0-rc4-18e0b82"
